# LarpClient 0.1.0 (Minecraft 1.8.9 / Forge)

Client premium client-side para Minecraft 1.8.9.

## Como compilar (sem computador)
1. Crie um repositorio no GitHub (pelo navegador do celular).
2. Envie o arquivo LarpClient.zip (este projeto zipado) para o repositorio.
3. Crie o arquivo .github/workflows/build.yml com o conteudo de github-workflow/build.yml.
4. Aba Actions -> aguarde o build -> baixe o JAR em Releases ou em Artifacts.
5. Coloque o JAR na pasta mods do Minecraft 1.8.9 com Forge.

## Uso
- RIGHT SHIFT: abre o menu do LarpClient (dentro do jogo).
- Clique esquerdo no modulo: liga/desliga (fica azul).
- Clique direito: abre as configuracoes do modulo.
- Botao HUD: arrastar os HUDs de lugar.
- C: zoom (se o modulo Zoom estiver ligado).
- Config salva em .minecraft/config/larpclient.json

## Estrutura
src/main/java/com/larpclient/
  core/       modulos, configuracoes, salvamento
  gui/        menu principal, ClickGui, editor de HUD
  modules/    combate, HUD, jogador, visual, mundo, cosmeticos
  cosmetics/  asas, chifres, aura, capa, boneco 3D
  util/       desenho 2D/3D, animacoes
