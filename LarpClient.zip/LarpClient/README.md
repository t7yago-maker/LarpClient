# LarpClient 0.3.0 (Forge 1.8.9)

Abra o menu com **RIGHT SHIFT** (clique esquerdo liga/desliga, direito abre as opcoes).

## Combate
Reach (ate 6.0) · Hitbox Expand · AutoClick (clica em qualquer lugar, ate 20 CPS) · Aim Assist (gruda em yaw+pitch, ate em galinha no chao) ·
Trigger Bot · Kill Aura · Velocity · Legit Scaffold · Hitboxes · Hit/Damage Indicator · Target HUD · CPS · Combo · Keystrokes

## Cosmeticos (so no seu cliente)
Horns (modelo unico azul com chama) · Asas (16) · Auras (13, varias ao mesmo tempo) · World Effects (efeitos no mapa) ·
Capas (49 + suas PNGs em `.minecraft/larpclient/capes/` + capas online por nome em `larpclient/capes.txt`) · Pets (9) ·
Kill Effects 3D (Tung Sahur, Tralalero, Bombardiro, Skibidi, Among Us, Troll Face + pre-morte AE) · Avatar

## Mundo
Custom Sky (inclui 5 ceus de metal liquido animados) · Time · Weather · Crosshair (18 estilos) · HUD completo

Aviso: reach/hitbox/aim assist/kill aura/autoclick sao cheats. Servidores com anti-cheat banem. Use em singleplayer ou servidor proprio.

## Novo (0.3.1)
Movement: Speed, Fly, NoFall, Step, Timer, Infinite Jump · Render: ESP, Tracers, Nametags, Chest ESP, TNT Timer, Chunk Borders ·
Player: Auto Armor, Chest Stealer, Auto Tool, Fast Break, Auto GG, Auto Respawn · HUD estilo Lunar: Speedometer, Item Counter, Server Address, Session Timer, Hunger.
Headless corrigido (usa isHidden). Fundo preto em todos os HUDs/paineis.

## Novo (0.3.2)
- Personagem do menu corrigido (cor GL velha deixava o corpo invisivel); skin baixada pelo nome de usuario (Mojang/minotar) com Steve de reserva.
- Menu (logo + opcoes) cresce para ficar do tamanho do personagem.
- Aim Assist: mira interpolada (suave), busca de alvo limitada, "Keep Sprint" para nao parar de andar.
- Korblox novo (bola preta facetada + espinho ciano), horns mais fieis (espinhos em lamina), chama azul maior que se inclina para tras ao andar.
- Avatar: Corpo S15 (Roblox slim), Animacao Zumbi, Brilho + manchas pretas em movimento.
- Capas: a capa escolhida agora substitui a capa original no jogo.

## Horns (modelo real)
As horns agora usam o modelo 3D oficial (assets/larpclient/models/frozen_horns.obj).
Para usar a textura original, coloque o Handle1Tex.png em src/main/resources/assets/larpclient/textures/frozen_horns.png.

## Novo (0.4.0)
- Aim Assist: sem escolha de parte do corpo, mira suave com filtro, cede quando voce mexe o mouse, nao gruda ao quebrar bloco.
- Fake Lag, Blink, Criticals, W-Tap, Auto Sprint, Bunny Hop, Inventory Move, Safe Walk, Glide, Fast Place, No Jump Delay, No Hurt Cam, Anti AFK, Panic, Full Bright, No Bob, Custom FOV, Time Changer, Clear Weather.
- Animacoes de braco (Avatar > Animacao): Zumbi, T-Pose, Asas, Superman, Bracos pra cima, Robo.
- Emotes 3D na tecla G (carro, giro, disco, foguete, dinheiro, mola, trono, onda). Aperte G de novo ou agache para parar.
- Auras de moedas (Bitcoin, Monero, Litecoin, Ethereum) e dinheiro ($ e euro).
- Chama das horns mais alta; korblox redonda com ponta curvada.

## 0.5.0
- ~60 modulos novos (HUDs, combate, movimento, player, visual, utility) em MegaModules; duplicados removidos.
- Chapeus 3D (13 estilos, modulo Hat), 8 auras de corpo novas, 2 efeitos de mapa (Wandering Stars, Confetti Orbs).
- 12 ceus novos, Step Ripples (onda ao pisar), Custom Ground (neve que limpa e volta, gelo, areia, neon, lava...), World Tint.
