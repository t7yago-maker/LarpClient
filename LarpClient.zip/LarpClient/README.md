# LarpClient 0.3.0 (Forge 1.8.9)

Abra o menu com **RIGHT SHIFT** (clique esquerdo liga/desliga, direito abre as opcoes).

## Combate
Reach (ate 6.0) · Hitbox Expand · AutoClick (clica em qualquer lugar, ate 20 CPS) · Aim Assist (gruda em yaw+pitch, ate em galinha no chao) ·
Trigger Bot · Kill Aura · Velocity · Legit Scaffold · Hitboxes · Hit/Damage Indicator · Target HUD · CPS · Combo · Keystrokes

## Cosmeticos (so no seu cliente)
Horns (modelo unico azul com chama) · Asas (16) · Auras (13, varias ao mesmo tempo) · World Effects (efeitos no mapa) ·
Capas (49 + suas PNGs em `.minecraft/larpclient/capes/` + capas online por nome em `larpclient/capes.txt`) · Pets (9) ·
Kill Effects 3D (Tung Sahur, Tralalero, Bombardiro, Skibidi, Among Us, Troll Face + pre-morte AE) · Avatar

## Mundo
Custom Sky (inclui 5 ceus de metal liquido animados) · Time · Weather · Crosshair (18 estilos) · HUD completo

Aviso: reach/hitbox/aim assist/kill aura/autoclick sao cheats. Servidores com anti-cheat banem. Use em singleplayer ou servidor proprio.

## Novo (0.3.1)
Movement: Speed, Fly, NoFall, Step, Timer, Infinite Jump · Render: ESP, Tracers, Nametags, Chest ESP, TNT Timer, Chunk Borders ·
Player: Auto Armor, Chest Stealer, Auto Tool, Fast Break, Auto GG, Auto Respawn · HUD estilo Lunar: Speedometer, Item Counter, Server Address, Session Timer, Hunger.
Headless corrigido (usa isHidden). Fundo preto em todos os HUDs/paineis.
