# LarpClient 0.1.0 (Minecraft 1.8.9 / Forge)

## Compilar sem computador (GitHub Actions)
1. Suba LarpClient.zip no repositorio (Add file > Upload files).
2. Cole o conteudo de ci/build.yml em .github/workflows/build.yml.
3. Aba Actions: se der erro, o motivo aparece na tela de Resumo.
4. Se der certo, baixe larpclient-0.1.0.jar em Releases.
5. Coloque o JAR em Android/data/git.artdeell.mojo/files/instances/<sua instancia>/mods

## Uso
- RIGHT SHIFT abre o menu. Esquerdo liga/desliga, direito abre opcoes.
- Botao HUD arrasta os HUDs. C = zoom (modulo Zoom).
- Config: .minecraft/config/larpclient.json
