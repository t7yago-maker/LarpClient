# LarpClient 0.2.0 (Minecraft 1.8.9 / Forge)

## Compilar sem computador (GitHub Actions)
1. Suba LarpClient.zip na raiz do repositorio (Add file > Upload files).
2. Cole o conteudo de ci/build.yml (ou o build.yml enviado) em .github/workflows/build.yml.
3. Aba Actions: se der erro, o motivo aparece na tela de Resumo (tire print e mande).
4. Se der certo, baixe larpclient-0.2.0.jar em Releases.
5. Coloque o JAR na pasta mods da sua instancia.

## Teclas
- RIGHT SHIFT: menu (clique esquerdo liga/desliga, direito abre opcoes)
- Segurar Q: Perspective (camera livre; ao soltar a mira volta)
- Segurar F (tecla de soltar): Fast Drop, dropa o stack inteiro e passa pelos slots
- C: Zoom

## Novidades 0.2.0
Combate: Reach (3.0-6.0), Hitbox Expand, AutoClick (16 CPS, esquerdo+direito), Aim Assist
(players/mobs/animais + barra 0-100, so com clique esquerdo), Legit Scaffold (ninja bridge).
Player: Perspective, Fast Drop, Fast Place, Toggle Sneak, Chat Timestamps.
Cosmeticos: 23 capas, 16 asas, 13 chifres (Thorn com fogo artificial azul), 13 auras (orbs, galaxy,
flame ring, lightning...), Headless, Korblox, corpo magro S15, Kill Effects (fera, raio, almas,
onda de choque, Tung Sahur).
Mundo: ceus realistas (Day, Dusk, Overcast, Milky Night) com nuvens, nebulosa, raios.
Menu: personagem entra de lado, para a direita e nao segue o mouse; item Minecraft Realms.
FOV dinamico removido. HUD: Module List (estilo hacker).

## Aviso
Reach, Hitbox Expand, AutoClick, Aim Assist e Scaffold sao cheats de PvP: servidores com
anti-cheat banem. Use em singleplayer ou servidor proprio.

## Pendente
Animacoes 1.7 (block-hit), mais modulos estilo Lunar/Badlion/Feather.
