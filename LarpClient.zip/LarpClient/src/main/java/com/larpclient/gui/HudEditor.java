package com.larpclient.gui;

import com.larpclient.core.Module;
import com.larpclient.core.ModuleManager;
import com.larpclient.modules.HudModule;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

/** Arraste os HUDs para onde quiser. Posicoes valem para qualquer resolucao. */
public class HudEditor extends GuiScreen {
    private final GuiScreen parent;
    private HudModule drag;
    private float offX, offY;

    public HudEditor(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        Gui.drawRect(0, 0, width, height, 0x66000000);
        ScaledResolution sr = new ScaledResolution(mc);
        RenderUtil.textC("Arraste os HUDs.  ESC para voltar.", width / 2f, 8f, 1f, 0xFFFFFFFF, true);
        for (Module m : ModuleManager.all) {
            if (!(m instanceof HudModule) || !m.enabled) continue;
            HudModule h = (HudModule) m;
            h.renderOverlay(sr, pt);
            float x = h.xf * width, y = h.yf * height, w = h.w * h.scale.f(), hh = h.h * h.scale.f();
            boolean on = h == drag;
            RenderUtil.roundOutline(x - 1, y - 1, w + 2, hh + 2, 3, 1.2f, on ? 0xFF2F6BFF : 0x88FFFFFF);
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        if (btn != 0) return;
        for (int i = ModuleManager.all.size() - 1; i >= 0; i--) {
            Module m = ModuleManager.all.get(i);
            if (!(m instanceof HudModule) || !m.enabled) continue;
            HudModule h = (HudModule) m;
            float x = h.xf * width, y = h.yf * height, w = h.w * h.scale.f(), hh = h.h * h.scale.f();
            if (mx >= x && mx <= x + w && my >= y && my <= y + hh) {
                drag = h;
                offX = mx - x;
                offY = my - y;
                return;
            }
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long t) {
        if (drag == null) return;
        drag.xf = Math.max(0f, Math.min(0.97f, (mx - offX) / width));
        drag.yf = Math.max(0f, Math.min(0.97f, (my - offY) / height));
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        drag = null;
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) mc.displayGuiScreen(parent);
    }

    @Override
    public void onGuiClosed() {
        ModuleManager.save();
    }
}
