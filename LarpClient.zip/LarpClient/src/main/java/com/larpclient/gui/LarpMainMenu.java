package com.larpclient.gui;

import com.larpclient.cosmetics.PlayerModelRenderer;
import com.larpclient.util.Anim;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.Random;

/** Tela de abertura (CLICK TO OPEN) + menu principal do LarpClient. */
public class LarpMainMenu extends GuiScreen {
    private static boolean introDone = false;
    private static final String NAME = "LarpClient";
    private static final String[] ITEMS = {"Singleplayer", "Multiplayer", "Minecraft Realms", "Minecraft Settings", "Client", "Quit Game"};
    private static final float MENU_X = 0.5f;

    private int phase; // 0 = abertura, 1 = transicao, 2 = menu
    private final long startT;
    private long clickT;
    private float spinBase;
    private final float[][] stars = new float[30][7];
    private final float[] hover = new float[ITEMS.length];
    private final float[] itemY = new float[ITEMS.length];
    private float btnHover;
    private float menuAlpha;

    public LarpMainMenu() {
        startT = System.currentTimeMillis();
        Random r = new Random(7L);
        for (float[] s : stars) {
            s[0] = r.nextFloat() < 0.8f ? (r.nextBoolean() ? r.nextFloat() * 0.3f : 0.7f + r.nextFloat() * 0.3f) : r.nextFloat();
            s[1] = r.nextFloat();
            s[2] = 2.5f + r.nextFloat() * 5f;
            s[3] = 0.4f + r.nextFloat();
            s[4] = r.nextFloat() * 6.28f;
            s[5] = r.nextFloat() * 360f;
            s[6] = 0.15f + r.nextFloat() * 0.3f;
        }
        if (introDone) {
            phase = 2;
            clickT = startT - 100000L;
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void open() {
        if (phase != 0) return;
        phase = 1;
        clickT = System.currentTimeMillis();
        spinBase = (clickT - startT) / 1000f * 18f;
    }

    private static float clampF(float v, float a, float b) {
        return v < a ? a : (v > b ? b : v);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        long now = System.currentTimeMillis();
        float time = (now - startT) / 1000f;
        float tp = phase == 0 ? 0f : (phase == 1 ? Anim.clamp01((now - clickT) / 1500f) : 1f);
        if (phase == 1 && tp >= 1f) {
            phase = 2;
            introDone = true;
        }
        float e = Anim.easeInOut(tp);
        menuAlpha = Anim.clamp01((tp - 0.35f) / 0.65f);

        Gui.drawRect(0, 0, width, height, 0xFF0B0B0B);

        RenderUtil.alphaMul = menuAlpha;
        curtains(time);
        floatStars(time);
        RenderUtil.alphaMul = 1f;

        if (phase >= 1) drawPlayer(now, mx, my);

        // ---- logo ----
        float logoY = height * 0.28f;
        float tw = RenderUtil.width(NAME, 1.2f);
        float left = width * MENU_X - (22f + 8f + tw) / 2f;
        float finalStarX = left + 11f, finalTextX = left + 30f;
        float introTextScale = 1.7f;
        float introTextX = width / 2f - RenderUtil.width(NAME, introTextScale) / 2f;
        float sx = Anim.lerp(width / 2f, finalStarX, e);
        float sy = Anim.lerp(height / 2f - 22f, logoY, e);
        float sr = Anim.lerp(34f, 11f, e);
        float tx = Anim.lerp(introTextX, finalTextX, e);
        float ty = Anim.lerp(height / 2f + 22f, logoY - 5f, e);
        float ts = Anim.lerp(introTextScale, 1.2f, e);
        float fade = phase == 0 ? Anim.clamp01(time / 1.4f) : 1f;
        float rot = phase == 0 ? time * 18f : spinBase + 360f * e + (phase == 2 ? (float) Math.sin(time) * 3f : 0f);
        float pulse = 0.5f + 0.5f * (float) Math.sin(time * 2f);

        RenderUtil.alphaMul = fade;
        RenderUtil.star(sx, sy, sr * (1.18f + 0.05f * pulse), rot, 1f, 0x28FFFFFF);
        RenderUtil.star(sx, sy, sr * 1.08f, rot, 1f, 0x50FFFFFF);
        RenderUtil.star(sx, sy, sr, rot, 2f, 0xFFFFFFFF);
        RenderUtil.text(NAME, tx, ty, ts, 0xFFFFFFFF, false);

        // ---- botao CLICK TO OPEN ----
        float bw = 124f, bh = 20f, bx = width / 2f - bw / 2f, by = height / 2f + 64f;
        boolean over = phase == 0 && mx >= bx && mx <= bx + bw && my >= by && my <= by + bh;
        btnHover += ((over ? 1f : 0f) - btnHover) * 0.2f;
        RenderUtil.alphaMul = fade * (1f - Anim.clamp01(tp * 4f));
        if (RenderUtil.alphaMul > 0.02f) {
            RenderUtil.roundRect(bx, by, bw, bh, 10f, RenderUtil.alpha(0xFFFFFFFF, 0.06f + 0.14f * btnHover));
            RenderUtil.roundOutline(bx, by, bw, bh, 10f, 1.2f, RenderUtil.alpha(0xFFFFFFFF, 0.45f + 0.5f * btnHover));
            RenderUtil.textC("CLICK TO OPEN", width / 2f, by + 6f, 0.9f, 0xFFFFFFFF, false);
        }

        // ---- itens do menu ----
        RenderUtil.alphaMul = menuAlpha;
        if (menuAlpha > 0.02f) {
            float y0 = logoY + 34f;
            for (int i = 0; i < ITEMS.length; i++) {
                float y = y0 + i * 19f + (i >= 3 ? 10f : 0f);
                itemY[i] = y;
                float iw = RenderUtil.width(ITEMS[i], 1f);
                float cx = width * MENU_X;
                boolean ov = menuAlpha > 0.85f && mx >= cx - iw / 2f - 10f && mx <= cx + iw / 2f + 10f && my >= y - 4f && my <= y + 14f;
                hover[i] += ((ov ? 1f : 0f) - hover[i]) * 0.2f;
                RenderUtil.textC(ITEMS[i], cx, y, 1f, RenderUtil.mix(0xFF9A9AA2, 0xFFFFFFFF, hover[i]), false);
                if (hover[i] > 0.02f) RenderUtil.rect(cx - iw / 2f * hover[i], y + 11f, cx + iw / 2f * hover[i], y + 12f, 0xFFFFFFFF);
            }
            RenderUtil.text("LarpClient 0.3.0  |  Minecraft 1.8.9", 6f, height - 12f, 0.8f, 0xFF6E6E78, false);
            String user = mc.getSession().getUsername();
            RenderUtil.text(user + " \u25be", width - RenderUtil.width(user + " \u25be", 1f) - 14f, 12f, 1f, 0xFFFFFFFF, false);
        }
        RenderUtil.alphaMul = 1f;
    }

    private float wave(float b, float y, float t, float i) {
        return b + (float) Math.sin(y * 0.011f + t * 0.55f + i * 0.5f) * 13f
                + (float) Math.sin(y * 0.027f - t * 0.4f) * 5f
                + (float) Math.sin(y / (float) height * Math.PI) * width * 0.03f * (1f + b / (width * 0.26f));
    }

    private void curtains(float t) {
        if (menuAlpha < 0.01f) return;
        int k = 8;
        float cw = width * 0.26f;
        GlStateManager.disableCull();
        for (int side = 0; side < 2; side++) {
            for (int i = 0; i < k; i++) {
                float b0 = i * cw / k, b1 = (i + 1) * cw / k;
                // listras suaves como a referencia: tons alternados, mais fortes na borda e esvaecendo para o centro
                float base = (i % 2 == 0) ? 0.07f : 0.13f;
                float a0 = base * (1.25f - 0.5f * i / (float) k), a1 = base * (1.25f - 0.5f * (i + 1) / (float) k);
                RenderUtil.begin();
                GL11.glBegin(GL11.GL_QUAD_STRIP);
                for (int y = 0; y <= height; y += 6) {
                    float x0 = wave(b0, y, t, i), x1 = wave(b1, y, t, i + 1);
                    if (side == 1) {
                        x0 = width - x0;
                        x1 = width - x1;
                    }
                    RenderUtil.color(((int) (a0 * 255f) << 24) | 0xFFFFFF);
                    GL11.glVertex2f(x0, y);
                    RenderUtil.color(((int) (a1 * 255f) << 24) | 0xFFFFFF);
                    GL11.glVertex2f(x1, y);
                }
                GL11.glEnd();
                RenderUtil.color(0x30FFFFFF);
                GL11.glLineWidth(1.2f);
                GL11.glBegin(GL11.GL_LINE_STRIP);
                for (int y = 0; y <= height; y += 6) {
                    float x1 = wave(b1, y, t, i + 1);
                    GL11.glVertex2f(side == 1 ? width - x1 : x1, y);
                }
                GL11.glEnd();
                RenderUtil.end();
            }
            // brilho borrado na borda interna da cortina
            RenderUtil.begin();
            GL11.glBegin(GL11.GL_QUAD_STRIP);
            for (int y = 0; y <= height; y += 6) {
                float x0 = wave(cw, y, t, k), x1 = x0 + width * 0.09f;
                if (side == 1) {
                    x0 = width - x0;
                    x1 = width - (x1);
                }
                RenderUtil.color(0x0AFFFFFF);
                GL11.glVertex2f(x0, y);
                RenderUtil.color(0x00FFFFFF);
                GL11.glVertex2f(side == 1 ? x0 - width * 0.09f : x1, y);
            }
            GL11.glEnd();
            RenderUtil.end();
        }
        GlStateManager.enableCull();
    }

    private void floatStars(float t) {
        if (menuAlpha < 0.01f) return;
        for (float[] s : stars) {
            float x = (s[0] + 0.02f * (float) Math.sin(t * s[3] * 0.5f + s[4])) * width;
            float yy = (s[1] - t * s[3] * 0.012f) % 1f;
            if (yy < 0f) yy += 1f;
            float a = s[6] * (0.5f + 0.5f * (float) Math.sin(t + s[4]));
            RenderUtil.star(x, yy * height, s[2], s[5] + t * 8f, 1f, ((int) (a * 255f) << 24) | 0xFFFFFF);
        }
    }

    private void drawPlayer(long now, int mx, int my) {
        float age = (now - (clickT + 500L)) / 1000f;
        if (age < 0f) return;
        float s = height * 0.27f;
        float feetY = height - 6f;
        // sai do lado direito da tela e para ao lado das opcoes (menu no centro)
        float endX = width * MENU_X + 62f + s * 0.5f;
        float startX = width + s * 0.7f;
        float wt = Anim.clamp01(age / 2.6f);
        float ew = 1f - (1f - wt) * (1f - wt);
        float px = Anim.lerp(startX, endX, ew);
        boolean walking = wt < 1f;
        float turn = Anim.easeInOut((age - 2.6f) / 0.6f);
        // andando para a esquerda = +90; parado: virado so um pouco para o menu (+28)
        float yaw = walking ? 90f : Anim.lerp(90f, 28f, turn);
        float amt = walking ? 0.85f * (1f - wt * wt * 0.3f) : 0.85f * (1f - turn);
        float hy = walking ? 0f : -6f * turn;
        float ticks = (now - startT) / 50f;
        for (int g = 0; g < 7; g++) {
            RenderUtil.circle(px, feetY - s * 0.85f, s * (1.05f - g * 0.1f), 0x0CFFFFFF);
        }
        PlayerModelRenderer.draw(px, feetY, s, yaw, hy, 0f, age * 9f, amt, ticks, true);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        if (btn != 0) return;
        if (phase == 0) {
            float bw = 124f, bh = 20f, bx = width / 2f - bw / 2f, by = height / 2f + 64f;
            if (mx >= bx && mx <= bx + bw && my >= by && my <= by + bh) open();
            return;
        }
        if (menuAlpha < 0.85f) return;
        for (int i = 0; i < ITEMS.length; i++) {
            float iw = RenderUtil.width(ITEMS[i], 1f);
            float cx = width * MENU_X, y = itemY[i];
            if (mx >= cx - iw / 2f - 10f && mx <= cx + iw / 2f + 10f && my >= y - 4f && my <= y + 14f) {
                action(i);
                return;
            }
        }
    }

    private void action(int i) {
        switch (i) {
            case 0: mc.displayGuiScreen(new GuiSelectWorld(this)); break;
            case 1: mc.displayGuiScreen(new GuiMultiplayer(this)); break;
            case 2:
                try {
                    new net.minecraft.realms.RealmsBridge().switchToRealms(this);
                } catch (Throwable t) {
                    mc.displayGuiScreen(new GuiMultiplayer(this));
                }
                break;
            case 3: mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings)); break;
            case 4: mc.displayGuiScreen(new ClickGui(this)); break;
            default: mc.shutdown(); break;
        }
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (phase == 0 && (key == Keyboard.KEY_RETURN || key == Keyboard.KEY_SPACE)) open();
    }
}
