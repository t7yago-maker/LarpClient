package com.larpclient.gui;

import com.larpclient.cosmetics.Emotes;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

/** Menu de emotes (tecla G). */
public class GuiEmotes extends GuiScreen {
    private static final int COLS = 4;

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private float cardW() {
        return Math.min(110f, (width - 40f) / COLS - 8f);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        RenderUtil.alphaMul = 1f;
        RenderUtil.rect(0, 0, width, height, 0xCC000000);
        float cw = cardW(), ch = 62f, gap = 8f;
        float totalW = COLS * cw + (COLS - 1) * gap;
        float x0 = (width - totalW) / 2f;
        int rows = (Emotes.NAMES.length + COLS - 1) / COLS;
        float totalH = rows * ch + (rows - 1) * gap;
        float y0 = (height - totalH) / 2f + 6f;
        RenderUtil.textC("Emotes", width / 2f, y0 - 30f, 1.5f, 0xFFFFFFFF, false);
        RenderUtil.textC("Clique para executar  -  G de novo para parar", width / 2f, y0 - 14f, 0.85f, 0xFF9A9AAA, false);
        for (int i = 0; i < Emotes.NAMES.length; i++) {
            float x = x0 + (i % COLS) * (cw + gap), y = y0 + (i / COLS) * (ch + gap);
            boolean hov = mx >= x && mx <= x + cw && my >= y && my <= y + ch;
            boolean act = Emotes.current() == i;
            int base = RenderUtil.mix(0xFF0C0C0C, Emotes.COLORS[i], hov ? 0.45f : (act ? 0.6f : 0.22f));
            RenderUtil.roundRect(x, y, cw, ch, 6f, base);
            RenderUtil.roundOutline(x, y, cw, ch, 6f, 1.4f, act ? 0xFF6C9BFF : (hov ? 0xFFFFFFFF : 0x55FFFFFF));
            RenderUtil.circle(x + cw / 2f, y + 22f, 11f, RenderUtil.alpha(Emotes.COLORS[i], 0.9f));
            RenderUtil.textC(String.valueOf(i + 1), x + cw / 2f, y + 18f, 1.1f, 0xFFFFFFFF, false);
            RenderUtil.textC(Emotes.NAMES[i], x + cw / 2f, y + 40f, 0.85f, 0xFFFFFFFF, false);
            RenderUtil.textC(mc.fontRendererObj.trimStringToWidth(Emotes.DESC[i], (int) ((cw - 6f) / 0.62f)), x + cw / 2f, y + 51f, 0.62f, 0xFFB0B0BA, false);
        }
        float by = y0 + totalH + 16f;
        boolean hs = mx >= width / 2f - 40f && mx <= width / 2f + 40f && my >= by && my <= by + 18f;
        RenderUtil.roundRect(width / 2f - 40f, by, 80f, 18f, 5f, hs ? 0x66FF3355 : 0x33FF3355);
        RenderUtil.textC("Parar emote", width / 2f, by + 5f, 0.85f, 0xFFFFFFFF, false);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        float cw = cardW(), ch = 62f, gap = 8f;
        float totalW = COLS * cw + (COLS - 1) * gap;
        float x0 = (width - totalW) / 2f;
        int rows = (Emotes.NAMES.length + COLS - 1) / COLS;
        float totalH = rows * ch + (rows - 1) * gap;
        float y0 = (height - totalH) / 2f + 6f;
        for (int i = 0; i < Emotes.NAMES.length; i++) {
            float x = x0 + (i % COLS) * (cw + gap), y = y0 + (i / COLS) * (ch + gap);
            if (mx >= x && mx <= x + cw && my >= y && my <= y + ch) {
                Emotes.start(i);
                mc.displayGuiScreen(null);
                if (mc.gameSettings.thirdPersonView == 0) mc.gameSettings.thirdPersonView = 2;
                return;
            }
        }
        float by = y0 + totalH + 16f;
        if (mx >= width / 2f - 40f && mx <= width / 2f + 40f && my >= by && my <= by + 18f) {
            Emotes.stop();
            mc.displayGuiScreen(null);
        }
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE || key == Keyboard.KEY_G) {
            mc.displayGuiScreen(null);
            return;
        }
        if (key >= Keyboard.KEY_1 && key <= Keyboard.KEY_8) {
            int i = key - Keyboard.KEY_1;
            if (i < Emotes.NAMES.length) {
                Emotes.start(i);
                mc.displayGuiScreen(null);
                if (mc.gameSettings.thirdPersonView == 0) mc.gameSettings.thirdPersonView = 2;
            }
        }
    }
}
