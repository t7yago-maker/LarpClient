package com.larpclient.gui;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.ModuleManager;
import com.larpclient.core.Setting;
import com.larpclient.cosmetics.PlayerModelRenderer;
import com.larpclient.util.Anim;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Menu do LarpClient (RIGHT SHIFT). Clique esquerdo liga/desliga, direito abre as configuracoes. */
public class ClickGui extends GuiScreen {
    private static final int BLUE = 0xFF2F6BFF;
    private static final float SBW = 84f;

    private final GuiScreen parent;
    private Category cat = Category.COMBAT;
    private Module selected;
    private final long openT = System.currentTimeMillis();
    private float scroll, setScroll;
    private final Map<Module, Float> anim = new HashMap<Module, Float>();

    // layout
    private float px, py, pw, ph, cx, cy, cw, ch, rx, ry, rw, rh, cardW, previewH, setY;
    private int cols;
    private boolean showRight;
    private static final float CARD_H = 30f, GAP = 6f;

    // interacao
    private Setting dragging;
    private float dragX, dragW;
    private boolean pressing, moved, pressContent;
    private int pressX, pressY, lastY, pressBtn;
    private Module pressModule;
    private Setting pendingSetting;
    private int pendingDir;

    public ClickGui(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void layout() {
        pw = Math.min(width - 12, 430);
        ph = Math.min(height - 12, 270);
        px = (width - pw) / 2f;
        py = (height - ph) / 2f;
        showRight = selected != null || cat == Category.COSMETICS;
        rw = showRight ? Math.min(158f, pw * 0.40f) : 0f;
        cx = px + SBW + 8f;
        cy = py + 10f;
        ch = ph - 20f;
        cw = pw - SBW - 16f - (showRight ? rw + 8f : 0f);
        cols = Math.max(1, (int) ((cw + GAP) / (100f + GAP)));
        cardW = (cw - (cols - 1) * GAP) / cols;
        rx = px + pw - rw - 8f;
        ry = cy;
        rh = ch;
        previewH = cat == Category.COSMETICS ? Math.min(rh * 0.5f, 120f) : 0f;
        setY = ry + (previewH > 0f ? previewH + 6f : 0f);
    }

    private List<Module> mods() {
        return ModuleManager.inCategory(cat);
    }

    private float maxScroll() {
        int rows = (mods().size() + cols - 1) / cols;
        return Math.max(0f, rows * (CARD_H + GAP) - ch);
    }

    private float rowHeight(Setting s) {
        switch (s.type) {
            case NUMBER: return 28f;
            case COLOR: return 16f + swRows() * 14f;
            default: return 20f;
        }
    }

    private int swRows() {
        int per = Math.max(1, (int) ((rw - 16f) / 14f));
        return (RenderUtil.PALETTE.length + per - 1) / per;
    }

    private float settingsTop() {
        return setY + (selected != null && !selected.note.isEmpty() ? 34f : 22f);
    }

    private void scissor(float x, float y, float w, float h) {
        int f = new ScaledResolution(mc).getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int) (x * f), (int) (mc.displayHeight - (y + h) * f), Math.max(0, (int) (w * f)), Math.max(0, (int) (h * f)));
    }

    private boolean in(float mx, float my, float x, float y, float w, float h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        layout();
        long now = System.currentTimeMillis();
        float open = Anim.easeOut((now - openT) / 260f);
        float time = (now - openT) / 1000f;
        scroll = Math.max(0f, Math.min(maxScroll(), scroll));

        RenderUtil.alphaMul = open;
        Gui.drawRect(0, 0, width, height, ((int) (0xA0 * open) << 24));
        GlStateManager.pushMatrix();
        GlStateManager.translate(width / 2f, height / 2f, 0f);
        float sc = 0.93f + 0.07f * open;
        GlStateManager.scale(sc, sc, 1f);
        GlStateManager.translate(-width / 2f, -height / 2f, 0f);

        RenderUtil.roundRect(px, py, pw, ph, 8f, 0xF00B0B10);
        RenderUtil.roundOutline(px, py, pw, ph, 8f, 1f, 0x40FFFFFF);
        RenderUtil.roundRect(px + 4f, py + 4f, SBW - 4f, ph - 8f, 6f, 0xFF101018);

        // logo
        RenderUtil.star(px + 20f, py + 20f, 9f, time * 20f, 1.5f, 0xFFFFFFFF);
        RenderUtil.text("LarpClient", px + 33f, py + 16f, 0.95f, 0xFFFFFFFF, false);

        // categorias
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            float by = py + 38f + i * 18f;
            boolean act = cats[i] == cat;
            boolean hov = in(mx, my, px + 8f, by, SBW - 12f, 16f);
            if (act) RenderUtil.roundRect(px + 8f, by, SBW - 12f, 16f, 4f, RenderUtil.alpha(BLUE, 0.85f));
            else if (hov) RenderUtil.roundRect(px + 8f, by, SBW - 12f, 16f, 4f, 0x22FFFFFF);
            RenderUtil.text(cats[i].label, px + 14f, by + 4f, 0.95f, act ? 0xFFFFFFFF : 0xFFB0B0BA, false);
        }
        // botoes de baixo
        float bby = py + ph - 24f;
        if (mc.thePlayer != null) {
            RenderUtil.roundRect(px + 8f, bby, SBW - 44f, 16f, 4f, in(mx, my, px + 8f, bby, SBW - 44f, 16f) ? 0x33FFFFFF : 0x18FFFFFF);
            RenderUtil.textC("HUD", px + 8f + (SBW - 44f) / 2f, bby + 4f, 0.9f, 0xFFFFFFFF, false);
        }
        RenderUtil.roundRect(px + SBW - 32f, bby, 28f, 16f, 4f, in(mx, my, px + SBW - 32f, bby, 28f, 16f) ? 0x55FF3355 : 0x25FF3355);
        RenderUtil.textC("X", px + SBW - 18f, bby + 4f, 0.9f, 0xFFFFFFFF, false);

        // cards
        scissor(cx - 2f, cy - 2f, cw + 4f, ch + 4f);
        List<Module> list = mods();
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            float x = cx + (i % cols) * (cardW + GAP);
            float y = cy + (i / cols) * (CARD_H + GAP) - scroll;
            if (y + CARD_H < cy - 2f || y > cy + ch + 2f) continue;
            Float av = anim.get(m);
            float a = av == null ? (m.enabled ? 1f : 0f) : av;
            a += ((m.enabled ? 1f : 0f) - a) * 0.22f;
            anim.put(m, a);
            boolean hov = in(mx, my, x, y, cardW, CARD_H) && in(mx, my, cx, cy, cw, ch);
            int base = RenderUtil.mix(0xFF18181F, BLUE, a);
            if (hov) base = RenderUtil.mix(base, 0xFFFFFFFF, 0.08f);
            RenderUtil.roundRect(x, y, cardW, CARD_H, 5f, base);
            if (m == selected) RenderUtil.roundOutline(x, y, cardW, CARD_H, 5f, 1.2f, 0xFFFFFFFF);
            RenderUtil.text(mc.fontRendererObj.trimStringToWidth(m.name, (int) (cardW - 18f)), x + 8f, y + 6f, 0.95f, 0xFFFFFFFF, false);
            RenderUtil.text(mc.fontRendererObj.trimStringToWidth(m.desc, (int) ((cardW - 12f) / 0.7f)), x + 8f, y + 18f, 0.7f, 0xFFB8B8C4, false);
            if (!m.note.isEmpty()) RenderUtil.text("!", x + cardW - 9f, y + 5f, 1f, 0xFFFFD60A, true);
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        // coluna da direita
        if (showRight) {
            if (previewH > 0f) {
                RenderUtil.roundRect(rx, ry, rw, previewH, 6f, 0xFF101018);
                float s = (previewH - 26f) / 1.95f;
                PlayerModelRenderer.draw(rx + rw / 2f, ry + previewH - 8f, Math.max(10f, s), (time * 40f) % 360f, 0f, 0f, 0f, 0f, time * 20f, true);
            }
            if (selected != null) drawSettings(mx, my);
            else if (cat == Category.COSMETICS) {
                RenderUtil.text("Botao direito num item", rx + 4f, setY + 4f, 0.8f, 0xFF8A8A96, false);
                RenderUtil.text("abre as opcoes.", rx + 4f, setY + 14f, 0.8f, 0xFF8A8A96, false);
            }
        }
        GlStateManager.popMatrix();
        RenderUtil.alphaMul = 1f;
    }

    private void drawSettings(int mx, int my) {
        float sh = ry + rh - setY;
        RenderUtil.roundRect(rx, setY, rw, sh, 6f, 0xFF101018);
        RenderUtil.text(selected.name, rx + 8f, setY + 6f, 1f, 0xFFFFFFFF, false);
        if (!selected.note.isEmpty()) {
            RenderUtil.text(mc.fontRendererObj.trimStringToWidth(selected.note, (int) ((rw - 12f) / 0.7f)), rx + 8f, setY + 18f, 0.7f, 0xFFFFD60A, false);
        }
        float top = settingsTop();
        scissor(rx, top, rw, ry + rh - top);
        float y = top - setScroll;
        for (Setting s : selected.settings) {
            float rhgt = rowHeight(s);
            if (y + rhgt >= top && y <= ry + rh) drawRow(s, y, mx, my);
            y += rhgt;
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    private void drawRow(Setting s, float y, int mx, int my) {
        float x = rx + 8f, w = rw - 16f;
        RenderUtil.text(s.name, x, y + 3f, 0.85f, 0xFFE0E0EA, false);
        switch (s.type) {
            case TOGGLE: {
                RenderUtil.roundRect(x + w - 24f, y + 1f, 24f, 11f, 5.5f, s.on ? BLUE : 0xFF2A2A34);
                RenderUtil.circle(x + w - (s.on ? 6f : 18f), y + 6.5f, 4f, 0xFFFFFFFF);
                break;
            }
            case CHOICE: {
                String v = "< " + s.m() + " >";
                RenderUtil.text(v, x + w - RenderUtil.width(v, 0.85f), y + 3f, 0.85f, 0xFF7FA6FF, false);
                break;
            }
            case NUMBER: {
                String v = s.display();
                RenderUtil.text(v, x + w - RenderUtil.width(v, 0.85f), y + 3f, 0.85f, 0xFF7FA6FF, false);
                float p = (float) ((s.num - s.min) / (s.max - s.min));
                RenderUtil.roundRect(x, y + 16f, w, 4f, 2f, 0xFF2A2A34);
                RenderUtil.roundRect(x, y + 16f, Math.max(3f, w * p), 4f, 2f, BLUE);
                RenderUtil.circle(x + w * p, y + 18f, 4f, 0xFFFFFFFF);
                break;
            }
            default: {
                int per = Math.max(1, (int) ((rw - 16f) / 14f));
                for (int i = 0; i < RenderUtil.PALETTE.length; i++) {
                    float sx = x + (i % per) * 14f, sy = y + 14f + (i / per) * 14f;
                    int c = RenderUtil.PALETTE[i];
                    if (c == 0) c = RenderUtil.rainbow(i * 0.05f);
                    RenderUtil.roundRect(sx, sy, 11f, 11f, 3f, c);
                    boolean sel = s.color == RenderUtil.PALETTE[i];
                    if (sel) RenderUtil.roundOutline(sx - 1.5f, sy - 1.5f, 14f, 14f, 4f, 1.2f, 0xFFFFFFFF);
                }
            }
        }
    }

    // ------------------------------------------------------------------ mouse
    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        layout();
        // categorias
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (in(mx, my, px + 8f, py + 38f + i * 18f, SBW - 12f, 16f)) {
                cat = cats[i];
                selected = null;
                scroll = 0f;
                setScroll = 0f;
                return;
            }
        }
        float bby = py + ph - 24f;
        if (mc.thePlayer != null && in(mx, my, px + 8f, bby, SBW - 44f, 16f)) {
            mc.displayGuiScreen(new HudEditor(this));
            return;
        }
        if (in(mx, my, px + SBW - 32f, bby, 28f, 16f)) {
            close();
            return;
        }
        pressing = true;
        moved = false;
        pressX = mx;
        pressY = my;
        lastY = my;
        pressBtn = btn;
        pressModule = null;
        pendingSetting = null;
        pressContent = false;

        // configuracoes
        if (showRight && selected != null && in(mx, my, rx, setY, rw, ry + rh - setY)) {
            float y = settingsTop() - setScroll;
            for (Setting s : selected.settings) {
                float h = rowHeight(s);
                if (my >= y && my < y + h && my >= settingsTop()) {
                    float x = rx + 8f, w = rw - 16f;
                    if (s.type == Setting.Type.NUMBER && btn == 0) {
                        dragging = s;
                        dragX = x;
                        dragW = w;
                        slide(mx);
                        pressing = false;
                    } else if (s.type == Setting.Type.COLOR && btn == 0) {
                        int per = Math.max(1, (int) ((rw - 16f) / 14f));
                        for (int i = 0; i < RenderUtil.PALETTE.length; i++) {
                            float sx = x + (i % per) * 14f, sy = y + 14f + (i / per) * 14f;
                            if (in(mx, my, sx, sy, 12f, 12f)) s.color = RenderUtil.PALETTE[i];
                        }
                        pressing = false;
                    } else if (s.type == Setting.Type.TOGGLE || s.type == Setting.Type.CHOICE) {
                        pendingSetting = s;
                        pendingDir = btn == 1 ? -1 : 1;
                    }
                    return;
                }
                y += h;
            }
            return;
        }
        // cards
        if (in(mx, my, cx, cy, cw, ch)) {
            pressContent = true;
            List<Module> list = mods();
            for (int i = 0; i < list.size(); i++) {
                float x = cx + (i % cols) * (cardW + GAP);
                float y = cy + (i / cols) * (CARD_H + GAP) - scroll;
                if (in(mx, my, x, y, cardW, CARD_H)) {
                    pressModule = list.get(i);
                    break;
                }
            }
        }
    }

    private void slide(int mx) {
        if (dragging == null) return;
        double p = Math.max(0.0, Math.min(1.0, (mx - dragX) / dragW));
        dragging.setNumber(dragging.min + p * (dragging.max - dragging.min));
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long t) {
        if (dragging != null) {
            slide(mx);
            return;
        }
        if (!pressing) return;
        if (Math.abs(my - pressY) > 4 || Math.abs(mx - pressX) > 4) moved = true;
        if (moved) {
            float dy = lastY - my;
            if (pressContent) scroll = Math.max(0f, Math.min(maxScroll(), scroll + dy));
            else if (selected != null) setScroll = Math.max(0f, setScroll + dy);
        }
        lastY = my;
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        if (dragging != null) {
            dragging = null;
            ModuleManager.save();
        }
        if (pressing && !moved) {
            if (pressModule != null) {
                if (pressBtn == 0) pressModule.toggle();
                else if (pressBtn == 1) {
                    selected = (selected == pressModule) ? null : pressModule;
                    setScroll = 0f;
                }
                ModuleManager.save();
            } else if (pendingSetting != null) {
                if (pendingSetting.type == Setting.Type.TOGGLE) pendingSetting.on = !pendingSetting.on;
                else pendingSetting.cycle(pendingDir);
                ModuleManager.save();
            }
        }
        pressing = false;
        pressModule = null;
        pendingSetting = null;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int w = Mouse.getEventDWheel();
        if (w == 0) return;
        int mx = Mouse.getEventX() * width / mc.displayWidth;
        float d = -Integer.signum(w) * 24f;
        if (showRight && selected != null && mx > rx) setScroll = Math.max(0f, setScroll + d);
        else scroll = Math.max(0f, Math.min(maxScroll(), scroll + d));
    }

    private void close() {
        mc.displayGuiScreen(parent);
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE || key == Keyboard.KEY_RSHIFT) close();
    }

    @Override
    public void onGuiClosed() {
        ModuleManager.save();
    }
}
