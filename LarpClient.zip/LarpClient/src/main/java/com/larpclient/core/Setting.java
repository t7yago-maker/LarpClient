package com.larpclient.core;

import com.google.gson.JsonObject;
import com.larpclient.util.RenderUtil;

import java.util.Locale;

public class Setting {
    public enum Type { TOGGLE, NUMBER, CHOICE, COLOR }

    public final String name;
    public final Type type;
    public boolean on;
    public double num, min, max, step;
    public String[] options = new String[0];
    public int index;
    public int color;

    private Setting(String name, Type type) {
        this.name = name;
        this.type = type;
    }

    public static Setting toggle(String name, boolean def) {
        Setting s = new Setting(name, Type.TOGGLE);
        s.on = def;
        return s;
    }

    public static Setting number(String name, double def, double min, double max, double step) {
        Setting s = new Setting(name, Type.NUMBER);
        s.num = def;
        s.min = min;
        s.max = max;
        s.step = step;
        return s;
    }

    public static Setting choice(String name, int def, String... options) {
        Setting s = new Setting(name, Type.CHOICE);
        s.options = options;
        s.index = def;
        return s;
    }

    /** rgb = 0 significa arco-iris. */
    public static Setting color(String name, int argb) {
        Setting s = new Setting(name, Type.COLOR);
        s.color = argb;
        return s;
    }

    public boolean b() { return on; }
    public float f() { return (float) num; }
    public int i() { return (int) Math.round(num); }
    public String m() { return options[index]; }
    public int c() { return RenderUtil.resolve(color); }

    public void cycle(int dir) {
        int n = options.length;
        index = ((index + dir) % n + n) % n;
    }

    public void setNumber(double v) {
        v = Math.max(min, Math.min(max, v));
        if (step > 0) v = Math.round(v / step) * step;
        num = v;
    }

    public String display() {
        switch (type) {
            case TOGGLE: return on ? "ON" : "OFF";
            case NUMBER:
                if (step >= 1) return String.valueOf((int) Math.round(num));
                return String.format(Locale.US, "%.2f", num);
            case CHOICE: return options[index];
            default: return color == 0 ? "Rainbow" : "";
        }
    }

    public void save(JsonObject o) {
        switch (type) {
            case TOGGLE: o.addProperty(name, on); break;
            case NUMBER: o.addProperty(name, num); break;
            case CHOICE: o.addProperty(name, index); break;
            case COLOR: o.addProperty(name, color); break;
        }
    }

    public void load(JsonObject o) {
        if (!o.has(name)) return;
        try {
            switch (type) {
                case TOGGLE: on = o.get(name).getAsBoolean(); break;
                case NUMBER: setNumber(o.get(name).getAsDouble()); break;
                case CHOICE:
                    int v = o.get(name).getAsInt();
                    if (v >= 0 && v < options.length) index = v;
                    break;
                case COLOR: color = o.get(name).getAsInt(); break;
            }
        } catch (Exception ignored) {
        }
    }
}
