package com.larpclient.core;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    RENDER("Render"),
    VISUAL("Visual"),
    UTILITY("Utility"),
    HUD("HUD"),
    WORLD("World"),
    COSMETICS("Cosmetics");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
