package com.larpclient.core;

public enum Category {
    COMBAT("Combat"),
    PLAYER("Player"),
    VISUAL("Visual"),
    HUD("HUD"),
    WORLD("World"),
    COSMETICS("Cosmetics");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
