package com.larpclient.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.larpclient.modules.CombatModules;
import com.larpclient.modules.HudModules;
import com.larpclient.modules.PlayerModules;
import com.larpclient.modules.VisualModules;
import com.larpclient.modules.WorldModules;
import com.larpclient.modules.CosmeticModules;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> all = new ArrayList<Module>();
    private static File file;

    private ModuleManager() {}

    public static void init(File mcDir) {
        file = new File(mcDir, "config/larpclient.json");
        CombatModules.register(all);
        HudModules.register(all);
        PlayerModules.register(all);
        VisualModules.register(all);
        WorldModules.register(all);
        CosmeticModules.register(all);
        load();
    }

    public static <T extends Module> T get(Class<T> c) {
        for (Module m : all) {
            if (c.isInstance(m)) return c.cast(m);
        }
        return null;
    }

    public static List<Module> inCategory(Category c) {
        List<Module> r = new ArrayList<Module>();
        for (Module m : all) {
            if (m.category == c) r.add(m);
        }
        return r;
    }

    public static void save() {
        try {
            if (file == null) return;
            JsonObject root = new JsonObject();
            for (Module m : all) {
                JsonObject o = new JsonObject();
                m.save(o);
                root.add(m.name, o);
            }
            file.getParentFile().mkdirs();
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            Files.write(file.toPath(), gson.toJson(root).getBytes(Charset.forName("UTF-8")));
        } catch (Exception ignored) {
        }
    }

    public static void load() {
        try {
            if (file == null || !file.exists()) return;
            String txt = new String(Files.readAllBytes(file.toPath()), Charset.forName("UTF-8"));
            JsonObject root = new JsonParser().parse(txt).getAsJsonObject();
            for (Module m : all) {
                if (root.has(m.name)) m.load(root.getAsJsonObject(m.name));
            }
        } catch (Exception ignored) {
        }
    }
}
