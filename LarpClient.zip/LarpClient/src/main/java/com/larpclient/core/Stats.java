package com.larpclient.core;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;

import java.util.ArrayList;
import java.util.List;

/** Estatisticas de combate compartilhadas pelos modulos. */
public final class Stats {
    public static final List<Long> left = new ArrayList<Long>();
    public static final List<Long> right = new ArrayList<Long>();
    public static int combo;
    public static float reach;
    public static long hitTime;
    public static EntityLivingBase target;
    public static long targetTime;
    private static int prevSelfHurt, prevTargetHurt;

    private Stats() {}

    public static int cps(List<Long> l) {
        long now = System.currentTimeMillis();
        while (!l.isEmpty() && now - l.get(0) > 1000L) l.remove(0);
        return l.size();
    }

    public static void click(int button) {
        long now = System.currentTimeMillis();
        if (button == 0) left.add(now);
        else if (button == 1) right.add(now);
    }

    public static void attack(Entity e, Minecraft mc) {
        if (e instanceof EntityLivingBase) {
            target = (EntityLivingBase) e;
            targetTime = System.currentTimeMillis();
            prevTargetHurt = 0;
        }
        MovingObjectPosition mop = mc.objectMouseOver;
        if (mop != null && mop.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY && mop.hitVec != null) {
            reach = (float) mc.thePlayer.getPositionEyes(1.0F).distanceTo(mop.hitVec);
        }
    }

    public static void tick(Minecraft mc) {
        if (mc.thePlayer == null) return;
        long now = System.currentTimeMillis();
        int sh = mc.thePlayer.hurtTime;
        if (sh > prevSelfHurt) combo = 0;
        prevSelfHurt = sh;
        if (target != null) {
            int th = target.hurtTime;
            if (th > prevTargetHurt && now - targetTime < 600L) {
                combo++;
                hitTime = now;
            }
            prevTargetHurt = th;
        }
        if (combo > 0 && now - hitTime > 3000L) combo = 0;
    }
}
