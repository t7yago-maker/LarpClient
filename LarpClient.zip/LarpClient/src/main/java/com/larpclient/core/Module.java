package com.larpclient.core;

import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final String desc;
    public final Category category;
    public boolean enabled;
    /** Aviso mostrado na GUI (ex.: regras de servidor). */
    public String note = "";
    public final List<Setting> settings = new ArrayList<Setting>();

    protected Module(String name, String desc, Category category) {
        this.name = name;
        this.desc = desc;
        this.category = category;
    }

    protected Setting add(Setting s) {
        settings.add(s);
        return s;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        try {
            if (e) onEnable(); else onDisable();
        } catch (Throwable ignored) {
        }
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(Minecraft mc) {}
    /** Inicio do tick (antes de processar cliques). */
    public void onPreTick(Minecraft mc) {}
    /** Chamado a cada frame (suave). */
    public void onFrame(Minecraft mc, float dt) {}
    public void renderOverlay(ScaledResolution sr, float pt) {}
    public void renderWorld(float pt) {}
    public void onAttack(Entity target) {}
    public void onMouse(int button) {}
    public void onChat(String message) {}

    public void save(JsonObject o) {
        o.addProperty("enabled", enabled);
        for (Setting s : settings) s.save(o);
    }

    public void load(JsonObject o) {
        for (Setting s : settings) s.load(o);
        if (o.has("enabled")) {
            try {
                setEnabled(o.get("enabled").getAsBoolean());
            } catch (Exception ignored) {
            }
        }
    }
}
