package com.larpclient;

import com.larpclient.core.Module;
import com.larpclient.core.ModuleManager;
import com.larpclient.core.Stats;
import com.larpclient.cosmetics.CosmeticRenderer;
import com.larpclient.gui.ClickGui;
import com.larpclient.gui.LarpMainMenu;
import com.larpclient.modules.PlayerModules;
import com.larpclient.modules.VisualModules;
import com.larpclient.modules.WorldModules;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class EventHandlers {
    private final Minecraft mc = Minecraft.getMinecraft();
    private long lastFrame;

    @SubscribeEvent
    public void onGui(GuiOpenEvent e) {
        if (e.gui != null && e.gui.getClass() == GuiMainMenu.class) {
            e.gui = new LarpMainMenu();
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            for (Module m : ModuleManager.all) {
                if (!m.enabled) continue;
                try {
                    m.onPreTick(mc);
                } catch (Throwable ignored) {
                }
            }
            return;
        }
        if (e.phase != TickEvent.Phase.END) return;
        if (LarpClient.openGui != null && LarpClient.openGui.isPressed() && mc.currentScreen == null) {
            mc.displayGuiScreen(new ClickGui(null));
        }
        Stats.tick(mc);
        for (Module m : ModuleManager.all) {
            if (!m.enabled) continue;
            try {
                m.onTick(mc);
            } catch (Throwable ignored) {
            }
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START) return;
        long nowNs = System.nanoTime();
        float dt = lastFrame == 0L ? 0.05f : Math.min(0.2f, (nowNs - lastFrame) / 1.0e9f);
        lastFrame = nowNs;
        if (mc.thePlayer != null && mc.theWorld != null) {
            for (Module m : ModuleManager.all) {
                if (!m.enabled) continue;
                try {
                    m.onFrame(mc, dt);
                } catch (Throwable ignored) {
                }
            }
        }
        WorldModules.TimeChanger t = ModuleManager.get(WorldModules.TimeChanger.class);
        if (t != null && t.enabled) {
            try {
                t.apply();
            } catch (Throwable ignored) {
            }
        }
    }

    @SubscribeEvent
    public void onOverlayPre(RenderGameOverlayEvent.Pre e) {
        if (e.type != RenderGameOverlayEvent.ElementType.CROSSHAIRS) return;
        VisualModules.Crosshair c = ModuleManager.get(VisualModules.Crosshair.class);
        if (c != null && c.enabled && mc.gameSettings.thirdPersonView == 0) {
            e.setCanceled(true);
            try {
                c.drawCrosshair(e.resolution);
            } catch (Throwable ignored) {
            }
        }
    }

    @SubscribeEvent
    public void onOverlayPost(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL) return;
        for (Module m : ModuleManager.all) {
            if (!m.enabled) continue;
            try {
                m.renderOverlay(e.resolution, e.partialTicks);
            } catch (Throwable ignored) {
            }
        }
        RenderUtil.alphaMul = 1f;
    }

    @SubscribeEvent
    public void onWorldLast(RenderWorldLastEvent e) {
        for (Module m : ModuleManager.all) {
            if (!m.enabled) continue;
            try {
                m.renderWorld(e.partialTicks);
            } catch (Throwable ignored) {
            }
        }
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (!e.buttonstate) return;
        Stats.click(e.button);
        for (Module m : ModuleManager.all) {
            if (m.enabled) m.onMouse(e.button);
        }
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        if (mc.thePlayer == null || e.entityPlayer != mc.thePlayer) return;
        Stats.attack(e.target, mc);
        for (Module m : ModuleManager.all) {
            if (m.enabled) m.onAttack(e.target);
        }
    }

    @SubscribeEvent
    public void onFov(FOVUpdateEvent e) {
        // FOV dinamico removido: o campo de visao nao muda ao correr/poções.
        e.newfov = 1.0f;
        PlayerModules.Zoom z = ModuleManager.get(PlayerModules.Zoom.class);
        if (z != null && z.enabled) e.newfov *= z.cur;
    }

    @SubscribeEvent
    public void onFog(EntityViewRenderEvent.FogColors e) {
        WorldModules.CustomSky s = ModuleManager.get(WorldModules.CustomSky.class);
        if (s == null || !s.enabled || !s.wantFog()) return;
        int c = s.horizon((float) e.renderPartialTicks);
        e.red = ((c >> 16) & 255) / 255f;
        e.green = ((c >> 8) & 255) / 255f;
        e.blue = (c & 255) / 255f;
    }

    @SubscribeEvent
    public void onCamera(EntityViewRenderEvent.CameraSetup e) {
        try {
            com.larpclient.cosmetics.DeathEffects.camera(e);
        } catch (Throwable ignored) {
        }
    }

    @SubscribeEvent
    public void onSpecials(net.minecraftforge.client.event.RenderLivingEvent.Specials.Pre e) {
        if (e.entity instanceof net.minecraft.entity.player.EntityPlayer
                && ModuleManager.get(com.larpclient.modules.HackModules.Nametags.class) != null
                && ModuleManager.get(com.larpclient.modules.HackModules.Nametags.class).enabled) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onBlockOverlay(RenderBlockOverlayEvent e) {
        PlayerModules.NoFire n = ModuleManager.get(PlayerModules.NoFire.class);
        if (n != null && n.enabled && e.overlayType == RenderBlockOverlayEvent.OverlayType.FIRE) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent e) {
        try {
            String plain = e.message.getUnformattedText();
            for (Module mm : ModuleManager.all) if (mm.enabled) mm.onChat(plain);
        } catch (Throwable ignored) {
        }
        PlayerModules.ChatTime t = ModuleManager.get(PlayerModules.ChatTime.class);
        if (t == null || !t.enabled || e.type == 2) return;
        String ts = new java.text.SimpleDateFormat("HH:mm").format(new java.util.Date());
        net.minecraft.util.ChatComponentText pre = new net.minecraft.util.ChatComponentText("\u00a77[" + ts + "] \u00a7r");
        pre.appendSibling(e.message);
        e.message = pre;
    }

    @SubscribeEvent
    public void onRenderPlayerPre(RenderPlayerEvent.Pre e) {
        try {
            CosmeticRenderer.onRenderPre(e);
        } catch (Throwable ignored) {
        }
    }

    @SubscribeEvent
    public void onRenderPlayer(RenderPlayerEvent.Post e) {
        try {
            CosmeticRenderer.onRenderPlayer(e);
        } catch (Throwable ignored) {
        }
    }
}
