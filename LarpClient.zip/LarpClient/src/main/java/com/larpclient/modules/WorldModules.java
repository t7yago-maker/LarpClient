package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;

import java.util.List;

public final class WorldModules {
    private WorldModules() {}

    public static void register(List<Module> l) {
        l.add(new TimeChanger());
        l.add(new CustomSky());
        l.add(new WeatherControl());
    }

    public static class TimeChanger extends Module {
        final Setting mode = add(Setting.choice("Mode", 0, "Day", "Noon", "Sunset", "Night", "Midnight", "Custom", "Cycle"));
        final Setting custom = add(Setting.number("Custom Time", 6000, 0, 24000, 100));
        final Setting speed = add(Setting.number("Cycle Speed", 20, 1, 100, 1));
        private float cycle = 0f;

        public TimeChanger() {
            super("Time Changer", "Muda o horario do mundo so para voce.", Category.WORLD);
        }

        public void apply() {
            Minecraft mc = Minecraft.getMinecraft();
            WorldClient w = mc.theWorld;
            if (w == null) return;
            long t;
            switch (mode.m()) {
                case "Day": t = 1000; break;
                case "Noon": t = 6000; break;
                case "Sunset": t = 12500; break;
                case "Night": t = 14500; break;
                case "Midnight": t = 18000; break;
                case "Custom": t = (long) custom.num; break;
                default: t = (long) cycle; break;
            }
            w.setWorldTime(t);
        }

        @Override
        public void onTick(Minecraft mc) {
            cycle = (cycle + speed.f()) % 24000f;
            apply();
        }
    }

    public static class WeatherControl extends Module {
        final Setting mode = add(Setting.choice("Weather", 0, "Clear"));

        public WeatherControl() {
            super("Weather", "Remove chuva e trovoes (so no seu cliente).", Category.WORLD);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.theWorld == null) return;
            mc.theWorld.setRainStrength(0f);
            mc.theWorld.setThunderStrength(0f);
        }
    }

    public static class CustomSky extends Module {
        // presets: diaTopo, diaHorizonte, noiteTopo, noiteHorizonte
        private static final int[][] PRESETS = {
                {0xFF2A0F6B, 0xFF7B3FE4, 0xFF05010F, 0xFF1A0B3D},
                {0xFF4A0A12, 0xFFD9483B, 0xFF110204, 0xFF4A0F18},
                {0xFF050508, 0xFF15151F, 0xFF000000, 0xFF05050A},
                {0xFF0B3C5D, 0xFF3DDBD9, 0xFF020B14, 0xFF0B5D4E},
                {0xFF3A2A6E, 0xFFFF9A3C, 0xFF0A0A1F, 0xFF3A1F4A},
                {0xFF2F6FCF, 0xFFBEDDF7, 0xFF040818, 0xFF141C38},   // Realistic Day
                {0xFF2B3F7A, 0xFFFFB070, 0xFF05071A, 0xFF2A1A3A},   // Realistic Dusk
                {0xFF6E7681, 0xFFAEB5BD, 0xFF0A0C12, 0xFF1A1E26},   // Overcast
                {0xFF0A1535, 0xFF2A4A7A, 0xFF010208, 0xFF0A1226},   // Milky Night
        };
        final Setting preset = add(Setting.choice("Preset", 0, "Purple Storm", "Crimson", "Void Black", "Aurora", "Sunset Gold", "Realistic Day", "Realistic Dusk", "Overcast", "Milky Night", "Custom", "Liquid Chrome", "Liquid Gold", "Liquid Mercury", "Lava Metal", "Liquid Aurora"));
        final Setting dayTop = add(Setting.color("Custom Day Top", 0xFF2F6BFF));
        final Setting dayHor = add(Setting.color("Custom Day Horizon", 0xFF00E5FF));
        final Setting nightTop = add(Setting.color("Custom Night Top", 0xFF02020A));
        final Setting nightHor = add(Setting.color("Custom Night Horizon", 0xFF101040));
        final Setting stars = add(Setting.toggle("Stars", true));
        final Setting bodies = add(Setting.toggle("Sun / Moon", true));
        final Setting emblem = add(Setting.toggle("Star Emblem", true));
        final Setting fog = add(Setting.toggle("Match Fog", true));
        final Setting clouds = add(Setting.toggle("Clouds", true));
        final Setting nebula = add(Setting.toggle("Nebula / Milky Way", true));
        final Setting lightning = add(Setting.toggle("Storm Lightning", true));

        public CustomSky() {
            super("Custom Sky", "Ceu e atmosfera personalizados (local).", Category.WORLD);
        }

        private int[] pal() {
            int i = preset.index;
            if (i >= 10) {
                int q = i - 10;
                return new int[]{LiquidSky.FOG[q], LiquidSky.FOG[q], LiquidSky.DARK[q], LiquidSky.DARK[q]};
            }
            if (i < PRESETS.length) return PRESETS[i];
            return new int[]{dayTop.c(), dayHor.c(), nightTop.c(), nightHor.c()};
        }

        /** 0 = noite, 1 = dia. */
        public float daylight(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null) return 1f;
            float ang = mc.theWorld.getCelestialAngle(pt);
            float v = (float) Math.cos(ang * Math.PI * 2.0) * 2f + 0.5f;
            return Math.max(0f, Math.min(1f, v));
        }

        public int top(float pt) {
            int[] p = pal();
            return RenderUtil.mix(p[2], p[0], daylight(pt));
        }

        public int horizon(float pt) {
            int[] p = pal();
            return RenderUtil.mix(p[3], p[1], daylight(pt));
        }

        public boolean wantStars() { return stars.b(); }
        public boolean wantBodies() { return bodies.b(); }
        public boolean wantEmblem() { return emblem.b(); }
        public boolean wantFog() { return fog.b(); }
        public boolean wantClouds() { return clouds.b(); }
        public boolean wantNebula() { return nebula.b(); }
        public boolean wantLightning() { return lightning.b(); }
        public int presetIndex() { return preset.index; }
        public boolean isLiquid() { return preset.index >= 10; }
        public int liquidTheme() { return preset.index - 10; }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.theWorld != null && mc.theWorld.provider.getSkyRenderer() != SkyRenderer.INSTANCE) {
                mc.theWorld.provider.setSkyRenderer(SkyRenderer.INSTANCE);
            }
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld != null && mc.theWorld.provider.getSkyRenderer() == SkyRenderer.INSTANCE) {
                mc.theWorld.provider.setSkyRenderer(null);
            }
        }
    }
}
