package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

import java.util.List;

public final class CosmeticModules {
    private CosmeticModules() {}

    public static void register(List<Module> l) {
        l.add(new Wings());
        l.add(new Horns());
        l.add(new Aura());
        l.add(new WorldEffects());
        l.add(new Pets());
        l.add(new Cape());
        l.add(new Avatar());
        l.add(new DeathFx());
    }

    // ------------------------------------------------------------------ ASAS
    public static final String[] WING_NAMES = {
            "Bat", "Angel", "Fire", "Tech", "Bat Small", "Bat Large", "Dragon", "Phoenix",
            "Angel Small", "Angel Large", "Crystal", "Butterfly", "Demon", "Ghost", "Raven", "Cyber"};
    /** Cor padrao de cada estilo (0 = usa a cor escolhida). */
    public static final int[] WING_COLOR = {
            0, 0, 0, 0, 0xFF9B30FF, 0xFF6A1BB0, 0xFFB01020, 0xFFFF7A00,
            0xFFFFFFFF, 0xFFFFF0B0, 0xFF3FE0FF, 0xFFFF5FD0, 0xFF8A0010, 0xFFBFD8FF, 0xFF1A1030, 0xFF00F0FF};

    public static class Wings extends Module {
        public final Setting style = add(Setting.choice("Style", 0, WING_NAMES));
        public final Setting useStyleColor = add(Setting.toggle("Use style color", true));
        public final Setting color = add(Setting.color("Color", 0xFF9B30FF));
        public final Setting size = add(Setting.number("Size", 1.0, 0.4, 2.0, 0.05));
        public final Setting speed = add(Setting.number("Flap Speed", 1.0, 0.2, 2.5, 0.1));
        public final Setting glow = add(Setting.toggle("Glow", true));

        public Wings() {
            super("Wings", "Asas 3D: 16 modelos (pequenas, grandes, dragao, fenix...).", Category.COSMETICS);
            enabled = true;
        }

        public int resolveColor() {
            int pc = WING_COLOR[style.index];
            if (useStyleColor.b() && pc != 0) return pc;
            return color.c();
        }
    }

    // ---------------------------------------------------------------- CHIFRES
    public static class Horns extends Module {
        public final Setting size = add(Setting.number("Size", 1.0, 0.5, 1.8, 0.05));
        public final Setting glow = add(Setting.toggle("Glow", true));
        public final Setting flame = add(Setting.toggle("Blue Flame", true));
        public final Setting flameSize = add(Setting.number("Flame Size", 1.0, 0.4, 2.0, 0.05));

        public Horns() {
            super("Horns", "Chifres de espinhos azuis com chama ciano no meio (modelo unico).", Category.COSMETICS);
            enabled = true;
        }
    }

    // ------------------------------------------------------------------ AURA
    public static final String[] AURA_NAMES = {
            "Ring", "Hexagram", "Helix", "Stars", "Orbs", "Orbs Trail", "Galaxy", "Flame Ring",
            "Lightning", "Sparkles", "Runes", "Vortex", "Snow"};

    public static class Aura extends Module {
        /** Varios efeitos ao mesmo tempo: um interruptor por estilo. */
        public final Setting[] on = new Setting[AURA_NAMES.length];
        public final Setting color = add(Setting.color("Color", 0xFF00B7FF));
        public final Setting size = add(Setting.number("Size", 1.0, 0.6, 1.8, 0.05));
        public final Setting speed = add(Setting.number("Speed", 1.0, 0.3, 3.0, 0.1));
        public final Setting count = add(Setting.number("Orb Count", 6, 2, 12, 1));

        public Aura() {
            super("Aura", "13 auras no player - ligue quantas quiser ao mesmo tempo.", Category.COSMETICS);
            for (int i = 0; i < AURA_NAMES.length; i++) {
                on[i] = add(Setting.toggle(AURA_NAMES[i], i == 4 || i == 7));
            }
            enabled = true;
        }
    }

    // ------------------------------------------------------------ EFEITOS NO MAPA
    public static final String[] WORLDFX_NAMES = {
            "Fireflies", "Embers", "Snow", "Sakura Petals", "Starfall", "Floating Orbs",
            "Lightning Bolts", "Blue Flames", "Light Rain", "Smoke Motes"};

    public static class WorldEffects extends Module {
        public final Setting[] on = new Setting[WORLDFX_NAMES.length];
        public final Setting tint = add(Setting.toggle("Use my color", false));
        public final Setting color = add(Setting.color("Color", 0xFF00B7FF));
        public final Setting density = add(Setting.number("Density", 120, 10, 400, 10));
        public final Setting radius = add(Setting.number("Radius", 24, 8, 48, 2));
        public final Setting speed = add(Setting.number("Speed", 1.0, 0.3, 3.0, 0.1));

        public WorldEffects() {
            super("World Effects", "Efeitos no mapa inteiro (vagalumes, brasas, neve, raios...) - combine varios.", Category.COSMETICS);
            for (int i = 0; i < WORLDFX_NAMES.length; i++) {
                on[i] = add(Setting.toggle(WORLDFX_NAMES[i], i == 0 || i == 1));
            }
        }

        @Override
        public void renderWorld(float pt) {
            com.larpclient.cosmetics.WorldFx.render(pt, this);
        }
    }

    // ------------------------------------------------------------------ CAPAS
    private static final String[] BASE_NAMES = {
            "Larp Star", "Void", "Cyber", "Galaxy", "Inferno", "Aurora",
            "Classic Blue", "Classic Red", "Classic Green", "Classic Purple", "Gold Royal", "Black Ops",
            "Pixel Heart", "Creeper", "Dragon Scale", "Sakura", "Sunset Wave", "Ice Crystal", "Matrix",
            "Blood Moon", "Rainbow", "Flame", "Neon Grid",
            "Migrator (style)", "Vanilla (style)", "Mojang Classic (style)", "Mojang Studios (style)",
            "Minecon 2011 (style)", "Minecon 2012 (style)", "Minecon 2013 (style)", "Minecon 2015 (style)",
            "Minecon 2016 (style)", "Prismarine", "Turtle", "Copper",
            "Brazil", "USA", "Japan", "United Kingdom", "Germany", "France", "Spain", "Portugal",
            "Italy", "Argentina", "Mexico", "Canada", "Russia", "South Korea"};
    private static final String[] BASE_FILES = {
            "larp_star", "void", "cyber", "galaxy", "inferno", "aurora",
            "classic_blue", "classic_red", "classic_green", "classic_purple", "gold_royal", "black_ops",
            "pixel_heart", "creeper", "dragon_scale", "sakura", "sunset_wave", "ice_crystal", "matrix",
            "blood_moon", "rainbow", "flame_cape", "neon_grid",
            "migrator", "vanilla", "mojang_classic", "mojang_studios",
            "minecon_2011", "minecon_2012", "minecon_2013", "minecon_2015",
            "minecon_2016", "prismarine", "turtle", "copper",
            "flag_brazil", "flag_usa", "flag_japan", "flag_uk", "flag_germany", "flag_france", "flag_spain", "flag_portugal",
            "flag_italy", "flag_argentina", "flag_mexico", "flag_canada", "flag_russia", "flag_korea"};
    private static final boolean[] BASE_ANIM = new boolean[BASE_NAMES.length];
    static {
        BASE_ANIM[4] = BASE_ANIM[5] = BASE_ANIM[20] = BASE_ANIM[21] = BASE_ANIM[22] = true;
    }

    /** Lista final: capas embutidas + PNGs em .minecraft/larpclient/capes + nomes em larpclient/capes.txt (online). */
    private static final java.util.List<String> EX_NAMES = new java.util.ArrayList<String>();
    private static final java.util.List<String> EX_KEY = new java.util.ArrayList<String>();
    private static final java.util.List<java.io.File> EX_FILE = new java.util.ArrayList<java.io.File>();
    public static final String[] CAPE_NAMES = buildCapeNames();

    private static String[] buildCapeNames() {
        try {
            java.io.File dir = new java.io.File(Minecraft.getMinecraft().mcDataDir, "larpclient/capes");
            dir.mkdirs();
            java.io.File[] fs = dir.listFiles();
            if (fs != null) {
                java.util.Arrays.sort(fs);
                for (java.io.File f : fs) {
                    if (f.getName().toLowerCase().endsWith(".png")) {
                        EX_NAMES.add("File: " + f.getName().substring(0, f.getName().length() - 4));
                        EX_KEY.add(null);
                        EX_FILE.add(f);
                    }
                }
            }
            java.io.File txt = new java.io.File(Minecraft.getMinecraft().mcDataDir, "larpclient/capes.txt");
            if (!txt.exists()) {
                String sample = "# Um nome de jogador por linha. A capa dele (oficial da Mojang/Minecon ou OptiFine) e baixada quando voce escolhe na lista.\n"
                        + "# Exemplo (se o jogador nao tiver capa, a capa nao muda):\n"
                        + "# Dinnerbone\n# jeb_\n";
                java.nio.file.Files.write(txt.toPath(), sample.getBytes("UTF-8"));
            }
            for (String line : java.nio.file.Files.readAllLines(txt.toPath(), java.nio.charset.Charset.forName("UTF-8"))) {
                String n = line.trim();
                if (n.isEmpty() || n.startsWith("#") || n.length() > 16) continue;
                EX_NAMES.add("Online: " + n);
                EX_KEY.add(n);
                EX_FILE.add(null);
            }
        } catch (Throwable ignored) {
        }
        String[] all = new String[BASE_NAMES.length + EX_NAMES.size()];
        System.arraycopy(BASE_NAMES, 0, all, 0, BASE_NAMES.length);
        for (int i = 0; i < EX_NAMES.size(); i++) all[BASE_NAMES.length + i] = EX_NAMES.get(i);
        return all;
    }

    public static class Cape extends Module {
        private final ResourceLocation[][] cache = new ResourceLocation[BASE_NAMES.length][4];
        private final java.util.Map<Integer, ResourceLocation> dyn = new java.util.HashMap<Integer, ResourceLocation>();
        private final java.util.Set<Integer> loading = new java.util.HashSet<Integer>();
        public final Setting style = add(Setting.choice("Style", 0, CAPE_NAMES));

        public Cape() {
            super("Cape", "Capas: 49 prontas (estilo oficiais, bandeiras, animadas) + suas proprias em larpclient/capes + capas online por nome.", Category.COSMETICS);
            enabled = true;
        }

        public ResourceLocation current(float ticks) {
            int i = style.index;
            if (i >= BASE_NAMES.length) {
                ResourceLocation r = dyn.get(i);
                if (r == null) startLoad(i);
                return r != null ? r : fallback();
            }
            int f = BASE_ANIM[i] ? ((int) (ticks / 4f)) & 3 : 0;
            if (cache[i][f] == null) {
                String n = BASE_ANIM[i] ? BASE_FILES[i] + "_" + f : BASE_FILES[i];
                cache[i][f] = new ResourceLocation("larpclient", "textures/capes/" + n + ".png");
            }
            return cache[i][f];
        }

        private ResourceLocation fallback() {
            if (cache[0][0] == null) cache[0][0] = new ResourceLocation("larpclient", "textures/capes/larp_star.png");
            return cache[0][0];
        }

        private void startLoad(final int idx) {
            if (loading.contains(idx)) return;
            loading.add(idx);
            final int k = idx - BASE_NAMES.length;
            final java.io.File file = EX_FILE.get(k);
            final String name = EX_KEY.get(k);
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    java.awt.image.BufferedImage img = null;
                    try {
                        if (file != null) img = javax.imageio.ImageIO.read(file);
                        else {
                            img = fetchMojang(name);
                            if (img == null) img = javax.imageio.ImageIO.read(new java.net.URL("http://s.optifine.net/capes/" + name + ".png"));
                        }
                    } catch (Throwable ignored) {
                    }
                    if (img == null) return;
                    int kk = Math.max(1, (int) Math.ceil(Math.max(img.getWidth() / 64.0, img.getHeight() / 32.0)));
                    java.awt.image.BufferedImage cv = new java.awt.image.BufferedImage(64 * kk, 32 * kk, java.awt.image.BufferedImage.TYPE_INT_ARGB);
                    java.awt.Graphics2D g = cv.createGraphics();
                    g.drawImage(img, 0, 0, null);
                    g.dispose();
                    final java.awt.image.BufferedImage fin = cv;
                    Minecraft.getMinecraft().addScheduledTask(new Runnable() {
                        @Override
                        public void run() {
                            dyn.put(idx, Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation(
                                    "larpcape" + idx, new net.minecraft.client.renderer.texture.DynamicTexture(fin)));
                        }
                    });
                }
            });
            t.setDaemon(true);
            t.start();
        }

        private static String get(String u) throws java.io.IOException {
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "LarpClient");
            java.io.InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            in.close();
            return new String(o.toByteArray(), "UTF-8");
        }

        private static java.awt.image.BufferedImage fetchMojang(String name) {
            try {
                com.google.gson.JsonParser jp = new com.google.gson.JsonParser();
                String id = jp.parse(get("https://api.mojang.com/users/profiles/minecraft/" + name)).getAsJsonObject().get("id").getAsString();
                com.google.gson.JsonObject prof = jp.parse(get("https://sessionserver.mojang.com/session/minecraft/profile/" + id)).getAsJsonObject();
                String val = prof.getAsJsonArray("properties").get(0).getAsJsonObject().get("value").getAsString();
                String json = new String(java.util.Base64.getDecoder().decode(val), "UTF-8");
                com.google.gson.JsonObject tex = jp.parse(json).getAsJsonObject().getAsJsonObject("textures");
                if (tex == null || !tex.has("CAPE")) return null;
                return javax.imageio.ImageIO.read(new java.net.URL(tex.getAsJsonObject("CAPE").get("url").getAsString()));
            } catch (Throwable t) {
                return null;
            }
        }
    }

    // ------------------------------------------------------------------ PETS
    public static final String[] PET_NAMES = {
            "Wolf", "Cat", "Baby Dragon", "Fox", "Slime", "Ghost", "Penguin", "Blaze Spirit", "Bunny"};

    public static class Pets extends Module {
        public final Setting style = add(Setting.choice("Pet", 0, PET_NAMES));
        public final Setting size = add(Setting.number("Size", 1.0, 0.5, 2.5, 0.1));
        public final Setting distance = add(Setting.number("Distance", 1.6, 0.8, 4.0, 0.2));
        public final Setting useColor = add(Setting.toggle("Use my color", false));
        public final Setting color = add(Setting.color("Color", 0xFF9B30FF));
        public final Setting nameTag = add(Setting.toggle("Name Tag", false));

        public Pets() {
            super("Pets", "Bichinho 3D de estimacao que anda atras de voce (lobo, gato, dragao, raposa...).", Category.COSMETICS);
            enabled = true;
        }

        @Override
        public void renderWorld(float pt) {
            com.larpclient.cosmetics.PetRenderer.render(pt, this);
        }
    }

    // ----------------------------------------------------------------- AVATAR
    public static class Avatar extends Module {
        public final Setting headless = add(Setting.toggle("Headless", true));
        public final Setting korblox = add(Setting.toggle("Korblox (perna direita)", false));
        public final Setting skinny = add(Setting.toggle("Magro (simples)", false));
        public final Setting thin = add(Setting.number("Magreza", 0.75, 0.5, 1.0, 0.01));
        public final Setting s15 = add(Setting.toggle("Corpo S15 (Roblox slim)", false));
        public final Setting anim = add(Setting.choice("Animacao", 1, "Normal", "Zumbi"));
        public final Setting spots = add(Setting.toggle("Brilho + manchas pretas", true));
        public final Setting spotSpeed = add(Setting.number("Velocidade das manchas", 1.0, 0.2, 4.0, 0.1));

        public Avatar() {
            super("Avatar", "Headless, Korblox, corpo S15 (Roblox slim), animacao de zumbi e brilho com manchas pretas (so para voce).", Category.COSMETICS);
            enabled = true;
        }
    }

    // --------------------------------------------------------- ANIMACAO DE MORTE
    public static class DeathFx extends Module {
        public final Setting style = add(Setting.choice("Style", 0, com.larpclient.cosmetics.DeathEffects.NAMES));
        public final Setting players = add(Setting.toggle("Players", true));
        public final Setting mobs = add(Setting.toggle("Mobs", true));
        public final Setting animals = add(Setting.toggle("Animals", true));
        public final Setting color = add(Setting.color("Color", 0xFF4FB8FF));
        public final Setting scale = add(Setting.number("Scale", 1.0, 0.5, 2.5, 0.1));

        public DeathFx() {
            super("Kill Effects", "Animacao 3D ao matar: pre-morte estilo AE + meme (Sahur, Tralalero, Bombardiro, Skibidi...).", Category.COSMETICS);
        }

        private final java.util.Map<net.minecraft.entity.Entity, Long> hit = new java.util.HashMap<net.minecraft.entity.Entity, Long>();

        @Override
        public void onAttack(net.minecraft.entity.Entity target) {
            hit.put(target, System.currentTimeMillis());
        }

        @Override
        public void onTick(Minecraft mc) {
            long now = System.currentTimeMillis();
            java.util.Iterator<java.util.Map.Entry<net.minecraft.entity.Entity, Long>> it = hit.entrySet().iterator();
            while (it.hasNext()) {
                java.util.Map.Entry<net.minecraft.entity.Entity, Long> en = it.next();
                net.minecraft.entity.Entity e = en.getKey();
                boolean old = now - en.getValue() > 6000L;
                boolean dead = !e.isEntityAlive() || (e instanceof net.minecraft.entity.EntityLivingBase
                        && ((net.minecraft.entity.EntityLivingBase) e).getHealth() <= 0f);
                if (dead && !old) {
                    boolean ok = (e instanceof EntityPlayer && players.b())
                            || (e instanceof net.minecraft.entity.passive.EntityAnimal && animals.b())
                            || (e instanceof net.minecraft.entity.monster.IMob && mobs.b());
                    if (ok) com.larpclient.cosmetics.DeathEffects.spawn(e, style.index, color.c(), scale.f());
                    it.remove();
                } else if (old) {
                    it.remove();
                }
            }
        }

        @Override
        public void renderWorld(float pt) {
            com.larpclient.cosmetics.DeathEffects.render(pt);
        }

        @Override
        public void renderOverlay(net.minecraft.client.gui.ScaledResolution sr, float pt) {
            com.larpclient.cosmetics.DeathEffects.overlay(sr);
        }
    }
}
