package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;

import java.util.List;
import java.util.Random;

public final class CosmeticModules {
    private CosmeticModules() {}

    private static final Random RND = new Random();

    public static void register(List<Module> l) {
        l.add(new Wings());
        l.add(new Horns());
        l.add(new Aura());
        l.add(new Cape());
    }

    public static class Wings extends Module {
        public final Setting style = add(Setting.choice("Style", 0, "Bat", "Angel", "Fire", "Tech"));
        public final Setting color = add(Setting.color("Color", 0xFF9B30FF));
        public final Setting size = add(Setting.number("Size", 1.0, 0.5, 1.6, 0.05));
        public final Setting speed = add(Setting.number("Flap Speed", 1.0, 0.2, 2.5, 0.1));
        public final Setting glow = add(Setting.toggle("Glow", true));

        public Wings() {
            super("Wings", "Asas 3D (aparecem so para voce).", Category.COSMETICS);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (style.index != 2 || mc.thePlayer == null || mc.theWorld == null) return;
            if (mc.thePlayer.ticksExisted % 2 != 0 || mc.gameSettings.thirdPersonView == 0) return;
            EntityPlayer p = mc.thePlayer;
            double y = Math.toRadians(p.renderYawOffset);
            double bx = Math.sin(y), bz = -Math.cos(y);
            double sx = Math.cos(y), sz = Math.sin(y);
            for (int s = -1; s <= 1; s += 2) {
                double lat = s * (0.5 + RND.nextDouble() * 1.2) * size.f();
                double px = p.posX + bx * 0.35 + sx * lat;
                double pz = p.posZ + bz * 0.35 + sz * lat;
                double py = p.posY + 1.1 + RND.nextDouble() * 0.9;
                mc.theWorld.spawnParticle(EnumParticleTypes.FLAME, px, py, pz, 0.0, 0.03, 0.0);
            }
        }
    }

    public static class Horns extends Module {
        public final Setting style = add(Setting.choice("Style", 0, "Fire", "Dark", "Angel", "Demon", "Crystal", "Dragon", "Custom"));
        public final Setting color = add(Setting.color("Custom Color", 0xFFFF2D55));
        public final Setting size = add(Setting.number("Size", 1.0, 0.5, 1.6, 0.05));
        public final Setting height = add(Setting.number("Custom Height", 0.35, 0.1, 0.7, 0.05));
        public final Setting spread = add(Setting.number("Custom Spread", 0.12, 0.0, 0.4, 0.02));
        public final Setting glow = add(Setting.toggle("Glow", true));

        public Horns() {
            super("Horns", "Chifres 3D com geometria propria.", Category.COSMETICS);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (style.index != 0 || mc.thePlayer == null || mc.theWorld == null) return;
            if (mc.thePlayer.ticksExisted % 2 != 0 || mc.gameSettings.thirdPersonView == 0) return;
            EntityPlayer p = mc.thePlayer;
            double y = Math.toRadians(p.rotationYawHead);
            double sx = Math.cos(y), sz = Math.sin(y);
            double top = p.posY + p.getEyeHeight() + 0.3 * size.f() + (p.isSneaking() ? -0.15 : 0.0);
            for (int s = -1; s <= 1; s += 2) {
                double off = (0.17 + 0.10 * size.f()) * s;
                mc.theWorld.spawnParticle(EnumParticleTypes.FLAME, p.posX + sx * off, top, p.posZ + sz * off,
                        (RND.nextDouble() - 0.5) * 0.01, 0.025, (RND.nextDouble() - 0.5) * 0.01);
            }
        }
    }

    public static class Aura extends Module {
        public final Setting style = add(Setting.choice("Style", 0, "Ring", "Hexagram", "Helix", "Stars"));
        public final Setting color = add(Setting.color("Color", 0xFF00B7FF));
        public final Setting size = add(Setting.number("Size", 1.0, 0.6, 1.8, 0.05));
        public final Setting speed = add(Setting.number("Speed", 1.0, 0.3, 3.0, 0.1));

        public Aura() {
            super("Aura", "Aneis, hexagrama e estrelas ao redor do jogador.", Category.COSMETICS);
        }
    }

    public static class Cape extends Module {
        private static final String[] NAMES = {"Larp Star", "Void", "Cyber", "Galaxy", "Inferno", "Aurora"};
        private static final String[] FILES = {"larp_star", "void", "cyber", "galaxy", "inferno", "aurora"};
        private static final boolean[] ANIM = {false, false, false, false, true, true};
        private final ResourceLocation[][] cache = new ResourceLocation[6][4];
        public final Setting style = add(Setting.choice("Style", 0, NAMES));

        public Cape() {
            super("Cape", "Capas exclusivas do LarpClient (so para voce).", Category.COSMETICS);
        }

        public ResourceLocation current(float ticks) {
            int i = style.index;
            int f = ANIM[i] ? ((int) (ticks / 4f)) & 3 : 0;
            if (cache[i][f] == null) {
                String n = ANIM[i] ? FILES[i] + "_" + f : FILES[i];
                cache[i][f] = new ResourceLocation("larpclient", "textures/capes/" + n + ".png");
            }
            return cache[i][f];
        }
    }
}
