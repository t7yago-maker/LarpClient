package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

import java.util.List;

public final class CosmeticModules {
    private CosmeticModules() {}

    public static void register(List<Module> l) {
        l.add(new Wings());
        l.add(new Horns());
        l.add(new Aura());
        l.add(new Cape());
        l.add(new Avatar());
        l.add(new DeathFx());
    }

    // ------------------------------------------------------------------ ASAS
    public static final String[] WING_NAMES = {
            "Bat", "Angel", "Fire", "Tech", "Bat Small", "Bat Large", "Dragon", "Phoenix",
            "Angel Small", "Angel Large", "Crystal", "Butterfly", "Demon", "Ghost", "Raven", "Cyber"};
    /** Cor padrao de cada estilo (0 = usa a cor escolhida). */
    public static final int[] WING_COLOR = {
            0, 0, 0, 0, 0xFF9B30FF, 0xFF6A1BB0, 0xFFB01020, 0xFFFF7A00,
            0xFFFFFFFF, 0xFFFFF0B0, 0xFF3FE0FF, 0xFFFF5FD0, 0xFF8A0010, 0xFFBFD8FF, 0xFF1A1030, 0xFF00F0FF};

    public static class Wings extends Module {
        public final Setting style = add(Setting.choice("Style", 0, WING_NAMES));
        public final Setting useStyleColor = add(Setting.toggle("Use style color", true));
        public final Setting color = add(Setting.color("Color", 0xFF9B30FF));
        public final Setting size = add(Setting.number("Size", 1.0, 0.4, 2.0, 0.05));
        public final Setting speed = add(Setting.number("Flap Speed", 1.0, 0.2, 2.5, 0.1));
        public final Setting glow = add(Setting.toggle("Glow", true));

        public Wings() {
            super("Wings", "Asas 3D: 16 modelos (pequenas, grandes, dragao, fenix...).", Category.COSMETICS);
            enabled = true;
        }

        public int resolveColor() {
            int pc = WING_COLOR[style.index];
            if (useStyleColor.b() && pc != 0) return pc;
            return color.c();
        }
    }

    // ---------------------------------------------------------------- CHIFRES
    public static final String[] HORN_NAMES = {
            "Fire", "Dark", "Angel", "Demon", "Crystal", "Dragon",
            "Thorn Blue", "Thorn Red", "Thorn Purple", "Thorn White", "Thorn Gold", "Ice", "Custom"};

    public static class Horns extends Module {
        public final Setting style = add(Setting.choice("Style", 6, HORN_NAMES));
        public final Setting color = add(Setting.color("Custom Color", 0xFFFF2D55));
        public final Setting size = add(Setting.number("Size", 1.0, 0.5, 1.8, 0.05));
        public final Setting height = add(Setting.number("Custom Height", 0.35, 0.1, 0.7, 0.05));
        public final Setting spread = add(Setting.number("Custom Spread", 0.12, 0.0, 0.4, 0.02));
        public final Setting glow = add(Setting.toggle("Glow", true));
        public final Setting flame = add(Setting.toggle("Artificial Flame", true));
        public final Setting flameSize = add(Setting.number("Flame Size", 1.0, 0.4, 2.0, 0.05));

        public Horns() {
            super("Horns", "Chifres 3D com espinhos e fogo artificial entre eles.", Category.COSMETICS);
            enabled = true;
        }
    }

    // ------------------------------------------------------------------ AURA
    public static final String[] AURA_NAMES = {
            "Ring", "Hexagram", "Helix", "Stars", "Orbs", "Orbs Trail", "Galaxy", "Flame Ring",
            "Lightning", "Sparkles", "Runes", "Vortex", "Snow"};

    public static class Aura extends Module {
        public final Setting style = add(Setting.choice("Style", 4, AURA_NAMES));
        public final Setting color = add(Setting.color("Color", 0xFF00B7FF));
        public final Setting size = add(Setting.number("Size", 1.0, 0.6, 1.8, 0.05));
        public final Setting speed = add(Setting.number("Speed", 1.0, 0.3, 3.0, 0.1));
        public final Setting count = add(Setting.number("Orb Count", 5, 2, 12, 1));

        public Aura() {
            super("Aura", "13 auras: orbs orbitando, galaxia, chamas, raios, runas...", Category.COSMETICS);
            enabled = true;
        }
    }

    // ------------------------------------------------------------------ CAPAS
    public static final String[] CAPE_NAMES = {
            "Larp Star", "Void", "Cyber", "Galaxy", "Inferno", "Aurora",
            "Classic Blue", "Classic Red", "Classic Green", "Classic Purple", "Gold Royal", "Black Ops",
            "Pixel Heart", "Creeper", "Dragon Scale", "Sakura", "Sunset Wave", "Ice Crystal", "Matrix",
            "Blood Moon", "Rainbow", "Flame", "Neon Grid"};
    private static final String[] CAPE_FILES = {
            "larp_star", "void", "cyber", "galaxy", "inferno", "aurora",
            "classic_blue", "classic_red", "classic_green", "classic_purple", "gold_royal", "black_ops",
            "pixel_heart", "creeper", "dragon_scale", "sakura", "sunset_wave", "ice_crystal", "matrix",
            "blood_moon", "rainbow", "flame_cape", "neon_grid"};
    private static final boolean[] CAPE_ANIM = {
            false, false, false, false, true, true,
            false, false, false, false, false, false,
            false, false, false, false, false, false, false,
            false, true, true, true};

    public static class Cape extends Module {
        private final ResourceLocation[][] cache = new ResourceLocation[CAPE_NAMES.length][4];
        public final Setting style = add(Setting.choice("Style", 0, CAPE_NAMES));

        public Cape() {
            super("Cape", "23 capas exclusivas (so para voce). Animadas: Inferno, Aurora, Rainbow, Flame, Neon.", Category.COSMETICS);
            enabled = true;
        }

        public ResourceLocation current(float ticks) {
            int i = style.index;
            int f = CAPE_ANIM[i] ? ((int) (ticks / 4f)) & 3 : 0;
            if (cache[i][f] == null) {
                String n = CAPE_ANIM[i] ? CAPE_FILES[i] + "_" + f : CAPE_FILES[i];
                cache[i][f] = new ResourceLocation("larpclient", "textures/capes/" + n + ".png");
            }
            return cache[i][f];
        }
    }

    // ----------------------------------------------------------------- AVATAR
    public static class Avatar extends Module {
        public final Setting headless = add(Setting.toggle("Headless", false));
        public final Setting korblox = add(Setting.toggle("Korblox (perna direita)", false));
        public final Setting skinny = add(Setting.toggle("Magro (S15)", false));
        public final Setting thin = add(Setting.number("Magreza", 0.75, 0.5, 1.0, 0.01));

        public Avatar() {
            super("Avatar", "Headless, Korblox e corpo magro estilo Roblox S15 (so para voce).", Category.COSMETICS);
        }
    }

    // --------------------------------------------------------- ANIMACAO DE MORTE
    public static final String[] DEATH_NAMES = {
            "Shadow Beast", "Lightning", "Soul Orbs", "Shockwave", "Tung Sahur (meme)", "Random"};

    public static class DeathFx extends Module {
        public final Setting style = add(Setting.choice("Style", 0, DEATH_NAMES));
        public final Setting players = add(Setting.toggle("Players", true));
        public final Setting mobs = add(Setting.toggle("Mobs", true));
        public final Setting animals = add(Setting.toggle("Animals", true));
        public final Setting color = add(Setting.color("Color", 0xFFB040FF));
        public final Setting scale = add(Setting.number("Scale", 1.0, 0.5, 2.0, 0.1));

        public DeathFx() {
            super("Kill Effects", "Animacao ao matar: fera ataca, raio, almas, onda de choque.", Category.COSMETICS);
        }

        private final java.util.Map<net.minecraft.entity.Entity, Long> hit = new java.util.HashMap<net.minecraft.entity.Entity, Long>();

        @Override
        public void onAttack(net.minecraft.entity.Entity target) {
            hit.put(target, System.currentTimeMillis());
        }

        @Override
        public void onTick(Minecraft mc) {
            long now = System.currentTimeMillis();
            java.util.Iterator<java.util.Map.Entry<net.minecraft.entity.Entity, Long>> it = hit.entrySet().iterator();
            while (it.hasNext()) {
                java.util.Map.Entry<net.minecraft.entity.Entity, Long> en = it.next();
                net.minecraft.entity.Entity e = en.getKey();
                boolean old = now - en.getValue() > 6000L;
                boolean dead = !e.isEntityAlive() || (e instanceof net.minecraft.entity.EntityLivingBase
                        && ((net.minecraft.entity.EntityLivingBase) e).getHealth() <= 0f);
                if (dead && !old) {
                    if (AdvCombatModules.kindOk(e, mc, true, true, true) || e instanceof net.minecraft.entity.EntityLivingBase) {
                        boolean ok = (e instanceof EntityPlayer && players.b())
                                || (e instanceof net.minecraft.entity.passive.EntityAnimal && animals.b())
                                || (e instanceof net.minecraft.entity.monster.IMob && mobs.b());
                        if (ok) com.larpclient.cosmetics.DeathEffects.spawn(e.posX, e.posY, e.posZ, style.index, color.c(), scale.f());
                    }
                    it.remove();
                } else if (old || (dead && old)) {
                    it.remove();
                }
            }
        }

        @Override
        public void renderWorld(float pt) {
            com.larpclient.cosmetics.DeathEffects.render(pt);
        }
    }
}
