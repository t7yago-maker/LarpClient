package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.opengl.GL11;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pacote grande de modulos simples: HUDs extras, combate, movimento, player, visual, utility e world. */
public final class MegaModules {
    private MegaModules() {}

    public interface Lines { String[] get(Minecraft mc); }

    /** HUD de texto definido por lambda. */
    public static class Hud extends HudModules.TextHud {
        final Lines fn;

        public Hud(String n, String d, int idx, Lines fn) {
            super(n, d, Category.HUD, 0.30f + (idx % 6) * 0.11f, 0.02f + (idx / 6) * 0.07f);
            this.fn = fn;
        }

        @Override
        protected String[] lines(Minecraft mc) {
            try {
                String[] r = fn.get(mc);
                return r == null ? new String[]{"-"} : r;
            } catch (Throwable t) {
                return new String[]{"-"};
            }
        }
    }

    static String f1(double v) { return String.format(Locale.US, "%.1f", v); }

    static int invCount(EntityPlayerSP p, net.minecraft.item.Item it) {
        int n = 0;
        for (ItemStack s : p.inventory.mainInventory) if (s != null && s.getItem() == it) n += s.stackSize;
        return n;
    }

    public static void register(List<Module> l) {
        int i = 0;
        // ---------------- HUD (leitura)
        l.add(new Hud("Health Display", "Vida atual e maxima.", i++, mc -> new String[]{"Vida: " + f1(mc.thePlayer.getHealth()) + "/" + f1(mc.thePlayer.getMaxHealth())}));
        l.add(new Hud("Food Display", "Nivel de fome.", i++, mc -> new String[]{"Fome: " + mc.thePlayer.getFoodStats().getFoodLevel()}));
        l.add(new Hud("Absorption HUD", "Coracoes dourados.", i++, mc -> new String[]{"Absorcao: " + f1(mc.thePlayer.getAbsorptionAmount())}));
        l.add(new Hud("Armor Value", "Pontos de armadura.", i++, mc -> new String[]{"Armadura: " + mc.thePlayer.getTotalArmorValue()}));
        l.add(new Hud("Biome HUD", "Bioma atual.", i++, mc -> new String[]{"Bioma: " + mc.theWorld.getBiomeGenForCoords(new BlockPos(mc.thePlayer)).biomeName}));
        l.add(new Hud("Light Level", "Nivel de luz onde voce esta.", i++, mc -> new String[]{"Luz: " + mc.theWorld.getLight(new BlockPos(mc.thePlayer))}));
        l.add(new Hud("Day Counter", "Dia do mundo e hora.", i++, mc -> {
            long t = mc.theWorld.getWorldTime();
            return new String[]{"Dia " + (t / 24000L) + "  (" + (t % 24000L) + ")"};
        }));
        l.add(new Hud("Held Item", "Item na mao e durabilidade.", i++, mc -> {
            ItemStack s = mc.thePlayer.getHeldItem();
            if (s == null) return new String[]{"Mao vazia"};
            String r = s.getDisplayName();
            if (s.getMaxDamage() > 0) r += " (" + (s.getMaxDamage() - s.getItemDamage()) + ")";
            return new String[]{r};
        }));
        l.add(new Hud("Player Count", "Jogadores no servidor.", i++, mc -> new String[]{"Online: " + (mc.getNetHandler() == null ? 0 : mc.getNetHandler().getPlayerInfoMap().size())}));
        l.add(new Hud("Facing Block", "Bloco para o qual voce olha.", i++, mc -> {
            MovingObjectPosition o = mc.objectMouseOver;
            if (o == null || o.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return new String[]{"Olhando: ar"};
            return new String[]{"Olhando: " + mc.theWorld.getBlockState(o.getBlockPos()).getBlock().getLocalizedName()};
        }));
        l.add(new Hud("Fall Distance", "Distancia de queda atual.", i++, mc -> new String[]{"Queda: " + f1(mc.thePlayer.fallDistance)}));
        l.add(new Hud("Yaw / Pitch", "Rotacao da camera.", i++, mc -> new String[]{"Yaw: " + f1(MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationYaw)), "Pitch: " + f1(mc.thePlayer.rotationPitch)}));
        l.add(new Hud("Chunk HUD", "Coordenadas do chunk.", i++, mc -> new String[]{"Chunk: " + (((int) Math.floor(mc.thePlayer.posX)) >> 4) + ", " + (((int) Math.floor(mc.thePlayer.posZ)) >> 4)}));
        l.add(new Hud("Move State", "Sprint / sneak / chao.", i++, mc -> new String[]{(mc.thePlayer.isSprinting() ? "Sprint " : "") + (mc.thePlayer.isSneaking() ? "Sneak " : "") + (mc.thePlayer.onGround ? "Chao" : "Ar")}));
        l.add(new Hud("XP Level", "Nivel de experiencia.", i++, mc -> new String[]{"XP: " + mc.thePlayer.experienceLevel}));
        l.add(new Hud("Entity Count", "Entidades carregadas.", i++, mc -> new String[]{"Entidades: " + mc.theWorld.loadedEntityList.size()}));
        l.add(new Hud("Gamemode HUD", "Modo de jogo.", i++, mc -> new String[]{"Modo: " + mc.playerController.getCurrentGameType().getName()}));
        l.add(new Hud("Dimension HUD", "Dimensao atual.", i++, mc -> new String[]{"Dim: " + mc.theWorld.provider.getDimensionName()}));
        l.add(new Hud("Arrow Counter", "Flechas no inventario.", i++, mc -> new String[]{"Flechas: " + invCount(mc.thePlayer, Items.arrow)}));
        l.add(new Hud("Gapple Counter", "Macas douradas no inventario.", i++, mc -> new String[]{"Gapples: " + invCount(mc.thePlayer, Items.golden_apple)}));
        l.add(new Hud("Pearl Counter", "Ender pearls no inventario.", i++, mc -> new String[]{"Pearls: " + invCount(mc.thePlayer, Items.ender_pearl)}));
        l.add(new Hud("Free Slots", "Espacos livres no inventario.", i++, mc -> {
            int n = 0;
            for (ItemStack s : mc.thePlayer.inventory.mainInventory) if (s == null) n++;
            return new String[]{"Slots livres: " + n};
        }));
        l.add(new Hud("Weather HUD", "Chuva e fase da lua.", i++, mc -> new String[]{(mc.theWorld.isRaining() ? "Chovendo" : "Limpo") + " | Lua " + mc.theWorld.getMoonPhase()}));
        l.add(new Hud("Vertical Speed", "Velocidade vertical.", i++, mc -> new String[]{"Vy: " + f1(mc.thePlayer.motionY * 20)}));
        l.add(new Hud("Nearby Players", "Jogadores a menos de 30 blocos.", i++, mc -> {
            int n = 0;
            for (Object o : mc.theWorld.playerEntities) if (o != mc.thePlayer && ((Entity) o).getDistanceToEntity(mc.thePlayer) < 30f) n++;
            return new String[]{"Perto: " + n};
        }));
        l.add(new Hud("Armor Durability", "Durabilidade media da armadura.", i++, mc -> {
            int cur = 0, max = 0;
            for (ItemStack s : mc.thePlayer.inventory.armorInventory) if (s != null) { cur += s.getMaxDamage() - s.getItemDamage(); max += s.getMaxDamage(); }
            return new String[]{"Armadura: " + (max == 0 ? 0 : cur * 100 / max) + "%"};
        }));
        l.add(new Stopwatch());
        l.add(new Watermark());

        // ---------------- combate
        l.add(new JumpReset());
        l.add(new AutoWeapon());
        l.add(new HitSound());
        l.add(new NoClickDelay());

        // ---------------- movimento
        l.add(new AutoWalk());
        l.add(new AutoJump());
        l.add(new Parkour());
        l.add(new FastLadder());
        l.add(new NoWeb());
        l.add(new HighJump());
        l.add(new Jesus());
        l.add(new AntiVoid());
        l.add(new LowGravity());
        l.add(new FastFall());

        // ---------------- player
        l.add(new AutoMine());
        l.add(new AutoUse());
        l.add(new DeathCoords());
        l.add(new NoPotionVisuals());

        // ---------------- visual
        l.add(new MobEsp());
        l.add(new ItemEsp());
        l.add(new Radar());
        l.add(new LowHealthWarning());
        l.add(new Waypoint());
        l.add(new MoveTrail());
        l.add(new ScreenSnow());

        // ---------------- utility / world
        l.add(new CopyCoords());
        l.add(new ClearChat());
        l.add(new AutoLog());
        l.add(new FpsBoost());
        l.add(new BreakReminder());
        l.add(new NoWeatherSounds());
    }

    // ============================================================ HUD especiais
    public static class Stopwatch extends HudModules.TextHud {
        long start;

        public Stopwatch() {
            super("Stopwatch", "Cronometro desde que foi ligado.", Category.HUD, 0.30f, 0.30f);
        }

        @Override
        public void onEnable() { start = System.currentTimeMillis(); }

        @Override
        protected String[] lines(Minecraft mc) {
            long s = (System.currentTimeMillis() - start) / 1000L;
            return new String[]{String.format(Locale.US, "%02d:%02d", s / 60, s % 60)};
        }
    }

    public static class Watermark extends Module {
        final Setting color = add(Setting.color("Color", 0));

        public Watermark() {
            super("Watermark", "Nome do client no topo da tela.", Category.HUD);
        }

        @Override
        public void renderOverlay(ScaledResolution sr, float pt) {
            RenderUtil.textC("LarpClient", sr.getScaledWidth() / 2f, 4, 1.2f, color.c(), true);
        }
    }

    // ============================================================ combate
    public static class JumpReset extends Module {
        public JumpReset() {
            super("Jump Reset", "Pula ao tomar dano para reduzir o knockback.", Category.COMBAT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && p.hurtTime == 9 && p.onGround && mc.currentScreen == null) p.jump();
        }
    }

    public static class AutoWeapon extends Module {
        public AutoWeapon() {
            super("Auto Weapon", "Troca para a melhor espada ao atacar.", Category.COMBAT);
        }

        @Override
        public void onAttack(Entity target) {
            Minecraft mc = Minecraft.getMinecraft();
            EntityPlayerSP p = mc.thePlayer;
            if (p == null) return;
            int best = -1;
            float bd = -1;
            for (int s = 0; s < 9; s++) {
                ItemStack st = p.inventory.mainInventory[s];
                if (st != null && st.getItem() instanceof ItemSword) {
                    float d = ((ItemSword) st.getItem()).getDamageVsEntity();
                    if (d > bd) { bd = d; best = s; }
                }
            }
            if (best >= 0) p.inventory.currentItem = best;
        }
    }

    public static class HitSound extends Module {
        public HitSound() {
            super("Hit Sound", "Toca um som ao acertar um golpe.", Category.COMBAT);
        }

        @Override
        public void onAttack(Entity target) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) mc.thePlayer.playSound("random.orb", 0.6f, 1.4f);
        }
    }

    public static class NoClickDelay extends Module {
        Field f;
        boolean tried;

        public NoClickDelay() {
            super("No Click Delay", "Remove o atraso de clique esquerdo (1.8).", Category.COMBAT);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (!tried) {
                tried = true;
                try {
                    f = ReflectionHelper.findField(Minecraft.class, "leftClickCounter", "field_71429_W");
                } catch (Throwable t) {
                    f = null;
                }
            }
            try {
                if (f != null) f.setInt(mc, 0);
            } catch (Throwable ignored) {
            }
        }
    }

    // ============================================================ movimento
    public static class AutoWalk extends Module {
        public AutoWalk() {
            super("Auto Walk", "Anda para frente sozinho.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.currentScreen == null) KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        }
    }

    public static class AutoJump extends Module {
        public AutoJump() {
            super("Auto Jump", "Pula sozinho ao bater num bloco.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && p.onGround && p.isCollidedHorizontally && mc.gameSettings.keyBindForward.isKeyDown()) p.jump();
        }
    }

    public static class Parkour extends Module {
        public Parkour() {
            super("Parkour", "Pula sozinho na borda dos blocos.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null || mc.theWorld == null || !p.onGround || p.isSneaking() || !mc.gameSettings.keyBindForward.isKeyDown()) return;
            if (mc.theWorld.getCollidingBoundingBoxes(p, p.getEntityBoundingBox().offset(p.motionX, -1.0, p.motionZ)).isEmpty()) p.jump();
        }
    }

    public static class FastLadder extends Module {
        public FastLadder() {
            super("Fast Ladder", "Sobe escadas mais rapido.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && p.isOnLadder() && p.isCollidedHorizontally && mc.gameSettings.keyBindForward.isKeyDown()) p.motionY = 0.25;
        }
    }

    public static class NoWeb extends Module {
        public NoWeb() {
            super("No Web", "Teia de aranha nao te segura.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer != null) mc.thePlayer.isInWeb = false;
        }
    }

    public static class HighJump extends Module {
        final Setting mult = add(Setting.number("Altura", 1.5, 1.0, 3.0, 0.1));

        public HighJump() {
            super("High Jump", "Pulo mais alto.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && mc.currentScreen == null && p.onGround && mc.gameSettings.keyBindJump.isKeyDown()) p.motionY = 0.42 * mult.num;
        }
    }

    public static class Jesus extends Module {
        public Jesus() {
            super("Jesus", "Flutua sobre a agua.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && p.isInWater() && !p.isSneaking()) p.motionY = 0.1;
        }
    }

    public static class AntiVoid extends Module {
        double lx, ly, lz;
        boolean has;

        public AntiVoid() {
            super("Anti Void", "Volta para o ultimo chao ao cair no void.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null) return;
            if (p.onGround) { lx = p.posX; ly = p.posY; lz = p.posZ; has = true; }
            else if (has && p.posY < 0) {
                p.setPosition(lx, ly + 0.1, lz);
                p.motionX = p.motionY = p.motionZ = 0;
                p.fallDistance = 0;
            }
        }
    }

    public static class LowGravity extends Module {
        final Setting str = add(Setting.number("Forca", 0.03, 0.01, 0.07, 0.01));

        public LowGravity() {
            super("Low Gravity", "Gravidade reduzida (cai devagar).", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && !p.onGround && !p.isInWater() && !p.capabilities.isFlying && p.motionY < 0) p.motionY += str.num;
        }
    }

    public static class FastFall extends Module {
        public FastFall() {
            super("Fast Fall", "Cai mais rapido.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && !p.onGround && !p.isInWater() && !p.capabilities.isFlying && p.motionY < -0.1) p.motionY -= 0.04;
        }
    }

    // ============================================================ player
    public static class AutoMine extends Module {
        public AutoMine() {
            super("Auto Mine", "Segura o botao de quebrar.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.currentScreen == null) KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), true);
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
        }
    }

    public static class AutoUse extends Module {
        public AutoUse() {
            super("Auto Use", "Segura o botao de usar item.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.currentScreen == null) KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        }
    }

    public static class DeathCoords extends Module {
        boolean dead;
        double dx, dy, dz;
        boolean has;

        public DeathCoords() {
            super("Death Coords", "Avisa no chat e marca onde voce morreu.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null) return;
            boolean d = p.getHealth() <= 0 || p.isDead;
            if (d && !dead) {
                dx = p.posX; dy = p.posY; dz = p.posZ; has = true;
                p.addChatMessage(new ChatComponentText("§7[Larp] Voce morreu em §f" + (int) dx + " " + (int) dy + " " + (int) dz));
            }
            dead = d;
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (!has || mc.thePlayer == null) return;
            RenderUtil.worldText("Morte", dx - RenderUtil.camX(pt), dy + 1.5 - RenderUtil.camY(pt), dz - RenderUtil.camZ(pt), 0.04f, 0xFFFF5050);
        }
    }

    public static class NoPotionVisuals extends Module {
        public NoPotionVisuals() {
            super("No Potion Visuals", "Remove cegueira e nausea visuais.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null) return;
            if (p.isPotionActive(Potion.blindness)) p.removePotionEffectClient(Potion.blindness.id);
            if (p.isPotionActive(Potion.confusion)) p.removePotionEffectClient(Potion.confusion.id);
        }
    }

    // ============================================================ visual
    static void box(double x0, double y0, double z0, double x1, double y1, double z1, int argb) {
        RenderUtil.begin();
        GL11.glLineWidth(1.6f);
        RenderUtil.color(argb);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(x0, y0, z0); GL11.glVertex3d(x1, y0, z0); GL11.glVertex3d(x1, y0, z1); GL11.glVertex3d(x0, y0, z1); GL11.glVertex3d(x0, y0, z0);
        GL11.glEnd();
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(x0, y1, z0); GL11.glVertex3d(x1, y1, z0); GL11.glVertex3d(x1, y1, z1); GL11.glVertex3d(x0, y1, z1); GL11.glVertex3d(x0, y1, z0);
        GL11.glEnd();
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(x0, y0, z0); GL11.glVertex3d(x0, y1, z0);
        GL11.glVertex3d(x1, y0, z0); GL11.glVertex3d(x1, y1, z0);
        GL11.glVertex3d(x1, y0, z1); GL11.glVertex3d(x1, y1, z1);
        GL11.glVertex3d(x0, y0, z1); GL11.glVertex3d(x0, y1, z1);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        RenderUtil.end();
    }

    static void entBox(Entity e, float pt, double cx, double cy, double cz, int col) {
        double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - cx;
        double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - cy;
        double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - cz;
        double w = e.width / 2.0;
        box(x - w, y, z - w, x + w, y + e.height, z + w, col);
    }

    public static class MobEsp extends Module {
        final Setting hostile = add(Setting.color("Hostis", 0xFFFF4040));
        final Setting passive = add(Setting.color("Animais", 0xFF40FF70));
        final Setting range = add(Setting.number("Alcance", 48, 8, 128, 4));

        public MobEsp() {
            super("Mob ESP", "Caixas em monstros e animais.", Category.VISUAL);
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null || mc.thePlayer == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            for (Object o : mc.theWorld.loadedEntityList) {
                if (!(o instanceof EntityMob) && !(o instanceof EntityAnimal)) continue;
                Entity e = (Entity) o;
                if (e.getDistanceToEntity(mc.thePlayer) > range.num) continue;
                entBox(e, pt, cx, cy, cz, o instanceof EntityMob ? hostile.c() : passive.c());
            }
        }
    }

    public static class ItemEsp extends Module {
        final Setting color = add(Setting.color("Color", 0xFFFFD040));
        final Setting names = add(Setting.toggle("Nomes", true));

        public ItemEsp() {
            super("Item ESP", "Destaca itens largados no chao.", Category.VISUAL);
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null || mc.thePlayer == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            for (Object o : mc.theWorld.loadedEntityList) {
                if (!(o instanceof EntityItem)) continue;
                EntityItem e = (EntityItem) o;
                if (e.getDistanceToEntity(mc.thePlayer) > 64f) continue;
                double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - cx;
                double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - cy;
                double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - cz;
                box(x - 0.2, y, z - 0.2, x + 0.2, y + 0.4, z + 0.2, color.c());
                if (names.b() && e.getEntityItem() != null) {
                    RenderUtil.worldText(e.getEntityItem().getDisplayName() + " x" + e.getEntityItem().stackSize, x, y + 0.8, z, 0.025f, 0xFFFFFFFF);
                }
            }
        }
    }

    public static class Radar extends Module {
        final Setting size = add(Setting.number("Tamanho", 50, 30, 90, 5));
        final Setting range = add(Setting.number("Alcance", 40, 10, 100, 5));

        public Radar() {
            super("Radar", "Mini-mapa com jogadores proximos.", Category.VISUAL);
        }

        @Override
        public void renderOverlay(ScaledResolution sr, float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null || mc.theWorld == null) return;
            float r = size.f();
            float cx = sr.getScaledWidth() - r - 8, cy = sr.getScaledHeight() - r - 8;
            RenderUtil.circle(cx, cy, r, 0x88000000);
            RenderUtil.line(cx - r, cy, cx + r, cy, 1f, 0x44FFFFFF);
            RenderUtil.line(cx, cy - r, cx, cy + r, 1f, 0x44FFFFFF);
            RenderUtil.circle(cx, cy, 2f, 0xFF40A0FF);
            double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            for (Object o : mc.theWorld.playerEntities) {
                EntityPlayer e = (EntityPlayer) o;
                if (e == mc.thePlayer) continue;
                double dx = e.posX - mc.thePlayer.posX, dz = e.posZ - mc.thePlayer.posZ;
                double rx = -(dx * cos + dz * sin), rz = -(dz * cos - dx * sin);
                double k = r / range.num;
                double px = rx * k, pz = rz * k;
                double d = Math.sqrt(px * px + pz * pz);
                if (d > r - 3) { px *= (r - 3) / d; pz *= (r - 3) / d; }
                RenderUtil.circle(cx + (float) px, cy + (float) pz, 2.2f, 0xFFFF4040);
            }
        }
    }

    public static class LowHealthWarning extends Module {
        public LowHealthWarning() {
            super("Low Health Warning", "Borda vermelha pulsando com vida baixa.", Category.VISUAL);
        }

        @Override
        public void renderOverlay(ScaledResolution sr, float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null || mc.thePlayer.getHealth() > 6f) return;
            float a = 0.25f + 0.2f * (float) Math.sin(System.currentTimeMillis() / 180.0);
            int w = sr.getScaledWidth(), h = sr.getScaledHeight();
            int c = RenderUtil.alpha(0xFFFF0000, a);
            int c0 = RenderUtil.alpha(0xFFFF0000, 0f);
            RenderUtil.gradV(0, 0, w, 40, c, c0);
            RenderUtil.gradV(0, h - 40, w, h, c0, c);
        }
    }

    public static class Waypoint extends Module {
        double x, y, z;
        final Setting color = add(Setting.color("Color", 0xFF40D0FF));

        public Waypoint() {
            super("Waypoint", "Marca o local onde voce ligou o modulo.", Category.VISUAL);
        }

        @Override
        public void onEnable() {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) { x = mc.thePlayer.posX; y = mc.thePlayer.posY; z = mc.thePlayer.posZ; }
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null) return;
            double rx = x - RenderUtil.camX(pt), ry = y - RenderUtil.camY(pt), rz = z - RenderUtil.camZ(pt);
            double d = Math.sqrt((x - mc.thePlayer.posX) * (x - mc.thePlayer.posX) + (z - mc.thePlayer.posZ) * (z - mc.thePlayer.posZ));
            box(rx - 0.3, ry, rz - 0.3, rx + 0.3, ry + 2.0, rz + 0.3, color.c());
            RenderUtil.worldText("Waypoint " + (int) d + "m", rx, ry + 2.6, rz, 0.04f, color.c());
        }
    }

    public static class MoveTrail extends Module {
        final List<double[]> pts = new ArrayList<double[]>();
        final Setting len = add(Setting.number("Tamanho", 40, 10, 120, 5));
        final Setting color = add(Setting.color("Color", 0));

        public MoveTrail() {
            super("Move Trail", "Rastro colorido atras de voce.", Category.VISUAL);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null) return;
            pts.add(new double[]{mc.thePlayer.posX, mc.thePlayer.posY + 0.1, mc.thePlayer.posZ});
            while (pts.size() > len.i()) pts.remove(0);
        }

        @Override
        public void renderWorld(float pt) {
            if (pts.size() < 2) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            RenderUtil.begin();
            GL11.glLineWidth(3f);
            GL11.glBegin(GL11.GL_LINE_STRIP);
            int n = pts.size();
            for (int k = 0; k < n; k++) {
                double[] q = pts.get(k);
                int c = color.color == 0 ? RenderUtil.rainbow(k * 0.03f) : color.c();
                RenderUtil.color(RenderUtil.alpha(c, (float) k / n));
                GL11.glVertex3d(q[0] - cx, q[1] - cy, q[2] - cz);
            }
            GL11.glEnd();
            RenderUtil.end();
        }
    }

    public static class ScreenSnow extends Module {
        final Setting count = add(Setting.number("Flocos", 60, 10, 200, 10));

        public ScreenSnow() {
            super("Screen Snow", "Neve caindo na tela.", Category.VISUAL);
        }

        @Override
        public void renderOverlay(ScaledResolution sr, float pt) {
            float t = System.currentTimeMillis() / 1000f;
            int w = sr.getScaledWidth(), h = sr.getScaledHeight();
            for (int k = 0; k < count.i(); k++) {
                float sx = ((k * 7919) % 1000) / 1000f;
                float sp = 18f + (k * 31) % 40;
                float y = (t * sp + (k * 53) % h) % h;
                float x = (sx * w + (float) Math.sin(t * 0.8f + k) * 12f + w) % w;
                RenderUtil.circle(x, y, 1f + (k % 3) * 0.6f, 0xCCFFFFFF);
            }
        }
    }

    // ============================================================ utility / world
    public static class CopyCoords extends Module {
        public CopyCoords() {
            super("Copy Coords", "Copia suas coordenadas (liga e desliga sozinho).", Category.UTILITY);
        }

        @Override
        public void onEnable() {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) {
                GuiScreen.setClipboardString((int) mc.thePlayer.posX + " " + (int) mc.thePlayer.posY + " " + (int) mc.thePlayer.posZ);
                mc.thePlayer.addChatMessage(new ChatComponentText("§7[Larp] Coordenadas copiadas."));
            }
            enabled = false;
        }
    }

    public static class ClearChat extends Module {
        public ClearChat() {
            super("Clear Chat", "Limpa o chat (liga e desliga sozinho).", Category.UTILITY);
        }

        @Override
        public void onEnable() {
            Minecraft mc = Minecraft.getMinecraft();
            mc.ingameGUI.getChatGUI().clearChatMessages();
            enabled = false;
        }
    }

    public static class AutoLog extends Module {
        final Setting hp = add(Setting.number("Vida minima", 4, 1, 15, 1));

        public AutoLog() {
            super("Auto Log", "Sai do servidor com vida baixa.", Category.UTILITY);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null || mc.theWorld == null || mc.isIntegratedServerRunning()) return;
            if (p.getHealth() > 0 && p.getHealth() <= hp.num) {
                enabled = false;
                mc.theWorld.sendQuittingDisconnectingPacket();
                mc.loadWorld(null);
                mc.displayGuiScreen(new GuiMainMenu());
            }
        }
    }

    public static class FpsBoost extends Module {
        boolean fancy, shadows;
        int part;

        public FpsBoost() {
            super("FPS Boost", "Reduz graficos para ganhar FPS.", Category.UTILITY);
        }

        @Override
        public void onEnable() {
            Minecraft mc = Minecraft.getMinecraft();
            fancy = mc.gameSettings.fancyGraphics;
            shadows = mc.gameSettings.entityShadows;
            part = mc.gameSettings.particleSetting;
            mc.gameSettings.fancyGraphics = false;
            mc.gameSettings.entityShadows = false;
            mc.gameSettings.particleSetting = 2;
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            mc.gameSettings.fancyGraphics = fancy;
            mc.gameSettings.entityShadows = shadows;
            mc.gameSettings.particleSetting = part;
        }
    }

    public static class BreakReminder extends Module {
        final Setting mins = add(Setting.number("Minutos", 30, 5, 120, 5));
        long last;

        public BreakReminder() {
            super("Break Reminder", "Lembra de fazer pausas.", Category.UTILITY);
        }

        @Override
        public void onEnable() { last = System.currentTimeMillis(); }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null) return;
            if (System.currentTimeMillis() - last > mins.num * 60000.0) {
                last = System.currentTimeMillis();
                mc.thePlayer.addChatMessage(new ChatComponentText("§e[Larp] Hora de uma pausa!"));
            }
        }
    }

    public static class NoWeatherSounds extends Module {
        public NoWeatherSounds() {
            super("Rain Off", "Para a chuva so para voce.", Category.WORLD);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.theWorld != null) {
                mc.theWorld.setRainStrength(0f);
                mc.theWorld.setThunderStrength(0f);
            }
        }
    }
}
