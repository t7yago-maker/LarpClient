package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.opengl.GL11;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Locale;

/** Pacote "hacker": movimento, render (ESP) e utilidades de jogador. */
public final class HackModules {
    private HackModules() {}

    public static void register(List<Module> l) {
        l.add(new Speed());
        l.add(new Fly());
        l.add(new NoFall());
        l.add(new Step());
        l.add(new TimerHack());
        l.add(new AirJump());
        l.add(new Esp());
        l.add(new Tracers());
        l.add(new Nametags());
        l.add(new ChestEsp());
        l.add(new AutoArmor());
        l.add(new ChestStealer());
        l.add(new AutoTool());
        l.add(new FastBreak());
        l.add(new AutoGG());
        l.add(new AutoRespawn());
    }

    static boolean moving(Minecraft mc) {
        return mc.thePlayer.movementInput.moveForward != 0f || mc.thePlayer.movementInput.moveStrafe != 0f;
    }

    static void setSpeed(Minecraft mc, double sp) {
        net.minecraft.client.entity.EntityPlayerSP p = mc.thePlayer;
        float f = p.movementInput.moveForward, s = p.movementInput.moveStrafe;
        if (f == 0f && s == 0f) {
            p.motionX = 0;
            p.motionZ = 0;
            return;
        }
        double yaw = Math.toRadians(p.rotationYaw);
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        p.motionX = dx / len * sp;
        p.motionZ = dz / len * sp;
    }

    // ----------------------------------------------------------------- MOVIMENTO
    public static class Speed extends Module {
        final Setting speed = add(Setting.number("Speed", 0.36, 0.2, 1.0, 0.01));
        final Setting bhop = add(Setting.toggle("Bunny Hop", true));

        public Speed() {
            super("Speed", "Corre muito mais rapido (com bunny hop opcional).", Category.MOVEMENT);
            note = "Cheat. Anti-cheats detectam.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null || !moving(mc)) return;
            EntityPlayer p = mc.thePlayer;
            if (bhop.b() && p.onGround) p.jump();
            if (!p.isInWater() && !p.isOnLadder()) setSpeed(mc, speed.num);
        }
    }

    public static class Fly extends Module {
        final Setting speed = add(Setting.number("Speed", 0.9, 0.1, 3.0, 0.05));
        final Setting vspeed = add(Setting.number("Vertical", 0.6, 0.1, 2.0, 0.05));

        public Fly() {
            super("Fly", "Voar (espaco sobe, shift desce).", Category.MOVEMENT);
            note = "Cheat. Em servidor com anti-cheat = ban/kick.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null) return;
            EntityPlayer p = mc.thePlayer;
            p.motionY = 0;
            if (mc.gameSettings.keyBindJump.isKeyDown()) p.motionY = vspeed.num;
            if (mc.gameSettings.keyBindSneak.isKeyDown()) p.motionY = -vspeed.num;
            setSpeed(mc, speed.num);
            p.fallDistance = 0f;
        }
    }

    public static class NoFall extends Module {
        public NoFall() {
            super("NoFall", "Cancela o dano de queda.", Category.MOVEMENT);
            note = "Cheat. Anti-cheats detectam.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null) return;
            if (mc.thePlayer.fallDistance > 2.4f && !mc.thePlayer.onGround) {
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
                mc.thePlayer.fallDistance = 0f;
            }
        }
    }

    public static class Step extends Module {
        final Setting height = add(Setting.number("Height", 1.0, 0.6, 2.5, 0.1));

        public Step() {
            super("Step", "Sobe blocos sem pular.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer != null) mc.thePlayer.stepHeight = height.f();
        }

        @Override
        public void onDisable() {
            if (Minecraft.getMinecraft().thePlayer != null) Minecraft.getMinecraft().thePlayer.stepHeight = 0.6f;
        }
    }

    public static class TimerHack extends Module {
        final Setting speed = add(Setting.number("Timer", 1.4, 0.3, 4.0, 0.1));
        private Field tf, sf;

        public TimerHack() {
            super("Timer", "Acelera (ou desacelera) o jogo todo.", Category.MOVEMENT);
            note = "Cheat. Anti-cheats detectam.";
        }

        private void set(Minecraft mc, float v) {
            try {
                if (tf == null) {
                    tf = ReflectionHelper.findField(Minecraft.class, "timer", "field_71428_T");
                    tf.setAccessible(true);
                    sf = ReflectionHelper.findField(net.minecraft.util.Timer.class, "timerSpeed", "field_74278_d");
                    sf.setAccessible(true);
                }
                sf.setFloat(tf.get(mc), v);
            } catch (Throwable ignored) {
            }
        }

        @Override
        public void onFrame(Minecraft mc, float dt) {
            set(mc, speed.f());
        }

        @Override
        public void onDisable() {
            set(Minecraft.getMinecraft(), 1f);
        }
    }

    public static class AirJump extends Module {
        private int cd;

        public AirJump() {
            super("Infinite Jump", "Pula de novo no ar.", Category.MOVEMENT);
            note = "Cheat.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null) return;
            if (cd > 0) cd--;
            if (mc.gameSettings.keyBindJump.isKeyDown() && !mc.thePlayer.onGround && cd == 0) {
                mc.thePlayer.motionY = 0.42;
                cd = 6;
            }
        }
    }

    // ----------------------------------------------------------------- RENDER
    static void fillBox(AxisAlignedBB b, int col, float a) {
        RenderUtil.color(RenderUtil.alpha(col, a));
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex3d(b.minX, b.minY, b.minZ); GL11.glVertex3d(b.maxX, b.minY, b.minZ); GL11.glVertex3d(b.maxX, b.minY, b.maxZ); GL11.glVertex3d(b.minX, b.minY, b.maxZ);
        GL11.glVertex3d(b.minX, b.maxY, b.minZ); GL11.glVertex3d(b.maxX, b.maxY, b.minZ); GL11.glVertex3d(b.maxX, b.maxY, b.maxZ); GL11.glVertex3d(b.minX, b.maxY, b.maxZ);
        GL11.glVertex3d(b.minX, b.minY, b.minZ); GL11.glVertex3d(b.maxX, b.minY, b.minZ); GL11.glVertex3d(b.maxX, b.maxY, b.minZ); GL11.glVertex3d(b.minX, b.maxY, b.minZ);
        GL11.glVertex3d(b.minX, b.minY, b.maxZ); GL11.glVertex3d(b.maxX, b.minY, b.maxZ); GL11.glVertex3d(b.maxX, b.maxY, b.maxZ); GL11.glVertex3d(b.minX, b.maxY, b.maxZ);
        GL11.glVertex3d(b.minX, b.minY, b.minZ); GL11.glVertex3d(b.minX, b.minY, b.maxZ); GL11.glVertex3d(b.minX, b.maxY, b.maxZ); GL11.glVertex3d(b.minX, b.maxY, b.minZ);
        GL11.glVertex3d(b.maxX, b.minY, b.minZ); GL11.glVertex3d(b.maxX, b.minY, b.maxZ); GL11.glVertex3d(b.maxX, b.maxY, b.maxZ); GL11.glVertex3d(b.maxX, b.maxY, b.minZ);
        GL11.glEnd();
    }

    static int healthColor(EntityLivingBase e) {
        float p = Math.max(0f, Math.min(1f, e.getHealth() / Math.max(1f, e.getMaxHealth())));
        return RenderUtil.mix(0xFFFF2020, 0xFF30FF50, p);
    }

    static AxisAlignedBB rel(Entity e, float pt, double cx, double cy, double cz) {
        double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - cx;
        double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - cy;
        double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - cz;
        double hw = e.width / 2.0 + 0.05;
        return new AxisAlignedBB(x - hw, y, z - hw, x + hw, y + e.height + 0.05, z + hw);
    }

    static boolean target(Entity e, Minecraft mc, boolean players, boolean mobs) {
        if (e == mc.thePlayer || !(e instanceof EntityLivingBase) || !e.isEntityAlive()) return false;
        if (e instanceof EntityPlayer) return players;
        return mobs && e instanceof net.minecraft.entity.EntityLiving;
    }

    public static class Esp extends Module {
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", false));
        final Setting fill = add(Setting.toggle("Fill", true));
        final Setting hp = add(Setting.toggle("Health Color", false));
        final Setting color = add(Setting.color("Color", 0xFFFF2D55));

        public Esp() {
            super("ESP", "Caixas coloridas em volta dos alvos, visiveis atras de paredes.", Category.RENDER);
            note = "Cheat visual. Proibido em muitos servidores.";
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            RenderUtil.begin();
            GlStateManager.disableDepth();
            GlStateManager.disableCull();
            GL11.glLineWidth(2f);
            for (Object o : mc.theWorld.loadedEntityList) {
                Entity e = (Entity) o;
                if (!target(e, mc, players.b(), mobs.b())) continue;
                int col = hp.b() ? healthColor((EntityLivingBase) e) : color.c();
                AxisAlignedBB b = rel(e, pt, cx, cy, cz);
                if (fill.b()) fillBox(b, col, 0.22f);
                RenderUtil.color(col);
                net.minecraft.client.renderer.RenderGlobal.drawOutlinedBoundingBox(b, (col >> 16) & 255, (col >> 8) & 255, col & 255, 255);
            }
            GlStateManager.enableDepth();
            GlStateManager.enableCull();
            RenderUtil.end();
        }
    }

    public static class Tracers extends Module {
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", false));
        final Setting color = add(Setting.color("Color", 0xFF00E5FF));
        final Setting width = add(Setting.number("Width", 1.5, 1, 4, 0.5));

        public Tracers() {
            super("Tracers", "Linhas da sua mira ate cada alvo.", Category.RENDER);
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null || mc.thePlayer == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            net.minecraft.util.Vec3 look = mc.getRenderViewEntity().getLook(pt);
            RenderUtil.begin();
            GlStateManager.disableDepth();
            GL11.glLineWidth(width.f());
            for (Object o : mc.theWorld.loadedEntityList) {
                Entity e = (Entity) o;
                if (!target(e, mc, players.b(), mobs.b())) continue;
                AxisAlignedBB b = rel(e, pt, cx, cy, cz);
                RenderUtil.color(color.c());
                GL11.glBegin(GL11.GL_LINES);
                GL11.glVertex3d(look.xCoord * 0.3, look.yCoord * 0.3, look.zCoord * 0.3);
                GL11.glVertex3d((b.minX + b.maxX) / 2, (b.minY + b.maxY) / 2, (b.minZ + b.maxZ) / 2);
                GL11.glEnd();
            }
            GlStateManager.enableDepth();
            RenderUtil.end();
        }
    }

    public static class Nametags extends Module {
        final Setting size = add(Setting.number("Size", 1.0, 0.5, 2.5, 0.1));
        final Setting dist = add(Setting.toggle("Distance", true));

        public Nametags() {
            super("Nametags", "Nome + vida + distancia grandes, visiveis atras de paredes.", Category.RENDER);
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null || mc.thePlayer == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            for (Object o : mc.theWorld.loadedEntityList) {
                if (!(o instanceof EntityPlayer) || o == mc.thePlayer || !((EntityPlayer) o).isEntityAlive()) continue;
                EntityPlayer e = (EntityPlayer) o;
                double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - cx;
                double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - cy + e.height + 0.55;
                double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - cz;
                float d = mc.thePlayer.getDistanceToEntity(e);
                float sc = 0.018f * size.f() * Math.max(1f, d / 5f);
                String t = e.getName() + " §" + (e.getHealth() > 10 ? "a" : (e.getHealth() > 5 ? "e" : "c")) + String.format(Locale.US, "%.1f", e.getHealth() + e.getAbsorptionAmount())
                        + (dist.b() ? " §7" + (int) d + "m" : "");
                RenderUtil.worldText(t, x, y, z, sc, 0xFFFFFFFF);
            }
        }
    }

    public static class ChestEsp extends Module {
        final Setting color = add(Setting.color("Color", 0xFFFFC830));
        final Setting ender = add(Setting.toggle("Ender Chests", true));

        public ChestEsp() {
            super("Chest ESP", "Mostra baus atras de paredes.", Category.RENDER);
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            RenderUtil.begin();
            GlStateManager.disableDepth();
            GL11.glLineWidth(2f);
            for (Object o : mc.theWorld.loadedTileEntityList) {
                TileEntity te = (TileEntity) o;
                boolean ch = te instanceof TileEntityChest;
                if (!ch && !(ender.b() && te instanceof TileEntityEnderChest)) continue;
                BlockPos bp = te.getPos();
                int col = ch ? color.c() : 0xFFB050FF;
                AxisAlignedBB b = new AxisAlignedBB(bp.getX() + 0.06 - cx, bp.getY() - cy, bp.getZ() + 0.06 - cz, bp.getX() + 0.94 - cx, bp.getY() + 0.88 - cy, bp.getZ() + 0.94 - cz);
                fillBox(b, col, 0.2f);
                RenderUtil.color(col);
                net.minecraft.client.renderer.RenderGlobal.drawOutlinedBoundingBox(b, (col >> 16) & 255, (col >> 8) & 255, col & 255, 255);
            }
            GlStateManager.enableDepth();
            RenderUtil.end();
        }
    }

    // ----------------------------------------------------------------- JOGADOR
    public static class AutoArmor extends Module {
        final Setting delay = add(Setting.number("Delay (ticks)", 4, 1, 20, 1));
        private int cd;

        public AutoArmor() {
            super("Auto Armor", "Equipa sozinho a melhor armadura do inventario.", Category.PLAYER);
        }

        private float val(ItemStack s) {
            if (s == null || !(s.getItem() instanceof ItemArmor)) return -1f;
            return ((ItemArmor) s.getItem()).damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, s) * 0.5f;
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || (mc.currentScreen != null && !(mc.currentScreen instanceof net.minecraft.client.gui.inventory.GuiInventory))) return;
            if (--cd > 0) return;
            cd = delay.i();
            EntityPlayer p = mc.thePlayer;
            for (int type = 0; type < 4; type++) {
                ItemStack cur = p.inventory.armorInventory[3 - type];
                float cv = val(cur);
                int bestJ = -1;
                float bv = cv;
                for (int j = 0; j < 36; j++) {
                    ItemStack s = p.inventory.mainInventory[j];
                    if (s == null || !(s.getItem() instanceof ItemArmor) || ((ItemArmor) s.getItem()).armorType != type) continue;
                    if (val(s) > bv) {
                        bv = val(s);
                        bestJ = j;
                    }
                }
                if (bestJ < 0) continue;
                if (cur != null) {
                    mc.playerController.windowClick(0, 5 + type, 0, 1, p);
                } else {
                    mc.playerController.windowClick(0, bestJ < 9 ? 36 + bestJ : bestJ, 0, 1, p);
                }
                return;
            }
        }
    }

    public static class ChestStealer extends Module {
        final Setting delay = add(Setting.number("Delay (ticks)", 2, 0, 10, 1));
        final Setting close = add(Setting.toggle("Auto Close", true));
        private int cd;

        public ChestStealer() {
            super("Chest Stealer", "Pega tudo do bau assim que abre.", Category.PLAYER);
            note = "Cheat. Proibido em muitos servidores.";
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || !(mc.currentScreen instanceof GuiChest) || !(mc.thePlayer.openContainer instanceof ContainerChest)) {
                cd = 3;
                return;
            }
            if (cd-- > 0) return;
            ContainerChest c = (ContainerChest) mc.thePlayer.openContainer;
            int n = c.getLowerChestInventory().getSizeInventory();
            for (int i = 0; i < n; i++) {
                if (c.getSlot(i).getHasStack()) {
                    mc.playerController.windowClick(c.windowId, i, 0, 1, mc.thePlayer);
                    cd = delay.i();
                    return;
                }
            }
            if (close.b()) mc.thePlayer.closeScreen();
        }
    }

    public static class AutoTool extends Module {
        public AutoTool() {
            super("Auto Tool", "Troca para a melhor ferramenta ao minerar.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null || !mc.gameSettings.keyBindAttack.isKeyDown()) return;
            MovingObjectPosition m = mc.objectMouseOver;
            if (m == null || m.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) return;
            Block b = mc.theWorld.getBlockState(m.getBlockPos()).getBlock();
            EntityPlayer p = mc.thePlayer;
            int best = p.inventory.currentItem;
            float bs = 1f;
            ItemStack h = p.getHeldItem();
            if (h != null) bs = h.getStrVsBlock(b);
            for (int i = 0; i < 9; i++) {
                ItemStack s = p.inventory.mainInventory[i];
                if (s != null && s.getStrVsBlock(b) > bs) {
                    bs = s.getStrVsBlock(b);
                    best = i;
                }
            }
            p.inventory.currentItem = best;
        }
    }

    public static class FastBreak extends Module {
        final Setting boost = add(Setting.number("Boost", 0.15, 0.0, 0.6, 0.05));
        private Field delayF, dmgF;

        public FastBreak() {
            super("Fast Break", "Quebra blocos mais rapido (sem atraso + dano extra).", Category.PLAYER);
            note = "Cheat. Anti-cheats detectam.";
        }

        @Override
        public void onTick(Minecraft mc) {
            try {
                if (delayF == null) {
                    delayF = ReflectionHelper.findField(PlayerControllerMP.class, "blockHitDelay", "field_78781_i");
                    delayF.setAccessible(true);
                    dmgF = ReflectionHelper.findField(PlayerControllerMP.class, "curBlockDamageMP", "field_78770_f");
                    dmgF.setAccessible(true);
                }
                delayF.setInt(mc.playerController, 0);
                float cur = dmgF.getFloat(mc.playerController);
                if (cur > 0f && cur < 1f) dmgF.setFloat(mc.playerController, Math.min(0.99f, cur + boost.f()));
            } catch (Throwable ignored) {
            }
        }
    }

    public static class AutoGG extends Module {
        final Setting msg = add(Setting.choice("Message", 0, "gg", "GG", "gg ez", "good game"));
        private long last;

        public AutoGG() {
            super("Auto GG", "Manda GG no chat quando o jogo termina.", Category.PLAYER);
        }

        @Override
        public void onChat(String m) {
            String l = m.toLowerCase();
            if (System.currentTimeMillis() - last < 15000L) return;
            if (l.contains("winner") || l.contains("venceu") || l.contains("won the game") || l.contains("vencedor") || l.contains("1st killer")) {
                last = System.currentTimeMillis();
                Minecraft mc = Minecraft.getMinecraft();
                if (mc.thePlayer != null) mc.thePlayer.sendChatMessage(msg.m());
            }
        }
    }

    public static class AutoRespawn extends Module {
        public AutoRespawn() {
            super("Auto Respawn", "Renasce sozinho ao morrer.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer != null && mc.thePlayer.getHealth() <= 0f) mc.thePlayer.respawnPlayer();
        }
    }
}
