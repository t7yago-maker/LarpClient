package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.core.Stats;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CombatModules {
    private CombatModules() {}

    public static void register(List<Module> l) {
        l.add(new Hitboxes());
        l.add(new HitIndicator());
        l.add(new DamageIndicator());
    }

    public static class Hitboxes extends Module {
        final Setting color = add(Setting.color("Hitbox Color", 0xFF00E5FF));
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", false));
        final Setting eye = add(Setting.toggle("Eye Line", true));
        final Setting through = add(Setting.toggle("See Through", true));
        final Setting width = add(Setting.number("Line Width", 2, 1, 5, 0.5));

        public Hitboxes() {
            super("Hitboxes", "Mostra a caixa de colisao dos jogadores.", Category.COMBAT);
            note = "Visual local. Alguns servidores podem proibir.";
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null) return;
            int col = color.c();
            int r = (col >> 16) & 255, g = (col >> 8) & 255, b = col & 255;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            RenderUtil.begin();
            GlStateManager.disableCull();
            GL11.glLineWidth(width.f());
            if (through.b()) GlStateManager.disableDepth();
            for (Object o : mc.theWorld.loadedEntityList) {
                Entity e = (Entity) o;
                if (e == mc.thePlayer && mc.gameSettings.thirdPersonView == 0) continue;
                boolean ok = (e instanceof EntityPlayer && players.b()) || (e instanceof EntityLiving && mobs.b());
                if (!ok) continue;
                double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - cx;
                double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - cy;
                double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - cz;
                double hw = e.width / 2.0;
                AxisAlignedBB bb = new AxisAlignedBB(x - hw, y, z - hw, x + hw, y + e.height, z + hw);
                RenderGlobal.drawOutlinedBoundingBox(bb, r, g, b, 255);
                if (eye.b() && e instanceof EntityLivingBase) {
                    Vec3 look = e.getLook(pt);
                    double ey = y + e.getEyeHeight();
                    net.minecraft.client.renderer.GlStateManager.color(1f, 0.15f, 0.15f, 1f);
                    GL11.glBegin(GL11.GL_LINES);
                    GL11.glVertex3d(x, ey, z);
                    GL11.glVertex3d(x + look.xCoord * 2.0, ey + look.yCoord * 2.0, z + look.zCoord * 2.0);
                    GL11.glEnd();
                }
            }
            GlStateManager.enableDepth();
            GlStateManager.enableCull();
            RenderUtil.end();
        }
    }

    public static class HitIndicator extends Module {
        final Setting color = add(Setting.color("Color", 0xFFFFFFFF));
        final Setting dur = add(Setting.number("Duration (ms)", 300, 100, 1000, 50));
        private long t;

        public HitIndicator() {
            super("Hit Indicator", "Marcador no centro da tela ao acertar um golpe.", Category.COMBAT);
        }

        @Override
        public void onAttack(Entity target) {
            t = System.currentTimeMillis();
        }

        @Override
        public void renderOverlay(ScaledResolution sr, float pt) {
            long d = System.currentTimeMillis() - t;
            if (d > dur.f()) return;
            float p = d / dur.f();
            float cx = sr.getScaledWidth() / 2f, cy = sr.getScaledHeight() / 2f;
            float g = 3f + p * 6f, len = 5f * (1f - p * 0.5f);
            int c = color.c();
            RenderUtil.alphaMul = 1f - p;
            try {
                RenderUtil.line(cx - g, cy - g, cx - g - len, cy - g - len, 2f, c);
                RenderUtil.line(cx + g, cy - g, cx + g + len, cy - g - len, 2f, c);
                RenderUtil.line(cx - g, cy + g, cx - g - len, cy + g + len, 2f, c);
                RenderUtil.line(cx + g, cy + g, cx + g + len, cy + g + len, 2f, c);
            } finally {
                RenderUtil.alphaMul = 1f;
            }
        }
    }

    public static class DamageIndicator extends Module {
        final Setting color = add(Setting.color("Color", 0xFFFF4040));
        final Setting size = add(Setting.number("Size", 0.03, 0.015, 0.06, 0.005));

        private static class Pop {
            double x, y, z;
            String s;
            long t;
        }

        private final List<Pop> pops = new ArrayList<Pop>();
        private EntityLivingBase tgt;
        private float lastHp;

        public DamageIndicator() {
            super("Damage Indicator", "Numeros flutuantes com o dano causado.", Category.COMBAT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityLivingBase t = Stats.target;
            if (t == null || !t.isEntityAlive()) {
                tgt = null;
            } else if (t != tgt) {
                tgt = t;
                lastHp = t.getHealth();
            } else {
                float hp = t.getHealth();
                if (hp < lastHp - 0.01f) {
                    Pop p = new Pop();
                    p.x = t.posX;
                    p.y = t.posY + t.height + 0.3;
                    p.z = t.posZ;
                    p.s = String.format(Locale.US, "-%.1f", lastHp - hp);
                    p.t = System.currentTimeMillis();
                    pops.add(p);
                }
                lastHp = hp;
            }
            long now = System.currentTimeMillis();
            for (int i = pops.size() - 1; i >= 0; i--) {
                if (now - pops.get(i).t > 1300L) pops.remove(i);
            }
        }

        @Override
        public void renderWorld(float pt) {
            if (pops.isEmpty()) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            long now = System.currentTimeMillis();
            int base = color.c();
            for (Pop p : pops) {
                float age = (now - p.t) / 1000f;
                float a = Math.max(0.05f, 1f - age / 1.3f);
                int col = RenderUtil.alpha(base, a);
                if (((col >>> 24) & 255) < 8) continue;
                RenderUtil.worldText(p.s, p.x - cx, p.y + age * 0.7 - cy, p.z - cz, size.f(), col);
            }
        }
    }
}
