package com.larpclient.modules;

import com.larpclient.LarpClient;
import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MathHelper;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;
import java.util.List;

public final class PlayerModules {
    private PlayerModules() {}

    public static void register(List<Module> l) {
        l.add(new AutoSprint());
        l.add(new Zoom());
        l.add(new Fullbright());
        l.add(new NoFire());
        l.add(new Perspective());
        l.add(new FastDrop());
        l.add(new FastPlace());
        l.add(new ChatTime());
        l.add(new ToggleSneak());
    }

    // ---------------------------------------------------------------------
    //  Perspective: segure Q para olhar em volta sem mudar a mira real
    // ---------------------------------------------------------------------
    public static class Perspective extends Module {
        final Setting view = add(Setting.choice("View", 0, "Behind", "Front"));
        private boolean active, applied;
        private float camYaw, camPitch, lockYaw, lockPitch, appYaw, appPitch;
        private int savedView;

        public Perspective() {
            super("Perspective", "Segure Q: camera livre em 3a pessoa. Ao soltar, a mira volta como estava.", Category.PLAYER);
            enabled = true;
        }

        private static void setRot(EntityPlayer p, float y, float pt) {
            p.rotationYaw = y;
            p.prevRotationYaw = y;
            p.rotationPitch = pt;
            p.prevRotationPitch = pt;
        }

        private void absorb(EntityPlayer p) {
            if (applied) {
                camYaw += p.rotationYaw - appYaw;
                camPitch += p.rotationPitch - appPitch;
                applied = false;
            }
        }

        private boolean held(Minecraft mc) {
            return LarpClient.perspectiveKey != null && LarpClient.perspectiveKey.isKeyDown() && mc.currentScreen == null;
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (!active || mc.thePlayer == null) return;
            absorb(mc.thePlayer);
            setRot(mc.thePlayer, lockYaw, lockPitch);
        }

        @Override
        public void onTick(Minecraft mc) {
            // Q e a tecla padrao de soltar item: move o "drop" para F para nao conflitar.
            if (LarpClient.perspectiveKey != null
                    && mc.gameSettings.keyBindDrop.getKeyCode() == LarpClient.perspectiveKey.getKeyCode()) {
                mc.gameSettings.keyBindDrop.setKeyCode(Keyboard.KEY_F);
                KeyBinding.resetKeyBindingArrayAndHash();
                mc.gameSettings.saveOptions();
            }
        }

        @Override
        public void onFrame(Minecraft mc, float dt) {
            EntityPlayer p = mc.thePlayer;
            if (p == null) return;
            boolean h = held(mc);
            if (h && !active) {
                active = true;
                applied = false;
                lockYaw = p.rotationYaw;
                lockPitch = p.rotationPitch;
                camYaw = lockYaw;
                camPitch = lockPitch;
                savedView = mc.gameSettings.thirdPersonView;
                mc.gameSettings.thirdPersonView = view.index == 1 ? 2 : 1;
            } else if (!h && active) {
                stop(mc);
            }
            if (active) {
                absorb(p);
                camPitch = MathHelper.clamp_float(camPitch, -90f, 90f);
                setRot(p, camYaw, camPitch);
                appYaw = camYaw;
                appPitch = camPitch;
                applied = true;
            }
        }

        private void stop(Minecraft mc) {
            if (mc.thePlayer != null) setRot(mc.thePlayer, lockYaw, lockPitch);
            mc.gameSettings.thirdPersonView = savedView;
            active = false;
            applied = false;
        }

        @Override
        public void onDisable() {
            if (active) stop(Minecraft.getMinecraft());
        }
    }

    // ---------------------------------------------------------------------
    //  Fast Drop: segurar a tecla de soltar (F) joga o stack inteiro, sem ficar clicando
    // ---------------------------------------------------------------------
    public static class FastDrop extends Module {
        final Setting delay = add(Setting.number("Hold delay (ticks)", 6, 2, 20, 1));
        final Setting interval = add(Setting.number("Interval (ticks)", 2, 1, 10, 1));
        final Setting cycle = add(Setting.toggle("Next slots (hotbar)", true));
        private int held;

        public FastDrop() {
            super("Fast Drop", "Segure a tecla de soltar (F): dropa o stack inteiro e vai passando pelos slots.", Category.PLAYER);
            enabled = true;
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayer p = mc.thePlayer;
            if (p == null || mc.currentScreen != null || !mc.gameSettings.keyBindDrop.isKeyDown()) {
                held = 0;
                return;
            }
            held++;
            if (held < delay.i() || (held - delay.i()) % interval.i() != 0) return;
            if (p.getHeldItem() == null && cycle.b()) {
                for (int i = 1; i <= 9; i++) {
                    int slot = (p.inventory.currentItem + i) % 9;
                    if (p.inventory.mainInventory[slot] != null) {
                        p.inventory.currentItem = slot;
                        break;
                    }
                }
            }
            if (p.getHeldItem() != null) p.dropOneItem(true);
        }
    }

    // ---------------------------------------------------------------------
    //  Fast Place: tira o atraso entre colocar blocos
    // ---------------------------------------------------------------------
    public static class FastPlace extends Module {
        private Field f;

        public FastPlace() {
            super("Fast Place", "Coloca blocos sem atraso ao segurar o botao direito.", Category.PLAYER);
            note = "Pode ser proibido em alguns servidores.";
        }

        @Override
        public void onTick(Minecraft mc) {
            try {
                if (f == null) {
                    f = ReflectionHelper.findField(Minecraft.class, "rightClickDelayTimer", "field_71467_ac");
                    f.setAccessible(true);
                }
                f.setInt(mc, 0);
            } catch (Throwable ignored) {
            }
        }
    }

    public static class ChatTime extends Module {
        public ChatTime() {
            super("Chat Timestamps", "Mostra a hora antes de cada mensagem do chat.", Category.PLAYER);
        }
    }

    public static class ToggleSneak extends Module {
        private boolean on, last;

        public ToggleSneak() {
            super("Toggle Sneak", "Aperte a tecla de agachar uma vez para ficar agachado.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null) return;
            int code = mc.gameSettings.keyBindSneak.getKeyCode();
            boolean down = code > 0 && Keyboard.isKeyDown(code);
            if (down && !last) on = !on;
            last = down;
            KeyBinding.setKeyBindState(code, on || down);
        }

        @Override
        public void onDisable() {
            on = false;
        }
    }

    public static class AutoSprint extends Module {
        public AutoSprint() {
            super("Auto Sprint", "Corre automaticamente ao andar para frente.", Category.PLAYER);
            note = "Alguns servidores restringem automacao de teclas.";
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null) return;
            if (mc.gameSettings.keyBindForward.isKeyDown() && !mc.thePlayer.isSneaking()
                    && !mc.thePlayer.isUsingItem() && !mc.thePlayer.isCollidedHorizontally
                    && mc.thePlayer.getFoodStats().getFoodLevel() > 6) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }

    public static class Zoom extends Module {
        final Setting level = add(Setting.number("Zoom Level", 0.25, 0.1, 0.8, 0.05));
        final Setting smooth = add(Setting.toggle("Smooth", true));
        public float cur = 1f;

        public Zoom() {
            super("Zoom", "Segure C para dar zoom.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            boolean hold = LarpClient.zoomKey != null && LarpClient.zoomKey.isKeyDown() && mc.currentScreen == null;
            float tgt = hold ? level.f() : 1f;
            cur = smooth.b() ? cur + (tgt - cur) * 0.35f : tgt;
        }

        @Override
        public void onDisable() {
            cur = 1f;
        }
    }

    public static class Fullbright extends Module {
        public Fullbright() {
            super("Fullbright", "Enxerga no escuro (efeito local).", Category.PLAYER);
            note = "Pode ser proibido em alguns servidores.";
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null) return;
            mc.thePlayer.addPotionEffect(new PotionEffect(Potion.nightVision.id, 1000, 0, false, false));
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) mc.thePlayer.removePotionEffectClient(Potion.nightVision.id);
        }
    }

    public static class NoFire extends Module {
        public NoFire() {
            super("Low Fire", "Remove o fogo que cobre a tela.", Category.PLAYER);
        }
    }
}
