package com.larpclient.modules;

import com.larpclient.LarpClient;
import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.List;

public final class PlayerModules {
    private PlayerModules() {}

    public static void register(List<Module> l) {
        l.add(new AutoSprint());
        l.add(new Zoom());
        l.add(new Fullbright());
        l.add(new NoFire());
    }

    public static class AutoSprint extends Module {
        public AutoSprint() {
            super("Auto Sprint", "Corre automaticamente ao andar para frente.", Category.PLAYER);
            note = "Alguns servidores restringem automacao de teclas.";
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null) return;
            if (mc.gameSettings.keyBindForward.isKeyDown() && !mc.thePlayer.isSneaking()
                    && !mc.thePlayer.isUsingItem() && !mc.thePlayer.isCollidedHorizontally
                    && mc.thePlayer.getFoodStats().getFoodLevel() > 6) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }

    public static class Zoom extends Module {
        final Setting level = add(Setting.number("Zoom Level", 0.25, 0.1, 0.8, 0.05));
        final Setting smooth = add(Setting.toggle("Smooth", true));
        public float cur = 1f;

        public Zoom() {
            super("Zoom", "Segure C para dar zoom.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            boolean hold = LarpClient.zoomKey != null && LarpClient.zoomKey.isKeyDown() && mc.currentScreen == null;
            float tgt = hold ? level.f() : 1f;
            cur = smooth.b() ? cur + (tgt - cur) * 0.35f : tgt;
        }

        @Override
        public void onDisable() {
            cur = 1f;
        }
    }

    public static class Fullbright extends Module {
        public Fullbright() {
            super("Fullbright", "Enxerga no escuro (efeito local).", Category.PLAYER);
            note = "Pode ser proibido em alguns servidores.";
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null) return;
            mc.thePlayer.addPotionEffect(new PotionEffect(Potion.nightVision.id, 1000, 0, false, false));
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer != null) mc.thePlayer.removePotionEffectClient(Potion.nightVision.id);
        }
    }

    public static class NoFire extends Module {
        public NoFire() {
            super("Low Fire", "Remove o fogo que cobre a tela.", Category.PLAYER);
        }
    }
}
