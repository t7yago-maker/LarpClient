package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.BlockPos;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Efeitos de chao: ondas ao pisar, chao customizado (neve que limpa e volta) e tinta de cor do mundo. */
public final class GroundModules {
    private GroundModules() {}

    public static void register(List<Module> l) {
        l.add(new StepRipples());
        l.add(new CustomGround());
        l.add(new WorldTint());
    }

    // ============================================================ ondas ao pisar
    public static class StepRipples extends Module {
        public final Setting style = add(Setting.choice("Estilo", 0, "Anel", "Preenchido", "Duplo", "Estrela de cores"));
        public final Setting color = add(Setting.color("Color", 0));
        public final Setting maxR = add(Setting.number("Raio", 1.6, 0.6, 4.0, 0.1));
        public final Setting life = add(Setting.number("Duracao (s)", 1.1, 0.4, 3.0, 0.1));
        public final Setting spacing = add(Setting.number("Espacamento", 0.9, 0.3, 2.0, 0.1));
        public final Setting landing = add(Setting.toggle("Onda grande ao cair", true));

        static final class R {
            double x, y, z;
            long t0;
            float big;
            int col;
        }

        final List<R> list = new ArrayList<R>();
        double lx, lz;
        boolean had, wasGround;
        float lastFall;
        int n;

        public StepRipples() {
            super("Step Ripples", "Onda colorida que se expande onde voce pisa e some.", Category.VISUAL);
        }

        void add(double x, double y, double z, float big) {
            R r = new R();
            r.x = x; r.y = y; r.z = z; r.big = big;
            r.t0 = System.currentTimeMillis();
            r.col = color.color == 0 ? RenderUtil.rainbow((n++) * 0.07f) : color.c();
            list.add(r);
            if (list.size() > 60) list.remove(0);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null) return;
            double fy = p.getEntityBoundingBox().minY;
            if (p.onGround) {
                if (!had) { lx = p.posX; lz = p.posZ; had = true; }
                double dx = p.posX - lx, dz = p.posZ - lz;
                if (dx * dx + dz * dz > spacing.num * spacing.num * 0.25) {
                    add(p.posX, fy, p.posZ, 1f);
                    lx = p.posX; lz = p.posZ;
                }
                if (!wasGround && landing.b() && lastFall > 1.5f) add(p.posX, fy, p.posZ, 1.8f);
            }
            if (!p.onGround) lastFall = Math.max(lastFall, p.fallDistance);
            else lastFall = 0f;
            wasGround = p.onGround;
        }

        @Override
        public void renderWorld(float pt) {
            if (list.isEmpty()) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            long now = System.currentTimeMillis();
            float lf = life.f() * 1000f;
            RenderUtil.begin();
            GlStateManager.depthMask(false);
            GlStateManager.blendFunc(770, 1);
            Iterator<R> it = list.iterator();
            while (it.hasNext()) {
                R r = it.next();
                float age = (now - r.t0) / lf;
                if (age >= 1f) { it.remove(); continue; }
                float rad = maxR.f() * r.big * (1f - (1f - age) * (1f - age));
                float a = (1f - age) * 0.9f;
                double x = r.x - cx, y = r.y + 0.03 - cy, z = r.z - cz;
                int st = style.index;
                if (st == 1) disc(x, y, z, rad, r.col, a * 0.7f, a * 0.1f);
                else if (st == 3) {
                    GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                    RenderUtil.color(RenderUtil.alpha(0xFFFFFFFF, a));
                    GL11.glVertex3d(x, y, z);
                    for (int i = 0; i <= 10; i++) {
                        double an = Math.PI * 2.0 * i / 10.0 + age * 2.0;
                        float rr = (i % 2 == 0) ? rad : rad * 0.45f;
                        RenderUtil.color(RenderUtil.alpha(RenderUtil.rainbow(i * 0.1f + age), a));
                        GL11.glVertex3d(x + Math.cos(an) * rr, y, z + Math.sin(an) * rr);
                    }
                    GL11.glEnd();
                } else {
                    band(x, y, z, rad * 0.86f, rad, r.col, 0f, a);
                    band(x, y, z, rad, rad * 1.06f + 0.02f, r.col, a, 0f);
                    if (st == 2) band(x, y, z, rad * 0.5f, rad * 0.58f, r.col, 0f, a * 0.7f);
                }
            }
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.depthMask(true);
            RenderUtil.end();
        }

        static void disc(double x, double y, double z, float r, int col, float aIn, float aOut) {
            GL11.glBegin(GL11.GL_TRIANGLE_FAN);
            RenderUtil.color(RenderUtil.alpha(col, aIn));
            GL11.glVertex3d(x, y, z);
            RenderUtil.color(RenderUtil.alpha(col, aOut));
            for (int i = 0; i <= 32; i++) {
                double an = Math.PI * 2.0 * i / 32.0;
                GL11.glVertex3d(x + Math.cos(an) * r, y, z + Math.sin(an) * r);
            }
            GL11.glEnd();
        }

        static void band(double x, double y, double z, float r0, float r1, int col, float a0, float a1) {
            GL11.glBegin(GL11.GL_QUAD_STRIP);
            for (int i = 0; i <= 32; i++) {
                double an = Math.PI * 2.0 * i / 32.0;
                double c = Math.cos(an), s = Math.sin(an);
                RenderUtil.color(RenderUtil.alpha(col, a0));
                GL11.glVertex3d(x + c * r0, y, z + s * r0);
                RenderUtil.color(RenderUtil.alpha(col, a1));
                GL11.glVertex3d(x + c * r1, y, z + s * r1);
            }
            GL11.glEnd();
        }
    }

    // ============================================================ chao customizado
    public static class CustomGround extends Module {
        public final Setting mode = add(Setting.choice("Chao", 0, "Neve", "Gelo", "Areia", "Grade Neon", "Lava", "Musgo", "Arco-iris", "Cristal Rosa"));
        public final Setting radius = add(Setting.number("Raio", 10, 4, 18, 1));
        public final Setting clear = add(Setting.toggle("Limpa ao passar", true));
        public final Setting regrow = add(Setting.number("Volta em (s)", 60, 5, 600, 5));
        public final Setting outdoors = add(Setting.toggle("So ao ar livre", true));
        public final Setting alpha = add(Setting.number("Opacidade", 0.9, 0.2, 1.0, 0.05));

        final List<int[]> cells = new ArrayList<int[]>();
        final Map<Long, Long> cleared = new HashMap<Long, Long>();
        int tick;

        public CustomGround() {
            super("Custom Ground", "Cobre o chao (neve, gelo, areia, neon...). Onde voce passa limpa e depois de um tempo volta.", Category.WORLD);
        }

        static long key(int x, int z) { return ((long) x << 32) ^ (z & 0xFFFFFFFFL); }

        @Override
        public void onDisable() {
            cells.clear();
            cleared.clear();
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null || mc.theWorld == null) return;
            long now = System.currentTimeMillis();
            if (clear.b() && p.onGround) {
                for (int[] c : cells) {
                    double dx = c[0] + 0.5 - p.posX, dz = c[2] + 0.5 - p.posZ;
                    if (dx * dx + dz * dz < 0.8 && Math.abs(c[1] + 1 - p.posY) < 1.3) cleared.put(key(c[0], c[2]), now);
                }
            }
            if (tick++ % 8 == 0) rebuild(mc, p);
            if (tick % 40 == 0) {
                long rg = (long) (regrow.num * 1000) + 3000;
                Iterator<Map.Entry<Long, Long>> it = cleared.entrySet().iterator();
                while (it.hasNext()) if (now - it.next().getValue() > rg) it.remove();
            }
        }

        void rebuild(Minecraft mc, EntityPlayerSP p) {
            cells.clear();
            int r = radius.i();
            int px = (int) Math.floor(p.posX), pz = (int) Math.floor(p.posZ), py = (int) Math.floor(p.posY);
            boolean sky = outdoors.b();
            for (int x = px - r; x <= px + r; x++) {
                for (int z = pz - r; z <= pz + r; z++) {
                    if ((x - px) * (x - px) + (z - pz) * (z - pz) > r * r) continue;
                    for (int y = py + 3; y >= py - 6; y--) {
                        BlockPos bp = new BlockPos(x, y, z);
                        IBlockState st = mc.theWorld.getBlockState(bp);
                        Block b = st.getBlock();
                        if (b.getMaterial().isSolid() && b.isFullCube()) {
                            BlockPos up = bp.up();
                            if (mc.theWorld.isAirBlock(up) && (!sky || mc.theWorld.canSeeSky(up))) cells.add(new int[]{x, y, z});
                            break;
                        }
                        if (b.getMaterial().isLiquid()) break;
                    }
                }
            }
        }

        int cellColor(int mi, int x, int z, long now, float th) {
            int h = (x * 73856093) ^ (z * 19349663);
            float n = ((h >>> 3) & 255) / 255f;
            switch (mi) {
                case 0: return RenderUtil.mix(0xFFEAF2FF, 0xFFFFFFFF, n);
                case 1: return RenderUtil.mix(0xFF9ADCFF, 0xFFD8F4FF, n);
                case 2: return RenderUtil.mix(0xFFE0C888, 0xFFF0DCA0, n);
                case 3: return RenderUtil.mix(0xFF101028, 0xFF1A1A40, n);
                case 4: return RenderUtil.mix(0xFFFF4A00, 0xFFFFC020, 0.5f + 0.5f * (float) Math.sin(th * 2 + n * 6));
                case 5: return RenderUtil.mix(0xFF2E6A24, 0xFF58A038, n);
                case 6: return RenderUtil.rainbow((x + z) * 0.03f + th * 0.1f);
                default: return RenderUtil.mix(0xFFFF7AD0, 0xFFC8A0FF, 0.5f + 0.5f * (float) Math.sin(th + n * 6));
            }
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null || cells.isEmpty()) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            long now = System.currentTimeMillis();
            float th = now / 1000f;
            int mi = mode.index;
            long rg = (long) (regrow.num * 1000);
            RenderUtil.begin();
            GlStateManager.depthMask(false);
            List<float[]> lines = new ArrayList<float[]>();
            GL11.glBegin(GL11.GL_QUADS);
            for (int[] c : cells) {
                float a = alpha.f();
                Long t0 = cleared.get(key(c[0], c[2]));
                if (t0 != null) {
                    long age = now - t0;
                    if (age < rg) continue;
                    a *= Math.min(1f, (age - rg) / 3000f);
                    if (a <= 0.01f) continue;
                }
                double x0 = c[0] - cx, x1 = x0 + 1, z0 = c[2] - cz, z1 = z0 + 1, y = c[1] + 1.015 - cy;
                if (mi == 3) {
                    lines.add(new float[]{(float) x0, (float) y, (float) z0, a});
                    RenderUtil.color(RenderUtil.alpha(0xFF05050F, a * 0.8f));
                } else {
                    RenderUtil.color(RenderUtil.alpha(cellColor(mi, c[0], c[2], now, th), a));
                }
                GL11.glVertex3d(x0, y, z0);
                GL11.glVertex3d(x0, y, z1);
                GL11.glVertex3d(x1, y, z1);
                GL11.glVertex3d(x1, y, z0);
            }
            GL11.glEnd();
            if (!lines.isEmpty()) {
                GL11.glLineWidth(2f);
                GL11.glBegin(GL11.GL_LINE_LOOP);
                GL11.glEnd();
                for (float[] q : lines) {
                    RenderUtil.color(RenderUtil.alpha(RenderUtil.rainbow(q[0] * 0.02f + q[2] * 0.02f + th * 0.2f), q[3]));
                    GL11.glBegin(GL11.GL_LINE_LOOP);
                    float y = q[1] + 0.005f;
                    GL11.glVertex3f(q[0], y, q[2]);
                    GL11.glVertex3f(q[0], y, q[2] + 1f);
                    GL11.glVertex3f(q[0] + 1f, y, q[2] + 1f);
                    GL11.glVertex3f(q[0] + 1f, y, q[2]);
                    GL11.glEnd();
                }
            }
            GlStateManager.depthMask(true);
            RenderUtil.end();
        }
    }

    // ============================================================ tinta de cor do mundo
    public static class WorldTint extends Module {
        public final Setting preset = add(Setting.choice("Estilo", 0, "Quente", "Frio", "Sepia", "Neon Roxo", "Matrix", "Rosa", "Por do Sol", "Custom"));
        public final Setting color = add(Setting.color("Custom", 0xFF40A0FF));
        public final Setting strength = add(Setting.number("Forca", 0.18, 0.03, 0.6, 0.01));
        public final Setting pulse = add(Setting.toggle("Pulsar", false));

        static final int[] P = {0xFFFF9A40, 0xFF40A0FF, 0xFFA07838, 0xFF9A30FF, 0xFF20FF60, 0xFFFF70B0, 0xFFFF5A30};

        public WorldTint() {
            super("World Tint", "Muda a cor geral do mundo (mais ou menos forte).", Category.WORLD);
        }

        @Override
        public void renderOverlay(ScaledResolution sr, float pt) {
            int c = preset.index < P.length ? P[preset.index] : color.c();
            float a = strength.f();
            if (pulse.b()) a *= 0.7f + 0.3f * (float) Math.sin(System.currentTimeMillis() / 700.0);
            RenderUtil.rect(0, 0, sr.getScaledWidth(), sr.getScaledHeight(), RenderUtil.alpha(c, a));
        }
    }
}
