package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;

import java.util.List;
import java.util.Locale;

/** Mods estilo Lunar Client (HUD + utilidades visuais). */
public final class LunarModules {
    private LunarModules() {}

    public static void register(List<Module> l) {
        l.add(new Speedometer());
        l.add(new ItemCounter());
        l.add(new ServerInfo());
        l.add(new SessionTimer());
        l.add(new HungerHud());
        l.add(new TntTimer());
        l.add(new ChunkBorders());
    }

    public static class Speedometer extends HudModules.TextHud {
        public Speedometer() {
            super("Speedometer", "Velocidade em blocos por segundo.", Category.HUD, 0.01f, 0.72f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            EntityPlayer p = mc.thePlayer;
            double dx = p.posX - p.lastTickPosX, dz = p.posZ - p.lastTickPosZ;
            return new String[]{String.format(Locale.US, "Speed: %.2f b/s", Math.sqrt(dx * dx + dz * dz) * 20.0)};
        }
    }

    public static class ItemCounter extends HudModules.TextHud {
        public ItemCounter() {
            super("Item Counter", "Gapples, pocoes, flechas e blocos no inventario.", Category.HUD, 0.01f, 0.78f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            int gap = 0, pots = 0, arrows = 0, blocks = 0;
            for (ItemStack s : mc.thePlayer.inventory.mainInventory) {
                if (s == null) continue;
                if (s.getItem() == Items.golden_apple) gap += s.stackSize;
                else if (s.getItem() == Items.arrow) arrows += s.stackSize;
                else if (s.getItem() instanceof ItemPotion && ItemPotion.isSplash(s.getMetadata())) pots += s.stackSize;
                else if (s.getItem() instanceof ItemBlock) blocks += s.stackSize;
            }
            return new String[]{"Gapples: " + gap, "Pots: " + pots, "Arrows: " + arrows, "Blocks: " + blocks};
        }
    }

    public static class ServerInfo extends HudModules.TextHud {
        public ServerInfo() {
            super("Server Address", "IP do servidor atual.", Category.HUD, 0.01f, 0.92f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{mc.getCurrentServerData() == null ? "Singleplayer" : mc.getCurrentServerData().serverIP};
        }
    }

    public static class SessionTimer extends HudModules.TextHud {
        private final long start = System.currentTimeMillis();

        public SessionTimer() {
            super("Session Timer", "Tempo de jogo nesta sessao.", Category.HUD, 0.9f, 0.02f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            long s = (System.currentTimeMillis() - start) / 1000L;
            return new String[]{String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)};
        }
    }

    public static class HungerHud extends HudModules.TextHud {
        public HungerHud() {
            super("Hunger / Saturation", "Fome e saturacao.", Category.HUD, 0.9f, 0.09f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{"Food: " + mc.thePlayer.getFoodStats().getFoodLevel(),
                    String.format(Locale.US, "Sat: %.1f", mc.thePlayer.getFoodStats().getSaturationLevel())};
        }
    }

    public static class TntTimer extends Module {
        public TntTimer() {
            super("TNT Timer", "Mostra o tempo para a TNT explodir.", Category.VISUAL);
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            for (Object o : mc.theWorld.loadedEntityList) {
                if (!(o instanceof EntityTNTPrimed)) continue;
                Entity e = (Entity) o;
                int f = ((EntityTNTPrimed) e).fuse;
                RenderUtil.worldText(String.format(Locale.US, "%.1fs", f / 20f),
                        e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - cx,
                        e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - cy + 1.2,
                        e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - cz, 0.03f, f < 20 ? 0xFFFF4040 : 0xFFFFFFFF);
            }
        }
    }

    public static class ChunkBorders extends Module {
        final Setting color = add(Setting.color("Color", 0xFF30FF90));
        final Setting range = add(Setting.number("Chunks", 2, 1, 5, 1));

        public ChunkBorders() {
            super("Chunk Borders", "Linhas nos limites dos chunks.", Category.VISUAL);
        }

        @Override
        public void renderWorld(float pt) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null) return;
            double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
            int bx = ((int) Math.floor(mc.thePlayer.posX) >> 4) << 4, bz = ((int) Math.floor(mc.thePlayer.posZ) >> 4) << 4;
            int r = range.i();
            double y0 = mc.thePlayer.posY - 24 - cy, y1 = mc.thePlayer.posY + 24 - cy;
            RenderUtil.begin();
            GL11.glLineWidth(1.5f);
            RenderUtil.color(color.c());
            GL11.glBegin(GL11.GL_LINES);
            for (int i = -r; i <= r + 1; i++) {
                for (int j = -r; j <= r + 1; j++) {
                    double x = bx + i * 16 - cx, z = bz + j * 16 - cz;
                    GL11.glVertex3d(x, y0, z);
                    GL11.glVertex3d(x, y1, z);
                }
            }
            double yy = Math.floor(mc.thePlayer.posY) - cy;
            for (int i = -r; i <= r + 1; i++) {
                double x = bx + i * 16 - cx;
                GL11.glVertex3d(x, yy, bz - r * 16 - cz);
                GL11.glVertex3d(x, yy, bz + (r + 1) * 16 - cz);
                double z = bz + i * 16 - cz;
                GL11.glVertex3d(bx - r * 16 - cx, yy, z);
                GL11.glVertex3d(bx + (r + 1) * 16 - cx, yy, z);
            }
            GL11.glEnd();
            RenderUtil.end();
        }
    }
}
