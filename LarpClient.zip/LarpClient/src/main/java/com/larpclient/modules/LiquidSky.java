package com.larpclient.modules;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

/** Ceu de metal liquido/derretido: textura procedural animada (sem arquivos) esticada numa cupula. */
public final class LiquidSky {
    private LiquidSky() {}

    private static final int TW = 192, TH = 96;
    private static DynamicTexture tex;
    private static long lastUpd;

    /** {escuro, medio, claro, brilho} por tema. */
    private static final int[][] THEMES = {
            {0x161C2C, 0x6C7A9A, 0xC8D4EE, 0xFFFFFF},   // Liquid Chrome
            {0x3A1C04, 0xC07A14, 0xFFC843, 0xFFF6D0},   // Molten Gold
            {0x14141C, 0x7C7C92, 0xD6D6EA, 0xFFFFFF},   // Mercury
            {0x1E0300, 0xC02A06, 0xFF8A1E, 0xFFE070},   // Lava Metal
            {0x080F2A, 0x1AB09A, 0x9A5CFF, 0xE8FFFF},   // Liquid Aurora
    };

    public static final int[] FOG = {0xFF6C7A9A, 0xFFC07A14, 0xFF7C7C92, 0xFFC02A06, 0xFF1AB09A};
    public static final int[] DARK = {0xFF101420, 0xFF2A1403, 0xFF0E0E14, 0xFF160200, 0xFF060B1E};

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static void update(int theme, float t) {
        if (tex == null) tex = new DynamicTexture(TW, TH);
        int[] d = tex.getTextureData();
        int[] th = THEMES[theme];
        for (int y = 0; y < TH; y++) {
            float v = y / (float) TH * 3.14159f;
            for (int x = 0; x < TW; x++) {
                float u = x / (float) TW * 6.28318f;
                float f1 = (float) Math.sin(2 * u + t * 0.55f + 2.6f * Math.sin(v * 3f + t * 0.35f));
                float f2 = (float) Math.sin(3 * u - t * 0.45f + 3.2f * Math.cos(v * 5f - t * 0.3f + f1 * 1.8f));
                float f3 = (float) Math.sin(4 * u + v * 6f + t * 0.6f + f2 * 2.4f);
                float h = (f1 + f2 + f3) / 3f;
                float m = 0.5f + 0.5f * (float) Math.sin(h * 5.5f + v * 3f);
                float spec = (float) Math.pow(m, 9f);
                int c = m < 0.5f ? mix(th[0], th[1], m * 2f) : mix(th[1], th[2], (m - 0.5f) * 2f);
                c = mix(c, th[3], spec * 0.9f);
                if (theme == 4) c = mix(c, th[2], 0.5f + 0.5f * f3 * (1f - m));
                d[y * TW + x] = 0xFF000000 | c;
            }
        }
        tex.updateDynamicTexture();
    }

    public static void draw(int theme, float tsec, float day) {
        theme = Math.max(0, Math.min(THEMES.length - 1, theme));
        long now = System.currentTimeMillis();
        if (tex == null || now - lastUpd > 33L) {
            update(theme, tsec);
            lastUpd = now;
        }
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.bindTexture(tex.getGlTextureId());
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_REPEAT);
        float br = 0.42f + 0.58f * day;
        GlStateManager.color(br, br, br, 1f);
        int seg = 48;
        float[] lat = {90f, 75f, 60f, 45f, 30f, 18f, 8f, 0f, -15f, -40f};
        for (int i = 0; i < lat.length - 1; i++) {
            GL11.glBegin(GL11.GL_QUAD_STRIP);
            for (int j = 0; j <= seg; j++) {
                double a = Math.PI * 2.0 * j / seg;
                for (int k = 0; k < 2; k++) {
                    float la = lat[i + k];
                    double rad = Math.cos(Math.toRadians(la)) * 100.0;
                    double y = Math.sin(Math.toRadians(la)) * 100.0;
                    float vv = (90f - la) / 130f;
                    GL11.glTexCoord2f(j / (float) seg, vv);
                    GL11.glVertex3d(Math.cos(a) * rad, y, Math.sin(a) * rad);
                }
            }
            GL11.glEnd();
        }
        com.larpclient.util.RenderUtil.white();
        GlStateManager.disableTexture2D();
    }
}
