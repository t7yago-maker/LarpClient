package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.ModuleManager;
import com.larpclient.core.Setting;
import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;
import java.util.ArrayDeque;
import java.util.List;

/** Pacote extra: Fake Lag, Blink, Criticals, WTap, Sprint, BHop, InvMove, SafeWalk, Glide, FullBright, etc. */
public final class ExtraModules {
    private ExtraModules() {}

    public static void register(List<Module> l) {
        l.add(new FakeLag());
        l.add(new Criticals());
        l.add(new WTap());
        l.add(new BHop());
        l.add(new InvMove());
        l.add(new SafeWalk());
        l.add(new Glide());
        l.add(new Blink());
        l.add(new NoJumpDelay());
        l.add(new NoHurtCam());
        l.add(new NoBob());
        l.add(new CustomFov());
        l.add(new WeatherChanger());
        l.add(new AntiAFK());
        l.add(new Panic());
    }

    // ============================================================ rede (Fake Lag / Blink)
    static final class LagHandler extends ChannelDuplexHandler {
        final ArrayDeque<Object[]> q = new ArrayDeque<Object[]>();
        volatile ChannelHandlerContext ctx;
        volatile boolean hold;
        volatile boolean all;

        @Override
        public void write(ChannelHandlerContext c, Object msg, ChannelPromise p) throws Exception {
            ctx = c;
            if (msg instanceof C00PacketKeepAlive) {
                super.write(c, msg, p);
                return;
            }
            boolean holdIt = hold && (all ? true : msg instanceof C03PacketPlayer);
            if (holdIt) {
                synchronized (q) {
                    q.add(new Object[]{msg, p, Long.valueOf(System.currentTimeMillis())});
                }
                return;
            }
            if (msg instanceof C02PacketUseEntity) flush(c, -1L);
            super.write(c, msg, p);
        }

        void flush(ChannelHandlerContext c, long olderThanMs) {
            long now = System.currentTimeMillis();
            boolean any = false;
            synchronized (q) {
                while (!q.isEmpty()) {
                    Object[] o = q.peekFirst();
                    if (olderThanMs >= 0 && now - ((Long) o[2]).longValue() < olderThanMs) break;
                    q.pollFirst();
                    c.write(o[0], (ChannelPromise) o[1]);
                    any = true;
                }
            }
            if (any) c.flush();
        }
    }

    private static LagHandler handler;

    static LagHandler net(Minecraft mc) {
        try {
            if (mc.getNetHandler() == null) return null;
            Channel ch = mc.getNetHandler().getNetworkManager().channel();
            if (ch == null) return null;
            LagHandler h = (LagHandler) ch.pipeline().get("larp_lag");
            if (h == null) {
                h = new LagHandler();
                ch.pipeline().addBefore("packet_handler", "larp_lag", h);
            }
            handler = h;
            return h;
        } catch (Throwable t) {
            return null;
        }
    }

    static void release(final LagHandler h, final long olderThan) {
        final ChannelHandlerContext c = h.ctx;
        if (c == null) return;
        c.channel().eventLoop().execute(new Runnable() {
            @Override
            public void run() {
                h.flush(c, olderThan);
            }
        });
    }

    public static class FakeLag extends Module {
        final Setting delay = add(Setting.number("Atraso (ms)", 180, 40, 1500, 10));
        final Setting pulse = add(Setting.toggle("Soltar em rajada", true));

        public FakeLag() {
            super("Fake Lag", "Segura seus pacotes de movimento e solta depois (lag falso para PvP).", Category.COMBAT);
            note = "Cheat de PvP. Anti-cheats detectam.";
        }

        @Override
        public void onTick(Minecraft mc) {
            LagHandler h = net(mc);
            if (h == null) return;
            h.hold = true;
            h.all = false;
            release(h, (long) delay.num);
        }

        @Override
        public void onDisable() {
            if (handler != null) {
                handler.hold = false;
                release(handler, -1L);
            }
        }
    }

    public static class Blink extends Module {
        public Blink() {
            super("Blink", "Segura TODOS os pacotes (fica parado para o servidor). Desligue para soltar tudo.", Category.PLAYER);
            note = "Cheat. Anti-cheats detectam.";
        }

        @Override
        public void onTick(Minecraft mc) {
            LagHandler h = net(mc);
            if (h != null) {
                h.hold = true;
                h.all = true;
            }
        }

        @Override
        public void onDisable() {
            if (handler != null) {
                handler.hold = false;
                handler.all = false;
                release(handler, -1L);
            }
        }
    }

    // ============================================================ combate
    public static class Criticals extends Module {
        public Criticals() {
            super("Criticals", "Faz o golpe virar critico mesmo no chao (pacotes de mini pulo).", Category.COMBAT);
            note = "Cheat. Anti-cheats detectam.";
        }

        @Override
        public void onAttack(Entity target) {
            EntityPlayerSP p = Minecraft.getMinecraft().thePlayer;
            if (p == null || !p.onGround || p.isInWater()) return;
            double x = p.posX, y = p.posY, z = p.posZ;
            p.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.0625, z, false));
            p.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
        }
    }

    public static class WTap extends Module {
        private int ticks;

        public WTap() {
            super("W-Tap", "Reseta a corrida ao bater para dar mais knockback.", Category.COMBAT);
        }

        @Override
        public void onAttack(Entity target) {
            EntityPlayerSP p = Minecraft.getMinecraft().thePlayer;
            if (p != null && p.isSprinting()) {
                p.setSprinting(false);
                ticks = 1;
            }
        }

        @Override
        public void onTick(Minecraft mc) {
            if (ticks > 0 && --ticks == 0 && mc.thePlayer != null && mc.gameSettings.keyBindForward.isKeyDown()) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }

    // ============================================================ movimento
    public static class AutoSprint extends Module {
        public AutoSprint() {
            super("Auto Sprint", "Corre sozinho enquanto anda para frente.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null) return;
            if (mc.gameSettings.keyBindForward.isKeyDown() && !p.isSneaking() && !p.isCollidedHorizontally
                    && p.getFoodStats().getFoodLevel() > 6 && !p.isUsingItem()) {
                p.setSprinting(true);
            }
        }
    }

    public static class BHop extends Module {
        final Setting boost = add(Setting.number("Impulso", 1.0, 1.0, 1.4, 0.02));

        public BHop() {
            super("Bunny Hop", "Pula sozinho enquanto anda (mantem velocidade).", Category.MOVEMENT);
            note = "Cheat. Anti-cheats detectam.";
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null || mc.currentScreen != null) return;
            boolean moving = mc.gameSettings.keyBindForward.isKeyDown() || mc.gameSettings.keyBindBack.isKeyDown()
                    || mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown();
            if (moving && p.onGround && !p.isSneaking() && !p.isInWater()) {
                p.jump();
                double b = boost.num;
                if (b > 1.0) {
                    p.motionX *= b;
                    p.motionZ *= b;
                }
            }
        }
    }

    public static class InvMove extends Module {
        public InvMove() {
            super("Inventory Move", "Anda e pula com o inventario aberto.", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (!(mc.currentScreen instanceof GuiContainer)) return;
            KeyBinding[] k = {mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack, mc.gameSettings.keyBindLeft,
                    mc.gameSettings.keyBindRight, mc.gameSettings.keyBindJump};
            for (KeyBinding b : k) KeyBinding.setKeyBindState(b.getKeyCode(), Keyboard.isKeyDown(b.getKeyCode()));
        }
    }

    public static class SafeWalk extends Module {
        private boolean forced;

        public SafeWalk() {
            super("Safe Walk", "Agacha sozinho na beira do bloco (nao cai).", Category.MOVEMENT);
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p == null || mc.currentScreen != null) return;
            boolean edge = p.onGround && mc.theWorld.getCollidingBoundingBoxes(p, p.getEntityBoundingBox().offset(p.motionX * 2, -0.6, p.motionZ * 2)).isEmpty();
            if (edge) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
                forced = true;
            } else if (forced) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), Keyboard.isKeyDown(mc.gameSettings.keyBindSneak.getKeyCode()));
                forced = false;
            }
        }

        @Override
        public void onDisable() {
            Minecraft mc = Minecraft.getMinecraft();
            if (forced) KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
            forced = false;
        }
    }

    public static class Glide extends Module {
        final Setting fall = add(Setting.number("Queda", 0.12, 0.02, 0.4, 0.01));

        public Glide() {
            super("Glide", "Cai devagar (planar).", Category.MOVEMENT);
            note = "Cheat. Anti-cheats detectam.";
        }

        @Override
        public void onTick(Minecraft mc) {
            EntityPlayerSP p = mc.thePlayer;
            if (p != null && !p.onGround && p.motionY < -fall.num && !p.isInWater()) p.motionY = -fall.num;
        }
    }

    // ============================================================ jogador
    private static Field fieldCache(Class<?> c, String... names) {
        try {
            return ReflectionHelper.findField(c, names);
        } catch (Throwable t) {
            return null;
        }
    }

    public static class FastPlace extends Module {
        private Field f;
        private boolean init;

        public FastPlace() {
            super("Fast Place", "Coloca blocos sem atraso.", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (!init) {
                init = true;
                f = fieldCache(Minecraft.class, "rightClickDelayTimer", "field_71467_ac");
                if (f != null) f.setAccessible(true);
            }
            try {
                if (f != null) f.setInt(mc, 0);
            } catch (Throwable ignored) {
            }
        }
    }

    public static class NoJumpDelay extends Module {
        private Field f;
        private boolean init;

        public NoJumpDelay() {
            super("No Jump Delay", "Pula de novo sem esperar tocar o chao (segurando espaco).", Category.PLAYER);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (!init) {
                init = true;
                f = fieldCache(net.minecraft.entity.EntityLivingBase.class, "jumpTicks", "field_70773_bE");
                if (f != null) f.setAccessible(true);
            }
            try {
                if (f != null && mc.thePlayer != null) f.setInt(mc.thePlayer, 0);
            } catch (Throwable ignored) {
            }
        }
    }

    public static class NoHurtCam extends Module {
        public NoHurtCam() {
            super("No Hurt Cam", "Tira o tranco da camera quando apanha.", Category.PLAYER);
        }

        @Override
        public void onFrame(Minecraft mc, float dt) {
            if (mc.thePlayer != null) mc.thePlayer.hurtTime = 0;
        }
    }

    public static class AntiAFK extends Module {
        private int t;

        public AntiAFK() {
            super("Anti AFK", "Mexe um pouco a cada 20s para nao ser kickado por ficar parado.", Category.UTILITY);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null) return;
            if (++t >= 400) {
                t = 0;
                mc.thePlayer.rotationYaw += 4f;
                if (mc.thePlayer.onGround) mc.thePlayer.jump();
            }
        }
    }

    public static class Panic extends Module {
        public Panic() {
            super("Panic", "Liga e DESLIGA TODOS os outros modulos de uma vez (emergencia).", Category.UTILITY);
        }

        @Override
        public void onEnable() {
            for (Module m : ModuleManager.all) {
                if (m != this && m.enabled && m.category != Category.COSMETICS && m.category != Category.HUD) m.setEnabled(false);
            }
            enabled = false;
        }
    }

    // ============================================================ visual / mundo
    public static class FullBright extends Module {
        private float old = 1f;

        public FullBright() {
            super("Full Bright", "Brilho maximo (enxerga no escuro).", Category.VISUAL);
        }

        @Override
        public void onEnable() {
            old = Minecraft.getMinecraft().gameSettings.gammaSetting;
        }

        @Override
        public void onTick(Minecraft mc) {
            mc.gameSettings.gammaSetting = 100f;
        }

        @Override
        public void onDisable() {
            Minecraft.getMinecraft().gameSettings.gammaSetting = old;
        }
    }

    public static class NoBob extends Module {
        private boolean old;

        public NoBob() {
            super("No Bob", "Tira o balanco da tela ao andar.", Category.VISUAL);
        }

        @Override
        public void onEnable() {
            old = Minecraft.getMinecraft().gameSettings.viewBobbing;
        }

        @Override
        public void onTick(Minecraft mc) {
            mc.gameSettings.viewBobbing = false;
        }

        @Override
        public void onDisable() {
            Minecraft.getMinecraft().gameSettings.viewBobbing = old;
        }
    }

    public static class CustomFov extends Module {
        final Setting fov = add(Setting.number("FOV", 100, 30, 140, 1));
        private float old = 70f;

        public CustomFov() {
            super("Custom FOV", "Campo de visao personalizado.", Category.VISUAL);
        }

        @Override
        public void onEnable() {
            old = Minecraft.getMinecraft().gameSettings.fovSetting;
        }

        @Override
        public void onTick(Minecraft mc) {
            mc.gameSettings.fovSetting = (float) fov.num;
        }

        @Override
        public void onDisable() {
            Minecraft.getMinecraft().gameSettings.fovSetting = old;
        }
    }

    public static class TimeChanger extends Module {
        final Setting time = add(Setting.choice("Hora", 1, "Amanhecer", "Meio-dia", "Por do sol", "Noite", "Meia-noite"));

        public TimeChanger() {
            super("Time Changer", "Muda a hora do dia so para voce.", Category.WORLD);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.theWorld == null) return;
            long[] t = {0L, 6000L, 12500L, 14500L, 18000L};
            mc.theWorld.setWorldTime(t[Math.max(0, Math.min(4, time.index))]);
        }
    }

    public static class WeatherChanger extends Module {
        public WeatherChanger() {
            super("Clear Weather", "Tira chuva e trovoes so para voce.", Category.WORLD);
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.theWorld == null) return;
            mc.theWorld.setRainStrength(0f);
            mc.theWorld.setThunderStrength(0f);
        }
    }
}
