package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.core.Stats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.List;
import java.util.Random;

/** Modulos de combate/PvP: Reach, Hitbox Expand, AutoClick, Aim Assist, Legit Scaffold. */
public final class AdvCombatModules {
    private AdvCombatModules() {}

    private static final Random RND = new Random();

    public static void register(List<Module> l) {
        l.add(new Reach());
        l.add(new HitboxExpand());
        l.add(new AutoClick());
        l.add(new AimAssist());
        l.add(new LegitScaffold());
    }

    // ------------------------------------------------------------------
    //  Selecao de alvos (jogadores / mobs / animais)
    // ------------------------------------------------------------------
    static boolean kindOk(Entity e, Minecraft mc, boolean players, boolean mobs, boolean animals) {
        if (e == null || e == mc.thePlayer || !(e instanceof EntityLivingBase) || !e.isEntityAlive()) return false;
        if (e instanceof EntityPlayer) return players && !e.isInvisible();
        if (e instanceof EntityAnimal) return animals;
        if (e instanceof IMob) return mobs;
        return false;
    }

    // ------------------------------------------------------------------
    //  Raio de mira estendido (usado por Reach e Hitbox Expand)
    // ------------------------------------------------------------------
    static void extendTarget(Minecraft mc, double reach, double expand) {
        if (mc.theWorld == null || mc.thePlayer == null || mc.currentScreen != null) return;
        Entity view = mc.getRenderViewEntity();
        if (view == null) return;
        MovingObjectPosition cur = mc.objectMouseOver;
        if (cur != null && cur.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY) return;
        Vec3 eye = view.getPositionEyes(1.0F);
        Vec3 look = view.getLook(1.0F);
        Vec3 end = eye.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
        double blockDist = reach;
        MovingObjectPosition blk = mc.theWorld.rayTraceBlocks(eye, end, false, false, true);
        if (blk != null && blk.hitVec != null) blockDist = eye.distanceTo(blk.hitVec);
        AxisAlignedBB area = view.getEntityBoundingBox()
                .addCoord(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach).expand(1.0, 1.0, 1.0);
        @SuppressWarnings("unchecked")
        List<Entity> list = mc.theWorld.getEntitiesWithinAABBExcludingEntity(view, area);
        Entity best = null;
        Vec3 bestHit = null;
        double bestD = Math.min(reach, blockDist);
        for (Entity e : list) {
            if (!e.canBeCollidedWith() || !(e instanceof EntityLivingBase)) continue;
            double b = e.getCollisionBorderSize() + expand;
            AxisAlignedBB bb = e.getEntityBoundingBox().expand(b, b, b);
            MovingObjectPosition mop = bb.calculateIntercept(eye, end);
            if (bb.isVecInside(eye)) {
                if (bestD >= 0.0) {
                    best = e;
                    bestHit = mop == null ? eye : mop.hitVec;
                    bestD = 0.0;
                }
            } else if (mop != null) {
                double d = eye.distanceTo(mop.hitVec);
                if (d < bestD) {
                    best = e;
                    bestHit = mop.hitVec;
                    bestD = d;
                }
            }
        }
        if (best != null) {
            mc.objectMouseOver = new MovingObjectPosition(best, bestHit);
            mc.pointedEntity = best;
        }
    }

    public static class Reach extends Module {
        final Setting dist = add(Setting.number("Reach", 3.0, 3.0, 6.0, 0.1));
        final Setting hold = add(Setting.toggle("Only while sprinting", false));

        public Reach() {
            super("Reach", "Aumenta o alcance de ataque (3.0 padrao ate 6.0).", Category.COMBAT);
            note = "Cheat de PvP. Anti-cheats e muitos servidores banem. Use em singleplayer/servidor proprio.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null) return;
            if (hold.b() && !mc.thePlayer.isSprinting()) return;
            double r = dist.num;
            if (r <= 3.0) return;
            HitboxExpand h = com.larpclient.core.ModuleManager.get(HitboxExpand.class);
            extendTarget(mc, r, h != null && h.enabled ? h.amount.num : 0.0);
        }
    }

    public static class HitboxExpand extends Module {
        final Setting amount = add(Setting.number("Expand", 0.2, 0.0, 1.0, 0.05));
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", true));
        final Setting animals = add(Setting.toggle("Animals", true));

        public HitboxExpand() {
            super("Hitbox Expand", "Aumenta a hitbox de players, mobs e animais para acertar mais facil.", Category.COMBAT);
            note = "Cheat de PvP. Pode causar ban em servidores com anti-cheat.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            Reach r = com.larpclient.core.ModuleManager.get(Reach.class);
            if (r != null && r.enabled && r.dist.num > 3.0) return; // Reach ja aplica a expansao
            extendTarget(mc, 3.0, amount.num);
        }
    }

    // ------------------------------------------------------------------
    //  AutoClick
    // ------------------------------------------------------------------
    public static class AutoClick extends Module {
        final Setting cps = add(Setting.number("CPS", 16, 1, 20, 1));
        final Setting jitter = add(Setting.number("Randomize", 2, 0, 6, 1));
        final Setting left = add(Setting.toggle("Left Click", true));
        final Setting right = add(Setting.toggle("Right Click", true));
        final Setting blocks = add(Setting.toggle("Pause on Blocks", true));
        private float accL, accR;

        public AutoClick() {
            super("AutoClick", "Clica sozinho segurando o mouse (16 CPS padrao, esquerdo e direito).", Category.COMBAT);
            note = "Automacao de cliques e proibida em muitos servidores.";
        }

        private float rate() {
            float c = cps.f() + (jitter.f() > 0 ? (RND.nextFloat() * 2f - 1f) * jitter.f() : 0f);
            return Math.max(1f, Math.min(20f, c));
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null || !mc.inGameHasFocus) return;
            if (left.b() && Mouse.isButtonDown(0)) {
                MovingObjectPosition m = mc.objectMouseOver;
                boolean onBlock = m != null && m.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK;
                if (!(blocks.b() && onBlock)) {
                    accL += rate() / 20f;
                    if (accL >= 1f) {
                        accL -= 1f;
                        KeyBinding.onTick(mc.gameSettings.keyBindAttack.getKeyCode());
                        Stats.click(0);
                    }
                } else accL = 0f;
            } else accL = 0f;
            if (right.b() && Mouse.isButtonDown(1)) {
                accR += rate() / 20f;
                if (accR >= 1f) {
                    accR -= 1f;
                    KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
                    Stats.click(1);
                }
            } else accR = 0f;
        }
    }

    // ------------------------------------------------------------------
    //  Aim Assist
    // ------------------------------------------------------------------
    public static class AimAssist extends Module {
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", false));
        final Setting animals = add(Setting.toggle("Animals", false));
        final Setting strength = add(Setting.number("Grudar (0-100)", 40, 0, 100, 1));
        final Setting range = add(Setting.number("Range", 4.5, 3, 8, 0.5));
        final Setting fov = add(Setting.number("FOV", 90, 20, 180, 5));
        final Setting vertical = add(Setting.toggle("Vertical", false));

        public AimAssist() {
            super("Aim Assist", "Puxa a mira para o alvo so quando voce segura o clique esquerdo.", Category.COMBAT);
            note = "Cheat de PvP. Anti-cheats detectam. Use com cuidado.";
        }

        @Override
        public void onFrame(Minecraft mc, float dt) {
            if (mc.currentScreen != null || !mc.inGameHasFocus || !Mouse.isButtonDown(0)) return;
            if (strength.num <= 0) return;
            EntityPlayer me = mc.thePlayer;
            Entity best = null;
            double bestAng = fov.num / 2.0;
            for (Object o : mc.theWorld.loadedEntityList) {
                Entity e = (Entity) o;
                if (!kindOk(e, mc, players.b(), mobs.b(), animals.b())) continue;
                if (me.getDistanceToEntity(e) > range.num) continue;
                double dx = e.posX - me.posX, dz = e.posZ - me.posZ;
                float yawTo = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
                double ang = Math.abs(MathHelper.wrapAngleTo180_float(yawTo - me.rotationYaw));
                if (ang < bestAng) {
                    bestAng = ang;
                    best = e;
                }
            }
            if (best == null) return;
            double dx = best.posX - me.posX;
            double dz = best.posZ - me.posZ;
            double dy = (best.posY + best.height * 0.6) - (me.posY + me.getEyeHeight());
            float yawTo = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
            float pitchTo = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
            // fracao por tick -> fracao por frame (independe do FPS)
            float perTick = (float) (strength.num / 100.0) * 0.30f;
            float frac = 1f - (float) Math.pow(1f - perTick, dt * 20f);
            float dyaw = MathHelper.wrapAngleTo180_float(yawTo - me.rotationYaw);
            me.rotationYaw += dyaw * frac;
            if (vertical.b()) {
                float dp = pitchTo - me.rotationPitch;
                me.rotationPitch = MathHelper.clamp_float(me.rotationPitch + dp * frac, -90f, 90f);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Legit Scaffold (ninja bridge)
    // ------------------------------------------------------------------
    public static class LegitScaffold extends Module {
        final Setting backOnly = add(Setting.toggle("Only moving back", false));
        final Setting lookDown = add(Setting.toggle("Only looking down", true));
        final Setting autoPlace = add(Setting.toggle("Auto Place", false));
        final Setting delay = add(Setting.number("Place Delay (ticks)", 2, 1, 8, 1));
        private boolean forced;
        private int cd;

        public LegitScaffold() {
            super("Legit Scaffold", "Ninja bridge: agacha sozinho na ponta do bloco enquanto voce coloca blocos.", Category.PLAYER);
            note = "Automacao de teclas. Alguns servidores proibem.";
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) {
                release(mc);
                return;
            }
            EntityPlayer p = mc.thePlayer;
            ItemStack held = p.getHeldItem();
            boolean block = held != null && held.getItem() instanceof ItemBlock;
            boolean ok = block && p.onGround;
            if (ok && lookDown.b() && p.rotationPitch < 55f) ok = false;
            if (ok && backOnly.b() && !mc.gameSettings.keyBindBack.isKeyDown()) ok = false;
            if (!ok) {
                release(mc);
                return;
            }
            AxisAlignedBB bb = p.getEntityBoundingBox().offset(p.motionX * 1.5, -0.5, p.motionZ * 1.5);
            boolean edge = mc.theWorld.getCollidingBoundingBoxes(p, bb).isEmpty();
            int sneak = mc.gameSettings.keyBindSneak.getKeyCode();
            boolean physical = sneak > 0 && Keyboard.isKeyDown(sneak);
            if (edge) {
                KeyBinding.setKeyBindState(sneak, true);
                forced = true;
                if (autoPlace.b() && p.isSneaking()) {
                    if (cd > 0) cd--;
                    MovingObjectPosition m = mc.objectMouseOver;
                    if (cd <= 0 && m != null && m.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
                        cd = delay.i();
                    }
                }
            } else if (forced && !physical) {
                KeyBinding.setKeyBindState(sneak, false);
                forced = false;
            }
        }

        private void release(Minecraft mc) {
            if (!forced) return;
            int sneak = mc.gameSettings.keyBindSneak.getKeyCode();
            if (!(sneak > 0 && Keyboard.isKeyDown(sneak))) KeyBinding.setKeyBindState(sneak, false);
            forced = false;
        }

        @Override
        public void onDisable() {
            release(Minecraft.getMinecraft());
        }
    }
}
