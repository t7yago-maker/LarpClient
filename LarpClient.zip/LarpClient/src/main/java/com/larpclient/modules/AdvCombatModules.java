package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.ModuleManager;
import com.larpclient.core.Setting;
import com.larpclient.core.Stats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Random;

/** Modulos de combate/PvP: Reach, Hitbox Expand, AutoClick, Aim Assist, TriggerBot, KillAura, Velocity, Legit Scaffold. */
public final class AdvCombatModules {
    private AdvCombatModules() {}

    private static final Random RND = new Random();
    private static Field leftCounter;

    public static void register(List<Module> l) {
        l.add(new Reach());
        l.add(new HitboxExpand());
        l.add(new AutoClick());
        l.add(new AimAssist());
        l.add(new TriggerBot());
        l.add(new KillAura());
        l.add(new Velocity());
        l.add(new LegitScaffold());
    }

    /** Zera o atraso interno de clique do Minecraft (sem isso ele ignora cliques rapidos). */
    static void resetClickDelay(Minecraft mc) {
        try {
            if (leftCounter == null) {
                leftCounter = ReflectionHelper.findField(Minecraft.class, "leftClickCounter", "field_71429_W");
                leftCounter.setAccessible(true);
            }
            leftCounter.setInt(mc, 0);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------
    //  Selecao de alvos (jogadores / mobs / animais)
    // ------------------------------------------------------------------
    static boolean kindOk(Entity e, Minecraft mc, boolean players, boolean mobs, boolean animals) {
        if (e == null || e == mc.thePlayer || !(e instanceof EntityLivingBase) || !e.isEntityAlive()) return false;
        if (e instanceof EntityPlayer) return players && !e.isInvisible();
        if (e instanceof EntityAnimal || e instanceof net.minecraft.entity.passive.EntityAmbientCreature
                || e instanceof net.minecraft.entity.passive.EntityWaterMob || e instanceof net.minecraft.entity.passive.EntityVillager) return animals;
        if (e instanceof IMob) return mobs;
        return false;
    }

    /** Ponto de mira dentro da hitbox do alvo. mode: 0 centro, 1 cabeca, 2 peito, 3 mais proximo. */
    static double[] aimPoint(Entity e, EntityPlayer me, int mode) {
        AxisAlignedBB bb = e.getEntityBoundingBox();
        double cx = (bb.minX + bb.maxX) / 2.0, cz = (bb.minZ + bb.maxZ) / 2.0;
        double h = bb.maxY - bb.minY;
        double ey = me.posY + me.getEyeHeight();
        switch (mode) {
            case 1: return new double[]{cx, bb.maxY - Math.min(0.25, h * 0.2), cz};
            case 2: return new double[]{cx, bb.minY + h * 0.72, cz};
            case 3: {
                double x = Math.max(bb.minX, Math.min(bb.maxX, me.posX));
                double y = Math.max(bb.minY, Math.min(bb.maxY, ey));
                double z = Math.max(bb.minZ, Math.min(bb.maxZ, me.posZ));
                return new double[]{x, y, z};
            }
            default: return new double[]{cx, bb.minY + h * 0.5, cz};
        }
    }

    static float[] anglesTo(EntityPlayer me, double[] p) {
        double dx = p[0] - me.posX, dz = p[2] - me.posZ, dy = p[1] - (me.posY + me.getEyeHeight());
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float pitch = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    static boolean visible(Minecraft mc, Entity e) {
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        double[] p = aimPoint(e, mc.thePlayer, 0);
        return mc.theWorld.rayTraceBlocks(eye, new Vec3(p[0], p[1], p[2]), false, true, false) == null;
    }

    // ------------------------------------------------------------------
    //  Raio de mira estendido (usado por Reach e Hitbox Expand)
    // ------------------------------------------------------------------
    static void applyTargeting(Minecraft mc) {
        Reach r = ModuleManager.get(Reach.class);
        HitboxExpand h = ModuleManager.get(HitboxExpand.class);
        boolean rOn = r != null && r.enabled && (!r.sprintOnly.b() || (mc.thePlayer != null && mc.thePlayer.isSprinting()));
        boolean hOn = h != null && h.enabled;
        double reach = rOn ? Math.max(3.0, r.dist.num) : 3.0;
        double exp = hOn ? h.amount.num : 0.0;
        if (reach <= 3.0 && exp <= 0.0) return;
        extendTarget(mc, reach, exp, h);
    }

    static void extendTarget(Minecraft mc, double reach, double expand, HitboxExpand h) {
        if (mc.theWorld == null || mc.thePlayer == null || mc.currentScreen != null) return;
        Entity view = mc.getRenderViewEntity();
        if (view == null) return;
        MovingObjectPosition cur = mc.objectMouseOver;
        Vec3 eye = view.getPositionEyes(1.0F);
        Vec3 look = view.getLook(1.0F);
        Vec3 end = eye.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
        double blockDist = reach;
        MovingObjectPosition blk = mc.theWorld.rayTraceBlocks(eye, end, false, false, true);
        if (blk != null && blk.hitVec != null) blockDist = eye.distanceTo(blk.hitVec);
        AxisAlignedBB area = view.getEntityBoundingBox()
                .addCoord(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach).expand(1.5, 1.5, 1.5);
        @SuppressWarnings("unchecked")
        List<Entity> list = mc.theWorld.getEntitiesWithinAABBExcludingEntity(view, area);
        Entity best = null;
        Vec3 bestHit = null;
        double bestD = Math.min(reach, blockDist);
        for (Entity e : list) {
            if (!e.canBeCollidedWith() || !(e instanceof EntityLivingBase)) continue;
            if (h != null && h.enabled) {
                if (!kindOk(e, mc, h.players.b(), h.mobs.b(), h.animals.b())) continue;
            } else if (e instanceof EntityPlayer && e.isInvisible()) {
                continue;
            }
            double b = e.getCollisionBorderSize() + expand;
            AxisAlignedBB bb = e.getEntityBoundingBox().expand(b, b, b);
            MovingObjectPosition mop = bb.calculateIntercept(eye, end);
            if (bb.isVecInside(eye)) {
                best = e;
                bestHit = mop == null ? eye : mop.hitVec;
                bestD = 0.0;
            } else if (mop != null) {
                double d = eye.distanceTo(mop.hitVec);
                if (d < bestD) {
                    best = e;
                    bestHit = mop.hitVec;
                    bestD = d;
                }
            }
        }
        if (best != null) {
            mc.objectMouseOver = new MovingObjectPosition(best, bestHit);
            mc.pointedEntity = best;
        }
    }

    public static class Reach extends Module {
        final Setting dist = add(Setting.number("Reach", 4.5, 3.0, 6.0, 0.1));
        final Setting sprintOnly = add(Setting.toggle("Only while sprinting", false));

        public Reach() {
            super("Reach", "Aumenta o alcance de ataque (3.0 = normal, ate 6.0).", Category.COMBAT);
            note = "Cheat de PvP. Anti-cheats e muitos servidores banem. Use em singleplayer/servidor proprio.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            applyTargeting(mc);
        }

        @Override
        public void onMouse(int button) {
            if (button == 0) applyTargeting(Minecraft.getMinecraft());
        }
    }

    public static class HitboxExpand extends Module {
        final Setting amount = add(Setting.number("Expand", 0.3, 0.0, 1.5, 0.05));
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", true));
        final Setting animals = add(Setting.toggle("Animals", true));

        public HitboxExpand() {
            super("Hitbox Expand", "Aumenta a hitbox de players, mobs e animais para acertar mais facil.", Category.COMBAT);
            note = "Cheat de PvP. Pode causar ban em servidores com anti-cheat.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            applyTargeting(mc);
        }

        @Override
        public void onMouse(int button) {
            if (button == 0) applyTargeting(Minecraft.getMinecraft());
        }
    }

    // ------------------------------------------------------------------
    //  AutoClick (clica em qualquer lugar: ar, blocos e entidades)
    // ------------------------------------------------------------------
    public static class AutoClick extends Module {
        final Setting cps = add(Setting.number("CPS", 14, 1, 20, 1));
        final Setting jitter = add(Setting.number("Randomize", 2, 0, 6, 1));
        final Setting left = add(Setting.toggle("Left Click", true));
        final Setting right = add(Setting.toggle("Right Click", false));
        final Setting rightBlocksOnly = add(Setting.toggle("Right: only blocks", true));
        private float accL, accR;

        public AutoClick() {
            super("AutoClick", "Segure o mouse e ele clica sozinho em qualquer lugar (ar, bloco, player, mob).", Category.COMBAT);
            note = "Automacao de cliques e proibida em muitos servidores.";
        }

        private float rate() {
            float c = cps.f() + (jitter.f() > 0 ? (RND.nextFloat() * 2f - 1f) * jitter.f() : 0f);
            return Math.max(1f, Math.min(20f, c));
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null || !mc.inGameHasFocus) {
                accL = accR = 0f;
                return;
            }
            if (left.b() && Mouse.isButtonDown(0)) {
                accL += rate() / 20f;
                if (accL >= 1f) {
                    accL -= 1f;
                    resetClickDelay(mc);
                    KeyBinding.onTick(mc.gameSettings.keyBindAttack.getKeyCode());
                    Stats.click(0);
                }
            } else accL = 0f;
            if (right.b() && Mouse.isButtonDown(1) && !mc.thePlayer.isUsingItem()) {
                ItemStack held = mc.thePlayer.getHeldItem();
                boolean ok = !rightBlocksOnly.b() || (held != null && held.getItem() instanceof ItemBlock);
                if (ok) {
                    accR += rate() / 20f;
                    if (accR >= 1f) {
                        accR -= 1f;
                        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
                        Stats.click(1);
                    }
                }
            } else accR = 0f;
        }
    }

    // ------------------------------------------------------------------
    //  Aim Assist: gruda no alvo (yaw + pitch). Galinha no chao = mira vai para baixo.
    // ------------------------------------------------------------------
    public static class AimAssist extends Module {
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", true));
        final Setting animals = add(Setting.toggle("Animals", true));
        final Setting strength = add(Setting.number("Grudar (0-100)", 85, 0, 100, 1));
        final Setting range = add(Setting.number("Range", 6.0, 3, 10, 0.5));
        final Setting fov = add(Setting.number("FOV", 140, 20, 360, 5));
        final Setting vertical = add(Setting.toggle("Vertical (pitch)", true));
        final Setting point = add(Setting.choice("Aim Point", 0, "Center", "Head", "Chest", "Nearest"));
        final Setting activate = add(Setting.choice("Activate", 0, "Hold Click", "Always"));
        final Setting sticky = add(Setting.toggle("Sticky Lock", true));
        final Setting walls = add(Setting.toggle("Ignore Walls", false));
        final Setting keepSprint = add(Setting.toggle("Keep Sprint (nao para de andar)", true));
        private Entity lock;
        private float lostT, scanT;
        private boolean wasSprint;

        public AimAssist() {
            super("Aim Assist", "Gruda no alvo e acompanha suave (galinha/mob baixo = a mira desce junto).", Category.COMBAT);
            note = "Cheat de PvP. Anti-cheats detectam. Use com cuidado.";
        }

        private static double lerp(double a, double b, float t) {
            return a + (b - a) * t;
        }

        /** Ponto de mira com a posicao do alvo interpolada (acompanha suave entre ticks). */
        private double[] aimI(Entity e, EntityPlayer me, int mode, float pt) {
            double[] p = aimPoint(e, me, mode);
            p[0] += lerp(e.lastTickPosX, e.posX, pt) - e.posX;
            p[1] += lerp(e.lastTickPosY, e.posY, pt) - e.posY;
            p[2] += lerp(e.lastTickPosZ, e.posZ, pt) - e.posZ;
            return p;
        }

        private float[] anglesI(EntityPlayer me, double[] p, float pt) {
            double ex = lerp(me.lastTickPosX, me.posX, pt), ey = lerp(me.lastTickPosY, me.posY, pt) + me.getEyeHeight(), ez = lerp(me.lastTickPosZ, me.posZ, pt);
            double dx = p[0] - ex, dz = p[2] - ez, dy = p[1] - ey;
            float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
            float pitch = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
            return new float[]{yaw, pitch};
        }

        private boolean pickOk(Minecraft mc, Entity e, boolean checkFov, float pt) {
            if (!kindOk(e, mc, players.b(), mobs.b(), animals.b())) return false;
            EntityPlayer me = mc.thePlayer;
            if (me.getDistanceToEntity(e) > range.num) return false;
            if (checkFov) {
                float yaw = anglesI(me, aimI(e, me, 0, pt), pt)[0];
                float vy = me.prevRotationYaw + (me.rotationYaw - me.prevRotationYaw) * pt;
                if (Math.abs(MathHelper.wrapAngleTo180_float(yaw - vy)) > fov.num / 2.0) return false;
            }
            return walls.b() || visible(mc, e);
        }

        @Override
        public void onFrame(Minecraft mc, float dt) {
            EntityPlayer me = mc.thePlayer;
            if (mc.currentScreen != null || !mc.inGameHasFocus || strength.num <= 0
                    || (activate.index == 0 && !Mouse.isButtonDown(0))) {
                lock = null;
                lostT = 0f;
                if (me != null) wasSprint = me.isSprinting() || mc.gameSettings.keyBindSprint.isKeyDown();
                return;
            }
            float pt = com.larpclient.EventHandlers.partial;

            // mantem o alvo (sticky) sem refazer raytrace a cada frame
            if (lock != null) {
                boolean ok = sticky.b() && kindOk(lock, mc, players.b(), mobs.b(), animals.b())
                        && me.getDistanceToEntity(lock) <= range.num + 1.5;
                if (ok && !walls.b()) {
                    scanT -= dt;
                    if (scanT <= 0f) {
                        scanT = 0.08f;
                        if (!visible(mc, lock)) lostT += 0.08f;
                        else lostT = 0f;
                    }
                    if (lostT > 0.4f) ok = false;
                }
                if (!ok) lock = null;
            }
            // procura alvo novo no maximo 12x por segundo (evita queda de FPS)
            if (lock == null) {
                scanT -= dt;
                if (scanT > 0f) return;
                scanT = 0.08f;
                lostT = 0f;
                double bestAng = 1e9;
                for (Object o : mc.theWorld.loadedEntityList) {
                    Entity e = (Entity) o;
                    if (!pickOk(mc, e, true, pt)) continue;
                    float[] a = anglesI(me, aimI(e, me, 0, pt), pt);
                    double dy = MathHelper.wrapAngleTo180_float(a[0] - me.rotationYaw);
                    double dp = a[1] - me.rotationPitch;
                    double ang = Math.sqrt(dy * dy + dp * dp);
                    if (ang < bestAng) {
                        bestAng = ang;
                        lock = e;
                    }
                }
            }
            if (lock == null) {
                wasSprint = me.isSprinting() || mc.gameSettings.keyBindSprint.isKeyDown();
                return;
            }

            float[] a = anglesI(me, aimI(lock, me, point.index, pt), pt);
            // enquanto gruda, prev == atual: a camera nao interpola entre ticks (acaba o tremor)
            float vYaw = me.rotationYaw;
            float vPitch = me.rotationPitch;
            float s = (float) (strength.num / 100.0);
            float perTick = Math.min(0.95f, s * s * 0.55f + s * 0.33f);
            float frac = 1f - (float) Math.pow(1f - perTick, Math.max(0.001f, dt) * 20f);
            float dyaw = MathHelper.wrapAngleTo180_float(a[0] - vYaw);
            float dpit = a[1] - vPitch;
            // zona morta pequena: sem micro-correcoes (tremida)
            float dead = 0.06f;
            float ay = Math.abs(dyaw) < dead ? 0f : dyaw * frac;
            me.rotationYaw += ay;
            me.prevRotationYaw = me.rotationYaw;
            if (vertical.b()) {
                float ap = Math.abs(dpit) < dead ? 0f : dpit * frac;
                me.rotationPitch = MathHelper.clamp_float(me.rotationPitch + ap, -90f, 90f);
                me.prevRotationPitch = me.rotationPitch;
            }
            // nao deixa a corrida parar enquanto estiver grudado
            if (keepSprint.b() && wasSprint && mc.gameSettings.keyBindForward.isKeyDown() && !me.isSprinting()
                    && !me.isCollidedHorizontally && !me.isUsingItem() && me.getFoodStats().getFoodLevel() > 6) {
                me.setSprinting(true);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Trigger Bot: bate sozinho quando a mira passa por cima de um alvo
    // ------------------------------------------------------------------
    public static class TriggerBot extends Module {
        final Setting cps = add(Setting.number("CPS", 12, 1, 20, 1));
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", true));
        final Setting animals = add(Setting.toggle("Animals", true));
        private float acc;

        public TriggerBot() {
            super("Trigger Bot", "Ataca automaticamente quando a mira esta em cima de um alvo.", Category.COMBAT);
            note = "Automacao de ataque. Proibido em quase todos os servidores.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.currentScreen != null || !mc.inGameHasFocus) return;
            MovingObjectPosition m = mc.objectMouseOver;
            if (m == null || m.typeOfHit != MovingObjectPosition.MovingObjectType.ENTITY
                    || !kindOk(m.entityHit, mc, players.b(), mobs.b(), animals.b())) {
                acc = Math.min(acc, 0.9f);
                return;
            }
            acc += (cps.f() + (RND.nextFloat() - 0.5f) * 2f) / 20f;
            if (acc >= 1f) {
                acc -= 1f;
                mc.playerController.attackEntity(mc.thePlayer, m.entityHit);
                mc.thePlayer.swingItem();
                Stats.click(0);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Kill Aura
    // ------------------------------------------------------------------
    public static class KillAura extends Module {
        final Setting range = add(Setting.number("Range", 4.0, 3, 6, 0.1));
        final Setting cps = add(Setting.number("CPS", 12, 1, 20, 1));
        final Setting rotate = add(Setting.toggle("Look at target", true));
        final Setting point = add(Setting.choice("Aim Point", 2, "Center", "Head", "Chest", "Nearest"));
        final Setting players = add(Setting.toggle("Players", true));
        final Setting mobs = add(Setting.toggle("Mobs", true));
        final Setting animals = add(Setting.toggle("Animals", false));
        final Setting walls = add(Setting.toggle("Ignore Walls", false));
        final Setting priority = add(Setting.choice("Priority", 0, "Closest", "Lowest HP"));
        private float acc;

        public KillAura() {
            super("Kill Aura", "Ataca sozinho quem esta no alcance (olha para o alvo e bate no CPS escolhido).", Category.COMBAT);
            note = "Cheat blatante. Banimento quase garantido em servidor com anti-cheat.";
        }

        @Override
        public void onPreTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) return;
            EntityPlayer me = mc.thePlayer;
            Entity best = null;
            double bestScore = 1e9;
            for (Object o : mc.theWorld.loadedEntityList) {
                Entity e = (Entity) o;
                if (!kindOk(e, mc, players.b(), mobs.b(), animals.b())) continue;
                double d = me.getDistanceToEntity(e);
                if (d > range.num) continue;
                if (!walls.b() && !visible(mc, e)) continue;
                double sc = priority.index == 0 ? d : ((EntityLivingBase) e).getHealth();
                if (sc < bestScore) {
                    bestScore = sc;
                    best = e;
                }
            }
            if (best == null) {
                acc = Math.min(acc, 0.9f);
                return;
            }
            if (rotate.b()) {
                float[] a = anglesTo(me, aimPoint(best, me, point.index));
                me.rotationYaw = a[0];
                me.prevRotationYaw = a[0];
                me.rotationPitch = MathHelper.clamp_float(a[1], -90f, 90f);
                me.prevRotationPitch = me.rotationPitch;
            }
            acc += (cps.f() + (RND.nextFloat() - 0.5f) * 2f) / 20f;
            if (acc >= 1f) {
                acc -= 1f;
                mc.playerController.attackEntity(me, best);
                me.swingItem();
                Stats.click(0);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Velocity (reduz o knockback recebido)
    // ------------------------------------------------------------------
    public static class Velocity extends Module {
        final Setting horizontal = add(Setting.number("Horizontal %", 60, 0, 100, 5));
        final Setting verticalS = add(Setting.number("Vertical %", 100, 0, 100, 5));
        private boolean done;

        public Velocity() {
            super("Velocity", "Diminui o knockback que voce toma.", Category.COMBAT);
            note = "Cheat de PvP. Anti-cheats detectam.";
        }

        private void apply(Minecraft mc) {
            EntityPlayer p = mc.thePlayer;
            if (p == null) return;
            if (p.hurtTime == 0) {
                done = false;
                return;
            }
            if (!done && p.maxHurtTime > 0 && p.hurtTime >= p.maxHurtTime - 1) {
                p.motionX *= horizontal.num / 100.0;
                p.motionZ *= horizontal.num / 100.0;
                p.motionY *= verticalS.num / 100.0;
                done = true;
            }
        }

        @Override
        public void onPreTick(Minecraft mc) {
            apply(mc);
        }

        @Override
        public void onTick(Minecraft mc) {
            apply(mc);
        }
    }

    // ------------------------------------------------------------------
    //  Legit Scaffold (ninja bridge)
    // ------------------------------------------------------------------
    public static class LegitScaffold extends Module {
        final Setting backOnly = add(Setting.toggle("Only moving back", false));
        final Setting lookDown = add(Setting.toggle("Only looking down", true));
        final Setting autoPlace = add(Setting.toggle("Auto Place", false));
        final Setting delay = add(Setting.number("Place Delay (ticks)", 2, 1, 8, 1));
        private boolean forced;
        private int cd;

        public LegitScaffold() {
            super("Legit Scaffold", "Ninja bridge: agacha sozinho na ponta do bloco enquanto voce coloca blocos.", Category.PLAYER);
            note = "Automacao de teclas. Alguns servidores proibem.";
        }

        @Override
        public void onTick(Minecraft mc) {
            if (mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) {
                release(mc);
                return;
            }
            EntityPlayer p = mc.thePlayer;
            ItemStack held = p.getHeldItem();
            boolean block = held != null && held.getItem() instanceof ItemBlock;
            boolean ok = block && p.onGround;
            if (ok && lookDown.b() && p.rotationPitch < 55f) ok = false;
            if (ok && backOnly.b() && !mc.gameSettings.keyBindBack.isKeyDown()) ok = false;
            if (!ok) {
                release(mc);
                return;
            }
            AxisAlignedBB bb = p.getEntityBoundingBox().offset(p.motionX * 1.5, -0.5, p.motionZ * 1.5);
            boolean edge = mc.theWorld.getCollidingBoundingBoxes(p, bb).isEmpty();
            int sneak = mc.gameSettings.keyBindSneak.getKeyCode();
            boolean physical = sneak > 0 && Keyboard.isKeyDown(sneak);
            if (edge) {
                KeyBinding.setKeyBindState(sneak, true);
                forced = true;
                if (autoPlace.b() && p.isSneaking()) {
                    if (cd > 0) cd--;
                    MovingObjectPosition m = mc.objectMouseOver;
                    if (cd <= 0 && m != null && m.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
                        cd = delay.i();
                    }
                }
            } else if (forced && !physical) {
                KeyBinding.setKeyBindState(sneak, false);
                forced = false;
            }
        }

        private void release(Minecraft mc) {
            if (!forced) return;
            int sneak = mc.gameSettings.keyBindSneak.getKeyCode();
            if (!(sneak > 0 && Keyboard.isKeyDown(sneak))) KeyBinding.setKeyBindState(sneak, false);
            forced = false;
        }

        @Override
        public void onDisable() {
            release(Minecraft.getMinecraft());
        }
    }
}
