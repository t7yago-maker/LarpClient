package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.util.List;

public final class VisualModules {
    private VisualModules() {}

    public static void register(List<Module> l) {
        l.add(new Crosshair());
    }

    public static class Crosshair extends Module {
        final Setting style = add(Setting.choice("Style", 0, "Cross", "Dot", "Circle", "Plus Dot", "X Cross", "Square", "Diamond", "Triangle", "Ring Dot", "T Shape", "Chevron", "Hexagram", "Heart", "Arrow Up", "Brackets", "Circle Cross", "Sniper", "Swirl"));
        final Setting size = add(Setting.number("Size", 5, 1, 15, 1));
        final Setting gap = add(Setting.number("Gap", 3, 0, 10, 1));
        final Setting thick = add(Setting.number("Thickness", 1, 1, 4, 1));
        final Setting color = add(Setting.color("Color", 0xFFFFFFFF));
        final Setting outline = add(Setting.toggle("Outline", true));
        final Setting spin = add(Setting.toggle("Spin", false));

        public Crosshair() {
            super("Custom Crosshair", "Mira personalizada.", Category.VISUAL);
        }

        public void drawCrosshair(ScaledResolution sr) {
            Minecraft mc = Minecraft.getMinecraft();
            float cx = sr.getScaledWidth() / 2f, cy = sr.getScaledHeight() / 2f;
            float g = gap.f(), s = size.f(), t = thick.f();
            int c = color.c();
            String st = style.m();
            if (st.equals("Cross") || st.equals("Plus Dot")) {
                float h = t / 2f;
                if (outline.b()) {
                    float o = 1f;
                    box(cx - g - s - o, cy - h - o, cx - g + o, cy + h + o, 0xFF000000);
                    box(cx + g - o, cy - h - o, cx + g + s + o, cy + h + o, 0xFF000000);
                    box(cx - h - o, cy - g - s - o, cx + h + o, cy - g + o, 0xFF000000);
                    box(cx - h - o, cy + g - o, cx + h + o, cy + g + s + o, 0xFF000000);
                }
                box(cx - g - s, cy - h, cx - g, cy + h, c);
                box(cx + g, cy - h, cx + g + s, cy + h, c);
                box(cx - h, cy - g - s, cx + h, cy - g, c);
                box(cx - h, cy + g, cx + h, cy + g + s, c);
            }
            if (st.equals("Dot") || st.equals("Plus Dot")) {
                if (outline.b()) RenderUtil.circle(cx, cy, t + 1.8f, 0xFF000000);
                RenderUtil.circle(cx, cy, t + 0.8f, c);
            }
            float rot = spin.b() ? (System.currentTimeMillis() % 4000L) / 4000f * 360f : 0f;
            float lw = t + 0.6f;
            float R = g + s * 0.5f;
            if (st.equals("X Cross")) {
                float d = (float) (Math.sqrt(0.5));
                for (int q = 0; q < 4; q++) {
                    double a = Math.toRadians(45 + q * 90 + rot);
                    float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                    if (outline.b()) RenderUtil.line(cx + ca * g, cy + sa * g, cx + ca * (g + s), cy + sa * (g + s), lw + 2f, 0xFF000000);
                    RenderUtil.line(cx + ca * g, cy + sa * g, cx + ca * (g + s), cy + sa * (g + s), lw, c);
                }
            }
            if (st.equals("Square")) {
                if (outline.b()) RenderUtil.roundOutline(cx - R - 1f, cy - R - 1f, R * 2f + 2f, R * 2f + 2f, 0f, lw + 2f, 0xFF000000);
                RenderUtil.roundOutline(cx - R, cy - R, R * 2f, R * 2f, 0f, lw, c);
            }
            if (st.equals("Diamond") || st.equals("Triangle") || st.equals("Hexagram") || st.equals("Heart") || st.equals("Swirl")) {
                int n = st.equals("Diamond") ? 4 : (st.equals("Triangle") ? 3 : 0);
                if (n > 0) {
                    float off = st.equals("Triangle") ? -90f : 0f;
                    for (int q = 0; q < n; q++) {
                        double a0 = Math.toRadians(off + rot + q * 360.0 / n), a1 = Math.toRadians(off + rot + (q + 1) * 360.0 / n);
                        float x0 = cx + (float) Math.cos(a0) * R, y0 = cy + (float) Math.sin(a0) * R;
                        float x1 = cx + (float) Math.cos(a1) * R, y1 = cy + (float) Math.sin(a1) * R;
                        if (outline.b()) RenderUtil.line(x0, y0, x1, y1, lw + 2f, 0xFF000000);
                        RenderUtil.line(x0, y0, x1, y1, lw, c);
                    }
                } else if (st.equals("Hexagram")) {
                    RenderUtil.star(cx, cy, R, rot, lw, c);
                } else if (st.equals("Heart")) {
                    int pts = 28;
                    float px = 0, py = 0;
                    for (int q = 0; q <= pts; q++) {
                        double a = Math.PI * 2.0 * q / pts;
                        float hx = (float) (16 * Math.pow(Math.sin(a), 3)) / 16f * R;
                        float hy = -(float) (13 * Math.cos(a) - 5 * Math.cos(2 * a) - 2 * Math.cos(3 * a) - Math.cos(4 * a)) / 16f * R;
                        if (q > 0) RenderUtil.line(cx + px, cy + py, cx + hx, cy + hy, lw, c);
                        px = hx;
                        py = hy;
                    }
                } else {
                    float px = cx, py = cy;
                    for (int q = 1; q <= 40; q++) {
                        double a = Math.toRadians(rot) + q * 0.35;
                        float rr = R * q / 40f;
                        float nx = cx + (float) Math.cos(a) * rr, ny = cy + (float) Math.sin(a) * rr;
                        RenderUtil.line(px, py, nx, ny, lw, c);
                        px = nx;
                        py = ny;
                    }
                }
            }
            if (st.equals("Ring Dot")) {
                RenderUtil.roundOutline(cx - R, cy - R, R * 2f, R * 2f, R, lw, c);
                RenderUtil.circle(cx, cy, t + 0.8f, c);
            }
            if (st.equals("Circle Cross")) {
                RenderUtil.roundOutline(cx - R, cy - R, R * 2f, R * 2f, R, lw, c);
                box(cx - R - s * 0.6f, cy - lw / 2f, cx - R * 0.35f, cy + lw / 2f, c);
                box(cx + R * 0.35f, cy - lw / 2f, cx + R + s * 0.6f, cy + lw / 2f, c);
                box(cx - lw / 2f, cy - R - s * 0.6f, cx + lw / 2f, cy - R * 0.35f, c);
                box(cx - lw / 2f, cy + R * 0.35f, cx + lw / 2f, cy + R + s * 0.6f, c);
            }
            if (st.equals("T Shape")) {
                box(cx - g - s, cy - lw / 2f, cx - g, cy + lw / 2f, c);
                box(cx + g, cy - lw / 2f, cx + g + s, cy + lw / 2f, c);
                box(cx - lw / 2f, cy + g, cx + lw / 2f, cy + g + s, c);
            }
            if (st.equals("Chevron") || st.equals("Arrow Up")) {
                float a = s + g;
                RenderUtil.line(cx, cy - (st.equals("Arrow Up") ? a : g), cx - a, cy + a * 0.5f, lw, c);
                RenderUtil.line(cx, cy - (st.equals("Arrow Up") ? a : g), cx + a, cy + a * 0.5f, lw, c);
                if (st.equals("Arrow Up")) box(cx - lw / 2f, cy - a, cx + lw / 2f, cy + a * 0.8f, c);
            }
            if (st.equals("Brackets") || st.equals("Sniper")) {
                float k = R, l = Math.max(3f, s * 0.8f);
                for (int sx = -1; sx <= 1; sx += 2) {
                    for (int sy = -1; sy <= 1; sy += 2) {
                        box(cx + sx * k - (sx > 0 ? l : 0f) - (sx < 0 ? 0f : 0f), cy + sy * k - lw / 2f, cx + sx * k + (sx < 0 ? l : 0f), cy + sy * k + lw / 2f, c);
                        box(cx + sx * k - lw / 2f, cy + sy * k - (sy > 0 ? l : 0f), cx + sx * k + lw / 2f, cy + sy * k + (sy < 0 ? l : 0f), c);
                    }
                }
                if (st.equals("Sniper")) {
                    box(cx - R * 2f, cy - 0.5f, cx + R * 2f, cy + 0.5f, RenderUtil.alpha(c, 0.7f));
                    box(cx - 0.5f, cy - R * 2f, cx + 0.5f, cy + R * 2f, RenderUtil.alpha(c, 0.7f));
                    RenderUtil.circle(cx, cy, 1.2f, c);
                }
            }
            if (st.equals("Circle")) {
                float rr = g + s * 0.5f;
                if (outline.b()) RenderUtil.roundOutline(cx - rr - 1f, cy - rr - 1f, (rr + 1f) * 2f, (rr + 1f) * 2f, rr + 1f, t + 2f, 0xFF000000);
                RenderUtil.roundOutline(cx - rr, cy - rr, rr * 2f, rr * 2f, rr, t + 0.5f, c);
            }
        }

        private void box(float x1, float y1, float x2, float y2, int c) {
            RenderUtil.rect(x1, y1, x2, y2, c);
        }
    }
}
