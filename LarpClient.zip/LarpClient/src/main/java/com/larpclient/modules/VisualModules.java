package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.util.List;

public final class VisualModules {
    private VisualModules() {}

    public static void register(List<Module> l) {
        l.add(new Crosshair());
    }

    public static class Crosshair extends Module {
        final Setting style = add(Setting.choice("Style", 0, "Cross", "Dot", "Circle", "Plus Dot"));
        final Setting size = add(Setting.number("Size", 5, 1, 15, 1));
        final Setting gap = add(Setting.number("Gap", 3, 0, 10, 1));
        final Setting thick = add(Setting.number("Thickness", 1, 1, 4, 1));
        final Setting color = add(Setting.color("Color", 0xFFFFFFFF));
        final Setting outline = add(Setting.toggle("Outline", true));

        public Crosshair() {
            super("Custom Crosshair", "Mira personalizada.", Category.VISUAL);
        }

        public void drawCrosshair(ScaledResolution sr) {
            Minecraft mc = Minecraft.getMinecraft();
            float cx = sr.getScaledWidth() / 2f, cy = sr.getScaledHeight() / 2f;
            float g = gap.f(), s = size.f(), t = thick.f();
            int c = color.c();
            String st = style.m();
            if (st.equals("Cross") || st.equals("Plus Dot")) {
                float h = t / 2f;
                if (outline.b()) {
                    float o = 1f;
                    box(cx - g - s - o, cy - h - o, cx - g + o, cy + h + o, 0xFF000000);
                    box(cx + g - o, cy - h - o, cx + g + s + o, cy + h + o, 0xFF000000);
                    box(cx - h - o, cy - g - s - o, cx + h + o, cy - g + o, 0xFF000000);
                    box(cx - h - o, cy + g - o, cx + h + o, cy + g + s + o, 0xFF000000);
                }
                box(cx - g - s, cy - h, cx - g, cy + h, c);
                box(cx + g, cy - h, cx + g + s, cy + h, c);
                box(cx - h, cy - g - s, cx + h, cy - g, c);
                box(cx - h, cy + g, cx + h, cy + g + s, c);
            }
            if (st.equals("Dot") || st.equals("Plus Dot")) {
                if (outline.b()) RenderUtil.circle(cx, cy, t + 1.8f, 0xFF000000);
                RenderUtil.circle(cx, cy, t + 0.8f, c);
            }
            if (st.equals("Circle")) {
                float rr = g + s * 0.5f;
                if (outline.b()) RenderUtil.roundOutline(cx - rr - 1f, cy - rr - 1f, (rr + 1f) * 2f, (rr + 1f) * 2f, rr + 1f, t + 2f, 0xFF000000);
                RenderUtil.roundOutline(cx - rr, cy - rr, rr * 2f, rr * 2f, rr, t + 0.5f, c);
            }
        }

        private void box(float x1, float y1, float x2, float y2, int c) {
            RenderUtil.rect(x1, y1, x2, y2, c);
        }
    }
}
