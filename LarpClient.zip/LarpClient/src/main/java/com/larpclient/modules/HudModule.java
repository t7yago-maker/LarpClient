package com.larpclient.modules;

import com.google.gson.JsonObject;
import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

/** Modulo de HUD arrastavel. Posicao guardada em fracao da tela (funciona em qualquer resolucao). */
public abstract class HudModule extends Module {
    public float xf, yf;
    public int w = 60, h = 14;
    public final Setting scale = add(Setting.number("Scale", 1.0, 0.5, 2.0, 0.05));
    public final Setting bg = add(Setting.toggle("Background", true));
    public final Setting color = add(Setting.color("Text Color", 0xFFFFFFFF));

    protected HudModule(String name, String desc, Category cat, float xf, float yf) {
        super(name, desc, cat);
        this.xf = xf;
        this.yf = yf;
    }

    public abstract void draw(Minecraft mc, float pt);

    @Override
    public void renderOverlay(ScaledResolution sr, float pt) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;
        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate(xf * sr.getScaledWidth(), yf * sr.getScaledHeight(), 0f);
            float s = scale.f();
            GlStateManager.scale(s, s, 1f);
            draw(mc, pt);
        } catch (Throwable ignored) {
        } finally {
            GlStateManager.popMatrix();
            com.larpclient.util.RenderUtil.white();
        }
    }

    @Override
    public void save(JsonObject o) {
        super.save(o);
        o.addProperty("xf", xf);
        o.addProperty("yf", yf);
    }

    @Override
    public void load(JsonObject o) {
        super.load(o);
        try {
            if (o.has("xf")) xf = o.get("xf").getAsFloat();
            if (o.has("yf")) yf = o.get("yf").getAsFloat();
        } catch (Exception ignored) {
        }
    }
}
