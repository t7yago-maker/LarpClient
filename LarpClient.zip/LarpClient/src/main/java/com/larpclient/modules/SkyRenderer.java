package com.larpclient.modules;

import com.larpclient.core.ModuleManager;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.IRenderHandler;
import org.lwjgl.opengl.GL11;

import java.util.Random;

/** Ceu proprio do LarpClient: gradiente, estrelas, sol/lua e emblema. */
public final class SkyRenderer {
    public static final IRenderHandler INSTANCE = new IRenderHandler() {
        @Override
        public void render(float partialTicks, WorldClient world, Minecraft mc) {
            SkyRenderer.draw(partialTicks, world, mc);
        }
    };

    private SkyRenderer() {}

    private static final float[][] STARS = new float[320][3];

    static {
        Random r = new Random(1337L);
        for (int i = 0; i < STARS.length; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double y = r.nextDouble() * 2.0 - 0.3;
            double rad = Math.sqrt(Math.max(0.0, 1.0 - Math.min(1.0, y * y)));
            STARS[i][0] = (float) (Math.cos(a) * rad * 95.0);
            STARS[i][1] = (float) (y * 95.0);
            STARS[i][2] = (float) (Math.sin(a) * rad * 95.0);
        }
    }

    private static void vc(int argb) {
        RenderUtil.color(argb);
    }

    static void draw(float pt, WorldClient world, Minecraft mc) {
        WorldModules.CustomSky sky = ModuleManager.get(WorldModules.CustomSky.class);
        if (sky == null) return;
        int top = sky.top(pt);
        int hor = sky.horizon(pt);
        float day = sky.daylight(pt);

        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableFog();
        GlStateManager.disableAlpha();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // ---- cupula em gradiente ----
        float[] lat = {90f, 70f, 50f, 32f, 18f, 8f, 0f, -12f, -30f, -50f};
        int seg = 28;
        for (int i = 0; i < lat.length - 1; i++) {
            GL11.glBegin(GL11.GL_QUAD_STRIP);
            for (int j = 0; j <= seg; j++) {
                double a = Math.PI * 2.0 * j / seg;
                for (int k = 0; k < 2; k++) {
                    float la = lat[i + k];
                    double rad = Math.cos(Math.toRadians(la)) * 100.0;
                    double y = Math.sin(Math.toRadians(la)) * 100.0;
                    float s = (float) Math.sin(Math.toRadians(la));
                    int c;
                    if (s >= 0f) c = RenderUtil.mix(hor, top, (float) Math.pow(s, 0.55));
                    else c = RenderUtil.mix(hor, RenderUtil.shade(hor, 0.35f), Math.min(1f, -s * 2.5f));
                    vc(c | 0xFF000000);
                    GL11.glVertex3d(Math.cos(a) * rad, y, Math.sin(a) * rad);
                }
            }
            GL11.glEnd();
        }

        // ---- objetos que giram com o tempo ----
        GlStateManager.blendFunc(770, 1);
        GlStateManager.pushMatrix();
        GlStateManager.rotate(-90f, 0f, 1f, 0f);
        GlStateManager.rotate(world.getCelestialAngle(pt) * 360f, 1f, 0f, 0f);

        if (sky.wantStars()) {
            float sa = (1f - day) * 0.95f;
            if (sa > 0.02f) {
                GL11.glPointSize(2f);
                RenderUtil.color(RenderUtil.alpha(0xFFFFFFFF, sa));
                GL11.glBegin(GL11.GL_POINTS);
                for (float[] p : STARS) GL11.glVertex3f(p[0], p[1], p[2]);
                GL11.glEnd();
            }
        }
        if (sky.wantBodies()) {
            disc(95f, 11f, 0xFFFFE9A8);
            disc(-95f, 8f, 0xFFD8E4FF);
        }
        GlStateManager.popMatrix();

        if (sky.wantEmblem()) {
            float t = (System.currentTimeMillis() % 3600000L) / 1000f;
            float a = 0.22f + 0.12f * (float) Math.sin(t * 0.8f);
            GL11.glLineWidth(2f);
            RenderUtil.color(RenderUtil.alpha(0xFFFFFFFF, a * (0.5f + 0.5f * (1f - day))));
            for (int tri = 0; tri < 2; tri++) {
                GL11.glBegin(GL11.GL_LINE_LOOP);
                for (int i = 0; i < 3; i++) {
                    double ang = Math.toRadians(t * 6f + tri * 60 + i * 120);
                    GL11.glVertex3d(Math.cos(ang) * 28.0, 85.0, Math.sin(ang) * 28.0);
                }
                GL11.glEnd();
            }
        }

        // ---- restaura ----
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.depthMask(true);
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static void disc(float y, float r, int col) {
        vc(col);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex3f(0f, y, 0f);
        for (int i = 0; i <= 24; i++) {
            double a = Math.PI * 2.0 * i / 24.0;
            GL11.glVertex3d(Math.cos(a) * r, y, Math.sin(a) * r);
        }
        GL11.glEnd();
    }
}
