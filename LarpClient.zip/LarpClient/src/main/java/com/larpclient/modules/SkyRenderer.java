package com.larpclient.modules;

import com.larpclient.core.ModuleManager;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.IRenderHandler;
import org.lwjgl.opengl.GL11;

import java.util.Random;

/** Ceu proprio do LarpClient: gradiente, estrelas, sol/lua e emblema. */
public final class SkyRenderer {
    public static final IRenderHandler INSTANCE = new IRenderHandler() {
        @Override
        public void render(float partialTicks, WorldClient world, Minecraft mc) {
            SkyRenderer.draw(partialTicks, world, mc);
        }
    };

    private SkyRenderer() {}

    private static final float[][] STARS = new float[320][3];

    static {
        Random r = new Random(1337L);
        for (int i = 0; i < STARS.length; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double y = r.nextDouble() * 2.0 - 0.3;
            double rad = Math.sqrt(Math.max(0.0, 1.0 - Math.min(1.0, y * y)));
            STARS[i][0] = (float) (Math.cos(a) * rad * 95.0);
            STARS[i][1] = (float) (y * 95.0);
            STARS[i][2] = (float) (Math.sin(a) * rad * 95.0);
        }
    }

    private static void vc(int argb) {
        RenderUtil.color(argb);
    }

    static void draw(float pt, WorldClient world, Minecraft mc) {
        WorldModules.CustomSky sky = ModuleManager.get(WorldModules.CustomSky.class);
        if (sky == null) return;
        int top = sky.top(pt);
        int hor = sky.horizon(pt);
        float day = sky.daylight(pt);

        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableFog();
        GlStateManager.disableAlpha();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // ---- cupula em gradiente ----
        float[] lat = {90f, 70f, 50f, 32f, 18f, 8f, 0f, -12f, -30f, -50f};
        int seg = 28;
        for (int i = 0; i < lat.length - 1; i++) {
            GL11.glBegin(GL11.GL_QUAD_STRIP);
            for (int j = 0; j <= seg; j++) {
                double a = Math.PI * 2.0 * j / seg;
                for (int k = 0; k < 2; k++) {
                    float la = lat[i + k];
                    double rad = Math.cos(Math.toRadians(la)) * 100.0;
                    double y = Math.sin(Math.toRadians(la)) * 100.0;
                    float s = (float) Math.sin(Math.toRadians(la));
                    int c;
                    if (s >= 0f) c = RenderUtil.mix(hor, top, (float) Math.pow(s, 0.55));
                    else c = RenderUtil.mix(hor, RenderUtil.shade(hor, 0.35f), Math.min(1f, -s * 2.5f));
                    vc(c | 0xFF000000);
                    GL11.glVertex3d(Math.cos(a) * rad, y, Math.sin(a) * rad);
                }
            }
            GL11.glEnd();
        }

        float tsec = (System.currentTimeMillis() % 100000000L) / 1000f;
        if (sky.isLiquid()) {
            LiquidSky.draw(sky.liquidTheme(), tsec, Math.max(0.35f, day));
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.enableTexture2D();
            GlStateManager.enableAlpha();
            GlStateManager.enableCull();
            GlStateManager.disableBlend();
            GlStateManager.depthMask(true);
            GlStateManager.color(1f, 1f, 1f, 1f);
            return;
        }
        int pi = sky.presetIndex();
        // nebulosa / via lactea (so de noite)
        if (sky.wantNebula() && day < 0.7f) {
            float na = (1f - day) * 0.55f;
            int ncolA = pi == 0 ? 0xFF7A3CFF : pi == 1 ? 0xFFFF3A4A : pi == 3 ? 0xFF22E0C0 : 0xFF5A78FF;
            int ncolB = pi == 0 ? 0xFF3A1AA0 : pi == 1 ? 0xFF8A1020 : pi == 3 ? 0xFF1A7A9A : 0xFF8A5AD0;
            GlStateManager.blendFunc(770, 1);
            Random nr = new Random(99L);
            for (int i = 0; i < 18; i++) {
                float az = nr.nextFloat() * 6.2832f;
                float el = 0.15f + nr.nextFloat() * 1.1f;
                float rx = 18f + nr.nextFloat() * 26f, ry = 8f + nr.nextFloat() * 14f;
                blob(az + tsec * 0.004f, el, rx, ry, (i % 2 == 0) ? ncolA : ncolB, na * (0.35f + 0.4f * nr.nextFloat()), 0.4f * (nr.nextFloat() - 0.5f));
            }
            // faixa da via lactea
            if (pi == 8) {
                for (int i = 0; i < 26; i++) {
                    float az = 0.6f + i * 0.22f;
                    float el = 0.55f + 0.5f * (float) Math.sin(i * 0.26f);
                    blob(az, el, 16f, 7f, 0xFFB8C8FF, na * 0.35f, 0.5f);
                }
            }
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        }

        // ---- objetos que giram com o tempo ----
        GlStateManager.blendFunc(770, 1);
        GlStateManager.pushMatrix();
        GlStateManager.rotate(-90f, 0f, 1f, 0f);
        GlStateManager.rotate(world.getCelestialAngle(pt) * 360f, 1f, 0f, 0f);

        if (sky.wantStars()) {
            float sa = (1f - day) * 0.95f;
            if (sa > 0.02f) {
                GL11.glPointSize(2f);
                RenderUtil.color(RenderUtil.alpha(0xFFFFFFFF, sa));
                GL11.glBegin(GL11.GL_POINTS);
                for (float[] p : STARS) GL11.glVertex3f(p[0], p[1], p[2]);
                GL11.glEnd();
            }
        }
        if (sky.wantBodies()) {
            for (int g = 1; g <= 4; g++) disc(95f, 11f + g * 7f, RenderUtil.alpha(0xFFFFC870, 0.07f));
            disc(95f, 11f, 0xFFFFE9A8);
            disc(95f, 7f, 0xFFFFFFFF);
            for (int g = 1; g <= 3; g++) disc(-95f, 8f + g * 5f, RenderUtil.alpha(0xFFB8D0FF, 0.07f));
            disc(-95f, 8f, 0xFFD8E4FF);
            disc(-92f, 2.2f, 0xFFB0BCD8);
            disc(-95f, 1.6f, 0xFFA8B4D0);
        }
        GlStateManager.popMatrix();

        // nuvens suaves
        if (sky.wantClouds()) {
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            int cl = pi == 2 ? 0xFF2A2A34 : pi == 0 ? 0xFF2A1560 : pi == 1 ? 0xFF6A1018 : RenderUtil.mix(0xFF1C2238, 0xFFFFFFFF, day);
            if (pi == 6) cl = RenderUtil.mix(0xFF402030, 0xFFFFC090, day);
            if (pi == 7) cl = RenderUtil.mix(0xFF181A20, 0xFFC8CCD2, day);
            Random cr = new Random(4242L);
            int n = pi == 7 ? 40 : 24;
            for (int i = 0; i < n; i++) {
                float az = cr.nextFloat() * 6.2832f + tsec * 0.01f;
                float el = 0.12f + cr.nextFloat() * 0.75f;
                float rx = 10f + cr.nextFloat() * 18f, ry = 3f + cr.nextFloat() * 5f;
                float a = (pi == 7 ? 0.55f : 0.38f) * (0.5f + 0.5f * cr.nextFloat());
                blob(az, el, rx, ry, cl, a, 0f);
                blob(az + 0.05f, el + 0.02f, rx * 0.6f, ry * 0.7f, RenderUtil.mix(cl, 0xFFFFFFFF, 0.25f), a * 0.6f, 0f);
            }
        }

        // raios da tempestade (Purple Storm)
        if (sky.wantLightning() && (pi == 0 || pi == 1)) {
            long slot = (long) (tsec * 3f);
            Random lr = new Random(slot * 7919L);
            float phase = (tsec * 3f) % 1f;
            if (lr.nextInt(4) == 0 && phase < 0.45f) {
                float az = lr.nextFloat() * 6.2832f;
                float el0 = 0.9f + lr.nextFloat() * 0.3f;
                float la = 1f - phase / 0.45f;
                GlStateManager.blendFunc(770, 1);
                for (int pass = 0; pass < 2; pass++) {
                    Random bl = new Random(slot * 31L);
                    GL11.glLineWidth(pass == 0 ? 6f : 2f);
                    GL11.glBegin(GL11.GL_LINE_STRIP);
                    float a0 = az, e0 = el0;
                    for (int i = 0; i < 12; i++) {
                        vc(pass == 0 ? RenderUtil.alpha(pi == 1 ? 0xFFFF6040 : 0xFF7A4CFF, la * 0.4f) : RenderUtil.alpha(0xFFFFFFFF, la));
                        GL11.glVertex3d(Math.cos(e0) * Math.cos(a0) * 88.0, Math.sin(e0) * 88.0, Math.cos(e0) * Math.sin(a0) * 88.0);
                        a0 += (bl.nextFloat() - 0.5f) * 0.05f;
                        e0 -= 0.06f + bl.nextFloat() * 0.03f;
                    }
                    GL11.glEnd();
                }
                blob(az, el0, 40f, 20f, pi == 1 ? 0xFFFF5030 : 0xFF6A40FF, la * 0.35f, 0f);
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            }
        }

        if (sky.wantEmblem()) {
            float t = (System.currentTimeMillis() % 3600000L) / 1000f;
            float a = 0.22f + 0.12f * (float) Math.sin(t * 0.8f);
            GL11.glLineWidth(2f);
            RenderUtil.color(RenderUtil.alpha(0xFFFFFFFF, a * (0.5f + 0.5f * (1f - day))));
            for (int tri = 0; tri < 2; tri++) {
                GL11.glBegin(GL11.GL_LINE_LOOP);
                for (int i = 0; i < 3; i++) {
                    double ang = Math.toRadians(t * 6f + tri * 60 + i * 120);
                    GL11.glVertex3d(Math.cos(ang) * 28.0, 85.0, Math.sin(ang) * 28.0);
                }
                GL11.glEnd();
            }
        }

        // ---- restaura ----
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.depthMask(true);
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Mancha suave na cupula do ceu. az/el em radianos, rx/ry em unidades do ceu. */
    private static void blob(float az, float el, float rx, float ry, int col, float alpha, float tilt) {
        double ce = Math.cos(el), se = Math.sin(el), ca = Math.cos(az), sa = Math.sin(az);
        double cxp = ce * ca * 90.0, cyp = se * 90.0, czp = ce * sa * 90.0;
        double ux = -sa, uz = ca;
        double vx = -se * ca, vy = ce, vz = -se * sa;
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        vc(RenderUtil.alpha(col, alpha));
        GL11.glVertex3d(cxp, cyp, czp);
        vc(RenderUtil.alpha(col, 0f));
        for (int i = 0; i <= 18; i++) {
            double t = Math.PI * 2.0 * i / 18.0;
            double a = Math.cos(t) * rx, b = Math.sin(t) * ry;
            double tx = a * Math.cos(tilt) - b * Math.sin(tilt), ty = a * Math.sin(tilt) + b * Math.cos(tilt);
            GL11.glVertex3d(cxp + ux * tx + vx * ty, cyp + vy * ty, czp + uz * tx + vz * ty);
        }
        GL11.glEnd();
    }

    private static void disc(float y, float r, int col) {
        vc(col);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex3f(0f, y, 0f);
        for (int i = 0; i <= 24; i++) {
            double a = Math.PI * 2.0 * i / 24.0;
            GL11.glVertex3d(Math.cos(a) * r, y, Math.sin(a) * r);
        }
        GL11.glEnd();
    }
}
