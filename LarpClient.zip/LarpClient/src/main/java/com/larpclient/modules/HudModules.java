package com.larpclient.modules;

import com.larpclient.core.Category;
import com.larpclient.core.Module;
import com.larpclient.core.Setting;
import com.larpclient.core.Stats;
import com.larpclient.gui.HudEditor;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Mouse;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class HudModules {
    private HudModules() {}

    public static void register(List<Module> l) {
        l.add(new Fps());
        l.add(new Cps());
        l.add(new Keystrokes());
        l.add(new ReachDisplay());
        l.add(new ComboCounter());
        l.add(new TargetHud());
        l.add(new ArmorHud());
        l.add(new PotionHud());
        l.add(new Coordinates());
        l.add(new Direction());
        l.add(new PingDisplay());
        l.add(new Clock());
        l.add(new Memory());
        l.add(new ModuleList());
    }

    /** HUD de texto simples (uma ou mais linhas). */
    public static abstract class TextHud extends HudModule {
        protected TextHud(String n, String d, Category c, float x, float y) {
            super(n, d, c, x, y);
        }

        protected abstract String[] lines(Minecraft mc);

        @Override
        public void draw(Minecraft mc, float pt) {
            String[] ls = lines(mc);
            FontRenderer fr = mc.fontRendererObj;
            int mw = 0;
            for (String s : ls) mw = Math.max(mw, fr.getStringWidth(s));
            w = mw + 10;
            h = ls.length * 10 + 5;
            if (bg.b()) RenderUtil.roundRect(0, 0, w, h, 3, 0x78000000);
            int col = color.c();
            for (int i = 0; i < ls.length; i++) RenderUtil.text(ls[i], 5, 3 + i * 10, 1f, col, true);
        }
    }

    public static class Fps extends TextHud {
        public Fps() {
            super("FPS Counter", "Mostra os quadros por segundo.", Category.HUD, 0.01f, 0.02f);
            enabled = true;
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{"FPS: " + Minecraft.getDebugFPS()};
        }
    }

    public static class Cps extends TextHud {
        public Cps() {
            super("CPS Counter", "Cliques por segundo (esquerdo | direito).", Category.COMBAT, 0.01f, 0.09f);
            enabled = true;
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{"CPS: " + Stats.cps(Stats.left) + " | " + Stats.cps(Stats.right)};
        }
    }

    public static class ReachDisplay extends TextHud {
        public ReachDisplay() {
            super("Reach Display", "Distancia do ultimo golpe.", Category.COMBAT, 0.01f, 0.16f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{String.format(Locale.US, "Reach: %.2f", Stats.reach)};
        }
    }

    public static class ComboCounter extends TextHud {
        public ComboCounter() {
            super("Combo Counter", "Golpes seguidos sem tomar dano.", Category.COMBAT, 0.01f, 0.23f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{"Combo: " + Stats.combo};
        }
    }

    public static class Coordinates extends TextHud {
        public Coordinates() {
            super("Coordinates", "Posicao X Y Z.", Category.HUD, 0.01f, 0.30f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{
                    String.format(Locale.US, "X: %.1f", mc.thePlayer.posX),
                    String.format(Locale.US, "Y: %.1f", mc.thePlayer.posY),
                    String.format(Locale.US, "Z: %.1f", mc.thePlayer.posZ)};
        }
    }

    public static class Direction extends TextHud {
        private static final String[] DIRS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

        public Direction() {
            super("Direction HUD", "Para onde voce esta olhando.", Category.HUD, 0.01f, 0.42f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            int i = MathHelper.floor_double(mc.thePlayer.rotationYaw * 8.0 / 360.0 + 0.5) & 7;
            return new String[]{"Dir: " + DIRS[i]};
        }
    }

    public static class PingDisplay extends TextHud {
        public PingDisplay() {
            super("Ping Display", "Latencia com o servidor.", Category.HUD, 0.01f, 0.48f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            int ping = 0;
            if (mc.getNetHandler() != null) {
                NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
                if (info != null) ping = info.getResponseTime();
            }
            return new String[]{"Ping: " + ping + " ms"};
        }
    }

    public static class Clock extends TextHud {
        private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss");

        public Clock() {
            super("Clock", "Hora do sistema.", Category.HUD, 0.01f, 0.54f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            return new String[]{fmt.format(new Date())};
        }
    }

    public static class Memory extends TextHud {
        public Memory() {
            super("Memory", "Memoria usada pelo jogo.", Category.HUD, 0.01f, 0.60f);
        }

        @Override
        protected String[] lines(Minecraft mc) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            return new String[]{"RAM: " + used + " / " + (rt.maxMemory() / 1048576L) + " MB"};
        }
    }

    public static class PotionHud extends HudModule {
        public PotionHud() {
            super("Potion HUD", "Efeitos de pocao ativos.", Category.HUD, 0.84f, 0.02f);
        }

        @Override
        public void draw(Minecraft mc, float pt) {
            Collection<PotionEffect> ef = mc.thePlayer.getActivePotionEffects();
            List<String> ls = new ArrayList<String>();
            for (PotionEffect e : ef) {
                ls.add(I18n.format(e.getEffectName()) + " " + (e.getAmplifier() + 1) + "  "
                        + net.minecraft.potion.Potion.getDurationString(e));
            }
            if (ls.isEmpty() && mc.currentScreen instanceof HudEditor) ls.add("Speed 2  1:30");
            if (ls.isEmpty()) return;
            int mw = 0;
            for (String s : ls) mw = Math.max(mw, mc.fontRendererObj.getStringWidth(s));
            w = mw + 10;
            h = ls.size() * 10 + 5;
            if (bg.b()) RenderUtil.roundRect(0, 0, w, h, 3, 0x78000000);
            for (int i = 0; i < ls.size(); i++) RenderUtil.text(ls.get(i), 5, 3 + i * 10, 1f, color.c(), true);
        }
    }

    public static class ArmorHud extends HudModule {
        final Setting held = add(Setting.toggle("Show Held Item", true));

        public ArmorHud() {
            super("Armor HUD", "Armadura e item na mao com durabilidade.", Category.HUD, 0.88f, 0.45f);
        }

        @Override
        public void draw(Minecraft mc, float pt) {
            List<ItemStack> items = new ArrayList<ItemStack>();
            for (int i = 3; i >= 0; i--) {
                ItemStack s = mc.thePlayer.inventory.armorInventory[i];
                if (s != null) items.add(s);
            }
            ItemStack hand = mc.thePlayer.getHeldItem();
            if (held.b() && hand != null) items.add(hand);
            w = 64;
            h = Math.max(items.size(), 1) * 18 + 4;
            if (items.isEmpty() && !(mc.currentScreen instanceof HudEditor)) return;
            if (bg.b()) RenderUtil.roundRect(0, 0, w, h, 3, 0x78000000);
            for (int i = 0; i < items.size(); i++) {
                ItemStack s = items.get(i);
                int y = 2 + i * 18;
                GlStateManager.enableRescaleNormal();
                RenderHelper.enableGUIStandardItemLighting();
                mc.getRenderItem().renderItemAndEffectIntoGUI(s, 3, y);
                mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, s, 3, y);
                RenderHelper.disableStandardItemLighting();
                GlStateManager.disableRescaleNormal();
                String d = s.isItemStackDamageable() ? String.valueOf(s.getMaxDamage() - s.getItemDamage()) : "";
                RenderUtil.text(d, 24, y + 5, 1f, color.c(), true);
            }
        }
    }

    public static class Keystrokes extends HudModule {
        public Keystrokes() {
            super("Keystrokes", "Teclas WASD e cliques na tela.", Category.COMBAT, 0.01f, 0.68f);
        }

        private void box(int x, int y, int bw, int bh, String label, boolean down) {
            RenderUtil.roundRect(x, y, bw, bh, 3, down ? 0xCC2F6BFF : 0x80000000);
            RenderUtil.textC(label, x + bw / 2f, y + (bh - 8) / 2f, 1f, color.c(), true);
        }

        @Override
        public void draw(Minecraft mc, float pt) {
            int k = 22, g = 2;
            w = k * 3 + g * 2;
            h = k * 2 + g * 2 + 20 + g + 12;
            KeyBinding[] kb = {mc.gameSettings.keyBindForward, mc.gameSettings.keyBindLeft,
                    mc.gameSettings.keyBindBack, mc.gameSettings.keyBindRight};
            box(k + g, 0, k, k, "W", kb[0].isKeyDown());
            box(0, k + g, k, k, "A", kb[1].isKeyDown());
            box(k + g, k + g, k, k, "S", kb[2].isKeyDown());
            box((k + g) * 2, k + g, k, k, "D", kb[3].isKeyDown());
            int bw = (w - g) / 2;
            int y2 = (k + g) * 2;
            box(0, y2, bw, 20, "LMB " + Stats.cps(Stats.left), Mouse.isButtonDown(0));
            box(bw + g, y2, bw, 20, "RMB " + Stats.cps(Stats.right), Mouse.isButtonDown(1));
            box(0, y2 + 22, w, 12, "", mc.gameSettings.keyBindJump.isKeyDown());
        }
    }

    public static class TargetHud extends HudModule {
        final Setting dur = add(Setting.number("Show Seconds", 3, 1, 10, 1));
        private float shown = -1f;

        public TargetHud() {
            super("Target HUD", "Vida e distancia do alvo.", Category.COMBAT, 0.62f, 0.62f);
            enabled = true;
        }

        @Override
        public void draw(Minecraft mc, float pt) {
            EntityLivingBase t = Stats.target;
            boolean preview = mc.currentScreen instanceof HudEditor;
            long now = System.currentTimeMillis();
            boolean live = t != null && t.isEntityAlive() && now - Stats.targetTime <= dur.i() * 1000L;
            if (!live && !preview) {
                shown = -1f;
                return;
            }
            String name = live ? t.getName() : "Target";
            float hp = live ? t.getHealth() : 20f;
            float max = live ? Math.max(1f, t.getMaxHealth()) : 20f;
            if (shown < 0f) shown = hp;
            shown += (hp - shown) * 0.15f;
            float pct = Math.max(0f, Math.min(1f, shown / max));
            w = 130;
            h = 38;
            if (bg.b()) RenderUtil.roundRect(0, 0, w, h, 4, 0xB0101014);
            if (live && t instanceof AbstractClientPlayer) {
                mc.getTextureManager().bindTexture(((AbstractClientPlayer) t).getLocationSkin());
                GlStateManager.color(1f, 1f, 1f, 1f);
                Gui.drawScaledCustomSizeModalRect(5, 5, 8, 8, 8, 8, 28, 28, 64, 64);
                Gui.drawScaledCustomSizeModalRect(5, 5, 40, 8, 8, 8, 28, 28, 64, 64);
            } else {
                RenderUtil.star(19, 19, 11, 0, 1.5f, 0xFFFFFFFF);
            }
            RenderUtil.text(name, 38, 5, 1f, color.c(), true);
            RenderUtil.rect(38, 17, 124, 22, 0xFF26262C);
            RenderUtil.rect(38, 17, 38 + 86 * pct, 22, RenderUtil.hsb(pct * 0.33f, 0.85f, 1f));
            float dist = live ? mc.thePlayer.getDistanceToEntity(t) : 3f;
            RenderUtil.text(String.format(Locale.US, "%.1f / %.1f  -  %.1fm", hp, max, dist), 38, 26, 0.8f, 0xFFB8B8C0, true);
        }
    }

    /** Lista de modulos ativos estilo "hacked client". */
    public static class ModuleList extends HudModule {
        final Setting rainbowSetting = add(Setting.toggle("Rainbow", true));

        public ModuleList() {
            super("Module List", "Lista dos modulos ligados (estilo hacker).", Category.HUD, 0.78f, 0.25f);
        }

        @Override
        public void draw(Minecraft mc, float pt) {
            java.util.List<Module> on = new java.util.ArrayList<Module>();
            for (Module m : com.larpclient.core.ModuleManager.all) {
                if (m.enabled && m != this && m.category != Category.HUD && m.category != Category.COSMETICS) on.add(m);
            }
            final FontRenderer fr = mc.fontRendererObj;
            java.util.Collections.sort(on, new java.util.Comparator<Module>() {
                @Override
                public int compare(Module a, Module b) {
                    return fr.getStringWidth(b.name) - fr.getStringWidth(a.name);
                }
            });
            int mw = 60;
            for (Module m : on) mw = Math.max(mw, fr.getStringWidth(m.name) + 8);
            w = mw;
            h = Math.max(12, on.size() * 10 + 4);
            for (int i = 0; i < on.size(); i++) {
                String n = on.get(i).name;
                int col = rainbowSetting.b() ? RenderUtil.rainbow(i * 0.07f) : color.c();
                float x = w - fr.getStringWidth(n) - 4;
                if (bg.b()) RenderUtil.rect(x - 2, 2 + i * 10, w, 12 + i * 10, 0x78000000);
                RenderUtil.rect(w - 1, 2 + i * 10, w, 12 + i * 10, col);
                RenderUtil.text(n, x, 3 + i * 10, 1f, col, true);
            }
        }
    }
}
