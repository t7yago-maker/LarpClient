package com.larpclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

public final class RenderUtil {
    /** Cores da paleta. 0 = arco-iris. */
    public static final int[] PALETTE = {
            0xFF2F6BFF, 0xFF00E5FF, 0xFF9B30FF, 0xFFFF2D55, 0xFFFF8A00,
            0xFFFFD60A, 0xFF34C759, 0xFFFFFFFF, 0xFFFF4FD8, 0
    };
    public static float alphaMul = 1f;

    private RenderUtil() {}

    // ---------- cores ----------
    public static int hsb(float h, float s, float b) {
        h = h - (float) Math.floor(h);
        float hh = h * 6f;
        int i = (int) Math.floor(hh);
        float f = hh - i;
        float p = b * (1 - s), q = b * (1 - s * f), t = b * (1 - s * (1 - f));
        float r, g, bl;
        switch (i % 6) {
            case 0: r = b; g = t; bl = p; break;
            case 1: r = q; g = b; bl = p; break;
            case 2: r = p; g = b; bl = t; break;
            case 3: r = p; g = q; bl = b; break;
            case 4: r = t; g = p; bl = b; break;
            default: r = b; g = p; bl = q; break;
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (bl * 255);
    }

    public static int rainbow(float offset) {
        return hsb((System.currentTimeMillis() % 6000L) / 6000f + offset, 0.7f, 1f);
    }

    public static int resolve(int c) { return c == 0 ? rainbow(0f) : c; }

    public static int mix(int a, int b, float t) {
        t = Anim.clamp01(t);
        int ca = (int) (((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t);
        int cr = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int cg = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int cb = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (ca << 24) | (cr << 16) | (cg << 8) | cb;
    }

    public static int alpha(int argb, float a) {
        int al = (int) (((argb >>> 24) & 255) * Anim.clamp01(a));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    public static int shade(int argb, float k) {
        int r = Math.min(255, (int) (((argb >> 16) & 255) * k));
        int g = Math.min(255, (int) (((argb >> 8) & 255) * k));
        int b = Math.min(255, (int) ((argb & 255) * k));
        return (argb & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    // ---------- estado GL ----------
    public static void begin() {
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableAlpha();
        GlStateManager.disableLighting();
    }

    public static void end() {
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public static void color(int argb) {
        float a = ((argb >>> 24) & 255) / 255f * alphaMul;
        GL11.glColor4f(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, a);
    }

    // ---------- formas 2D ----------
    public static void rect(float x1, float y1, float x2, float y2, int argb) {
        begin();
        color(argb);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2f(x1, y2);
        GL11.glVertex2f(x2, y2);
        GL11.glVertex2f(x2, y1);
        GL11.glVertex2f(x1, y1);
        GL11.glEnd();
        end();
    }

    public static void gradV(float x1, float y1, float x2, float y2, int top, int bottom) {
        begin();
        GL11.glShadeModel(GL11.GL_SMOOTH);
        GL11.glBegin(GL11.GL_QUADS);
        color(top);
        GL11.glVertex2f(x2, y1);
        GL11.glVertex2f(x1, y1);
        color(bottom);
        GL11.glVertex2f(x1, y2);
        GL11.glVertex2f(x2, y2);
        GL11.glEnd();
        GL11.glShadeModel(GL11.GL_FLAT);
        end();
    }

    private static void corner(float cx, float cy, float r, int a0, int a1) {
        for (int i = 0; i <= 6; i++) {
            double a = Math.toRadians(a0 + (a1 - a0) * i / 6.0);
            GL11.glVertex2d(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
        }
    }

    private static void roundPath(float x, float y, float w, float h, float r) {
        corner(x + w - r, y + r, r, 270, 360);
        corner(x + w - r, y + h - r, r, 0, 90);
        corner(x + r, y + h - r, r, 90, 180);
        corner(x + r, y + r, r, 180, 270);
    }

    public static void roundRect(float x, float y, float w, float h, float r, int argb) {
        begin();
        color(argb);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex2f(x + w / 2f, y + h / 2f);
        roundPath(x, y, w, h, r);
        GL11.glVertex2f(x + w - r, y);
        GL11.glEnd();
        end();
    }

    public static void roundOutline(float x, float y, float w, float h, float r, float lw, int argb) {
        begin();
        color(argb);
        GL11.glLineWidth(lw);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        roundPath(x, y, w, h, r);
        GL11.glEnd();
        end();
    }

    public static void circle(float cx, float cy, float r, int argb) {
        begin();
        color(argb);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex2f(cx, cy);
        for (int i = 0; i <= 28; i++) {
            double a = Math.PI * 2 * i / 28.0;
            GL11.glVertex2d(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
        }
        GL11.glEnd();
        end();
    }

    public static void line(float x1, float y1, float x2, float y2, float lw, int argb) {
        begin();
        color(argb);
        GL11.glLineWidth(lw);
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y2);
        GL11.glEnd();
        end();
    }

    /** Estrela de Davi (dois triangulos). */
    public static void star(float cx, float cy, float r, float rotDeg, float lw, int argb) {
        begin();
        color(argb);
        GL11.glLineWidth(lw);
        for (int t = 0; t < 2; t++) {
            GL11.glBegin(GL11.GL_LINE_LOOP);
            for (int i = 0; i < 3; i++) {
                double a = Math.toRadians(rotDeg - 90 + t * 60 + i * 120);
                GL11.glVertex2d(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
            }
            GL11.glEnd();
        }
        end();
    }

    // ---------- texto ----------
    public static void text(String s, float x, float y, float scale, int argb, boolean shadow) {
        float a = ((argb >>> 24) & 255) * alphaMul;
        if (a < 6f) return;
        int col = (((int) a) << 24) | (argb & 0xFFFFFF);
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(scale, scale, 1f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        fr.drawString(s, 0, 0, col, shadow);
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public static float width(String s, float scale) {
        return Minecraft.getMinecraft().fontRendererObj.getStringWidth(s) * scale;
    }

    public static void textC(String s, float cx, float y, float scale, int argb, boolean shadow) {
        text(s, cx - width(s, scale) / 2f, y, scale, argb, shadow);
    }

    // ---------- camera / mundo ----------
    public static double camX(float pt) {
        Entity e = Minecraft.getMinecraft().getRenderViewEntity();
        return e.lastTickPosX + (e.posX - e.lastTickPosX) * pt;
    }

    public static double camY(float pt) {
        Entity e = Minecraft.getMinecraft().getRenderViewEntity();
        return e.lastTickPosY + (e.posY - e.lastTickPosY) * pt;
    }

    public static double camZ(float pt) {
        Entity e = Minecraft.getMinecraft().getRenderViewEntity();
        return e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt;
    }

    /** Texto no mundo virado para a camera. x,y,z relativos a camera. */
    public static void worldText(String s, double x, double y, double z, float scale, int argb) {
        Minecraft mc = Minecraft.getMinecraft();
        RenderManager rm = mc.getRenderManager();
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
        GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);
        GlStateManager.scale(-scale, -scale, scale);
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        FontRenderer fr = mc.fontRendererObj;
        fr.drawString(s, -fr.getStringWidth(s) / 2, 0, argb, true);
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }
}
