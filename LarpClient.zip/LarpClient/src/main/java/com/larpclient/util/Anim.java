package com.larpclient.util;

public final class Anim {
    private Anim() {}

    public static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    public static float easeOut(float t) { t = clamp01(t); return 1f - (float) Math.pow(1f - t, 3); }
    public static float easeInOut(float t) {
        t = clamp01(t);
        return t < 0.5f ? 4f * t * t * t : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }
}
