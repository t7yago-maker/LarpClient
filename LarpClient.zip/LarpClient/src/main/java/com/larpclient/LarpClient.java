package com.larpclient;

import com.larpclient.core.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = LarpClient.MODID, name = "LarpClient", version = LarpClient.VERSION,
        acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public class LarpClient {
    public static final String MODID = "larpclient";
    public static final String VERSION = "0.3.0";

    public static KeyBinding openGui;
    public static KeyBinding zoomKey;
    public static KeyBinding perspectiveKey;

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        openGui = new KeyBinding("Open LarpClient", Keyboard.KEY_RSHIFT, "LarpClient");
        zoomKey = new KeyBinding("Zoom", Keyboard.KEY_C, "LarpClient");
        perspectiveKey = new KeyBinding("Perspective (hold)", Keyboard.KEY_Q, "LarpClient");
        ClientRegistry.registerKeyBinding(perspectiveKey);
        ClientRegistry.registerKeyBinding(openGui);
        ClientRegistry.registerKeyBinding(zoomKey);
        ModuleManager.init(Minecraft.getMinecraft().mcDataDir);
        MinecraftForge.EVENT_BUS.register(new EventHandlers());
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                ModuleManager.save();
            }
        }));
    }
}
