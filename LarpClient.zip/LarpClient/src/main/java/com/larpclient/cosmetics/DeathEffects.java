package com.larpclient.cosmetics;

import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Kill effects 3D estilo After Effects: pre-morte (congela, treme, separacao RGB, linhas convergindo, flash,
 * onda de choque, camera tremendo) e depois um meme 3D em voxel que faz sua animacao e explode em confete.
 */
public final class DeathEffects {
    private DeathEffects() {}

    public static final String[] NAMES = {
            "Tung Tung Sahur", "Tralalero Tralala", "Bombardiro Crocodilo", "Skibidi Toilet",
            "Among Us (Sus)", "Troll Face", "AE Shockwave", "Random Meme"};

    private static final float PRE = 1.0f;
    private static final float MEME = 3.2f;
    private static final float TOTAL = PRE + MEME + 0.6f;

    private static final class Fx {
        double x, y, z;
        int style, color, snd;
        float scale, yaw, vw, vh;
        boolean player;
        long t0, seed;
    }

    private static final List<Fx> LIST = new ArrayList<Fx>();
    private static final Random RND = new Random();
    private static float shake, flash;

    public static void spawn(Entity e, int style, int color, float scale) {
        Minecraft mc = Minecraft.getMinecraft();
        Fx f = new Fx();
        f.x = e.posX;
        f.y = e.posY;
        f.z = e.posZ;
        f.style = style >= 7 ? RND.nextInt(6) : style;
        f.color = color;
        f.scale = scale;
        f.vw = Math.max(0.3f, e.width);
        f.vh = Math.max(0.4f, e.height);
        f.player = e instanceof EntityPlayer;
        if (mc.thePlayer != null) {
            f.yaw = (float) Math.toDegrees(Math.atan2(mc.thePlayer.posX - f.x, mc.thePlayer.posZ - f.z));
        }
        f.t0 = System.currentTimeMillis();
        f.seed = RND.nextLong();
        LIST.add(f);
    }

    // ------------------------------------------------------------ camera / overlay
    public static void camera(EntityViewRenderEvent.CameraSetup e) {
        if (shake <= 0.001f) return;
        float t = System.nanoTime() / 1.0e9f;
        e.roll += (float) Math.sin(t * 61f) * shake * 2.2f;
        e.yaw += (float) Math.sin(t * 47f + 1f) * shake * 0.9f;
        e.pitch += (float) Math.sin(t * 53f + 2f) * shake * 0.9f;
    }

    public static void overlay(ScaledResolution sr) {
        if (flash <= 0.01f) return;
        RenderUtil.rect(0, 0, sr.getScaledWidth(), sr.getScaledHeight(), ((int) (Math.min(1f, flash) * 200f) << 24) | 0xFFFFFF);
    }

    // ------------------------------------------------------------------ render
    public static void render(float pt) {
        shake = 0f;
        flash = 0f;
        if (LIST.isEmpty()) return;
        Minecraft mc = Minecraft.getMinecraft();
        long now = System.currentTimeMillis();
        double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
        for (int i = LIST.size() - 1; i >= 0; i--) {
            Fx f = LIST.get(i);
            float age = (now - f.t0) / 1000f;
            if (age > TOTAL) {
                LIST.remove(i);
                continue;
            }
            double dist = mc.thePlayer == null ? 0 : Math.sqrt((mc.thePlayer.posX - f.x) * (mc.thePlayer.posX - f.x) + (mc.thePlayer.posZ - f.z) * (mc.thePlayer.posZ - f.z));
            float near = (float) Math.max(0.0, 1.0 - dist / 30.0);
            float da = age - PRE;
            float sh = age < PRE ? (age / PRE) * (age / PRE) * 0.8f : (da < 0.5f ? 1f - da / 0.5f : 0f);
            shake = Math.max(shake, sh * near);
            if (da > -0.08f && da < 0.35f) flash = Math.max(flash, (da < 0.05f ? (da + 0.08f) / 0.13f : 1f - (da - 0.05f) / 0.3f) * near);
            sounds(mc, f, age);

            GlStateManager.pushMatrix();
            GlStateManager.translate(f.x - cx, f.y - cy, f.z - cz);
            GlStateManager.scale(f.scale, f.scale, f.scale);
            RenderUtil.begin();
            GlStateManager.disableCull();
            GlStateManager.enableDepth();
            if (age < PRE + 0.12f) pre(f, age, pt);
            if (age >= PRE - 0.02f) {
                if (age - PRE < 0.7f) burst(f, age - PRE);
                float mt = age - PRE;
                if (f.style < 6 && mt < MEME) meme(f, mt);
                if (mt > MEME - 0.2f) confetti(f, mt - (MEME - 0.2f), 1.8f);
            }
            RenderUtil.end();
            GlStateManager.enableCull();
            GlStateManager.popMatrix();
        }
        RenderUtil.alphaMul = 1f;
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static void play(Minecraft mc, Fx f, String s, float vol, float pitch) {
        try {
            mc.theWorld.playSound(f.x, f.y, f.z, s, vol, pitch, false);
        } catch (Throwable ignored) {
        }
    }

    private static void sounds(Minecraft mc, Fx f, float age) {
        if ((f.snd & 1) == 0 && age > 0.02f) {
            f.snd |= 1;
            play(mc, f, "mob.endermen.portal", 1f, 0.5f);
        }
        if ((f.snd & 2) == 0 && age > PRE) {
            f.snd |= 2;
            play(mc, f, "random.explode", 1f, 0.7f);
        }
        float mt = age - PRE;
        if (mt < 0f) return;
        if (f.style == 0) { // tung tung tung sahur
            for (int k = 0; k < 4; k++) {
                int bit = 4 << k;
                if ((f.snd & bit) == 0 && mt > 0.1f + k * 0.45f) {
                    f.snd |= bit;
                    play(mc, f, "note.bd", 1f, k == 3 ? 1.5f : 0.8f);
                    play(mc, f, "note.bassattack", 0.8f, k == 3 ? 1.2f : 0.6f);
                }
            }
        } else if (f.style == 3) { // skibidi
            float[] p = {0.9f, 1.05f, 1.2f, 1.05f, 0.9f, 1.05f, 1.35f, 1.2f};
            for (int k = 0; k < 8; k++) {
                int bit = 4 << k;
                if ((f.snd & bit) == 0 && mt > 0.1f + k * 0.3f) {
                    f.snd |= bit;
                    play(mc, f, "note.harp", 1f, p[k]);
                    play(mc, f, "note.snare", 0.6f, 1f);
                }
            }
        } else if (f.style == 2) { // bombardiro
            for (int k = 0; k < 5; k++) {
                int bit = 4 << k;
                if ((f.snd & bit) == 0 && mt > 0.3f + k * 0.5f + 0.68f) {
                    f.snd |= bit;
                    play(mc, f, "random.explode", 0.9f, 1f + k * 0.05f);
                }
            }
        } else if (f.style == 1) {
            for (int k = 0; k < 6; k++) {
                int bit = 4 << k;
                if ((f.snd & bit) == 0 && mt > 0.15f + k * 0.4f) {
                    f.snd |= bit;
                    play(mc, f, "note.pling", 0.9f, 0.8f + (k % 3) * 0.25f);
                }
            }
        } else if (f.style == 4) {
            if ((f.snd & 4) == 0 && mt > 0.2f) {
                f.snd |= 4;
                play(mc, f, "mob.villager.no", 1f, 0.8f);
            }
            if ((f.snd & 8) == 0 && mt > 1.4f) {
                f.snd |= 8;
                play(mc, f, "mob.endermen.portal", 1f, 1.5f);
            }
        } else if (f.style == 5) {
            if ((f.snd & 4) == 0 && mt > 0.3f) {
                f.snd |= 4;
                play(mc, f, "mob.villager.haggle", 1f, 0.6f);
            }
        }
        if ((f.snd & 0x40000) == 0 && mt > MEME - 0.2f) {
            f.snd |= 0x40000;
            play(mc, f, "random.levelup", 1f, 1.1f);
        }
    }

    // ------------------------------------------------------------ helpers
    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        float c1 = 1.70158f, c3 = c1 + 1f;
        float u = x - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    private static void ringY(float r, float w, int col, float a) {
        GL11.glBegin(GL11.GL_QUAD_STRIP);
        for (int i = 0; i <= 40; i++) {
            double an = Math.PI * 2.0 * i / 40.0;
            RenderUtil.color(RenderUtil.alpha(col, a));
            GL11.glVertex3d(Math.cos(an) * (r - w), 0, Math.sin(an) * (r - w));
            RenderUtil.color(RenderUtil.alpha(col, a * 0.2f));
            GL11.glVertex3d(Math.cos(an) * (r + w), 0, Math.sin(an) * (r + w));
        }
        GL11.glEnd();
    }

    private static void billboardGlow(float x, float y, float z, float r, int col, float a) {
        Minecraft mc = Minecraft.getMinecraft();
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0f, 1f, 0f);
        GlStateManager.rotate(mc.getRenderManager().playerViewX, 1f, 0f, 0f);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        RenderUtil.color(RenderUtil.alpha(col, a));
        GL11.glVertex3f(0f, 0f, 0f);
        RenderUtil.color(RenderUtil.alpha(col, 0f));
        for (int i = 0; i <= 18; i++) {
            double an = Math.PI * 2.0 * i / 18.0;
            GL11.glVertex3f((float) Math.cos(an) * r, (float) Math.sin(an) * r, 0f);
        }
        GL11.glEnd();
        GlStateManager.popMatrix();
    }

    private static void add() {
        GlStateManager.blendFunc(770, 1);
        GlStateManager.depthMask(false);
    }

    private static void norm() {
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
    }

    private static void label(String s, float y, float size, int col) {
        GlStateManager.depthMask(true);
        RenderUtil.worldText(s, 0, y, 0, size, col);
        RenderUtil.begin();
        GlStateManager.disableCull();
    }

    // ------------------------------------------------------------------ fase 1: pre-morte
    private static void humanoid(Fx f, int col) {
        float h = f.vh;
        if (f.player) {
            float k = h / 1.8f;
            Vox.box(-0.25f * k, 0.72f * k, -0.125f * k, 0.25f * k, 1.35f * k, 0.125f * k, col);   // corpo
            Vox.box(-0.25f * k, 1.35f * k, -0.25f * k, 0.25f * k, 1.85f * k, 0.25f * k, col);     // cabeca
            Vox.box(-0.5f * k, 0.72f * k, -0.125f * k, -0.25f * k, 1.35f * k, 0.125f * k, col);   // bracos
            Vox.box(0.25f * k, 0.72f * k, -0.125f * k, 0.5f * k, 1.35f * k, 0.125f * k, col);
            Vox.box(-0.25f * k, 0f, -0.125f * k, 0f, 0.72f * k, 0.125f * k, col);                  // pernas
            Vox.box(0f, 0f, -0.125f * k, 0.25f * k, 0.72f * k, 0.125f * k, col);
        } else {
            Vox.box(-f.vw / 2f, 0f, -f.vw / 2f, f.vw / 2f, h, f.vw / 2f, col);
        }
    }

    private static void pre(Fx f, float age, float pt) {
        float p = Math.min(1f, age / PRE);
        float fade = age > PRE ? Math.max(0f, 1f - (age - PRE) / 0.12f) : 1f;
        Random r = new Random(f.seed + (long) (age * 28f));
        float amp = 0.01f + 0.12f * p * p;
        // silhueta tremendo com separacao RGB
        add();
        int[] ch = {0xFFFF2020, 0xFF20FF40, 0xFF3050FF};
        for (int c = 0; c < 3; c++) {
            GlStateManager.pushMatrix();
            float ox = (c - 1) * amp * 1.4f + (r.nextFloat() - 0.5f) * amp;
            GlStateManager.translate(ox, (r.nextFloat() - 0.5f) * amp * 0.5f, (r.nextFloat() - 0.5f) * amp);
            float sc = 1f + p * 0.12f * (r.nextFloat());
            GlStateManager.scale(sc, 1f, sc);
            RenderUtil.alphaMul = (0.35f + 0.4f * p) * fade;
            humanoid(f, ch[c]);
            GlStateManager.popMatrix();
        }
        RenderUtil.alphaMul = 1f;
        // linhas convergindo + aneis de carga
        for (int i = 0; i < 28; i++) {
            Random rr = new Random(f.seed + i * 31L);
            double a = rr.nextDouble() * Math.PI * 2.0;
            float el = (rr.nextFloat() - 0.2f) * 1.4f;
            float rad0 = 3.2f - 2.6f * ((p * 1.6f + rr.nextFloat()) % 1f);
            float len = 0.7f;
            float y0 = f.vh * 0.5f + el * rad0 * 0.4f;
            GL11.glLineWidth(2f);
            RenderUtil.color(RenderUtil.alpha(f.color, 0.8f * p * fade));
            GL11.glBegin(GL11.GL_LINES);
            GL11.glVertex3d(Math.cos(a) * rad0, y0, Math.sin(a) * rad0);
            GL11.glVertex3d(Math.cos(a) * (rad0 + len), y0 + el * 0.3f, Math.sin(a) * (rad0 + len));
            GL11.glEnd();
        }
        GlStateManager.pushMatrix();
        GlStateManager.translate(0, 0.03f, 0);
        ringY(1.8f - 1.4f * p, 0.12f, f.color, 0.8f * fade);
        ringY(1.2f - 0.9f * ((p * 2f) % 1f), 0.06f, 0xFFFFFFFF, 0.5f * fade);
        GlStateManager.popMatrix();
        billboardGlow(0, f.vh * 0.5f, 0, 0.6f + p * 1.6f, f.color, 0.35f * p * fade);
        norm();
    }

    // ------------------------------------------------------------------ explosao (onda de choque)
    private static void burst(Fx f, float t) {
        float k = t / 0.7f;
        add();
        GlStateManager.pushMatrix();
        GlStateManager.translate(0, 0.05f, 0);
        ringY(0.3f + k * 5.5f, 0.35f * (1f - k) + 0.05f, 0xFFFFFFFF, 1f - k);
        ringY(0.2f + k * 3.5f, 0.2f * (1f - k) + 0.04f, f.color, 1f - k);
        GlStateManager.popMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.translate(0, f.vh * 0.5f, 0);
        GlStateManager.rotate(90f, 1f, 0f, 0f);
        ringY(0.3f + k * 4f, 0.2f * (1f - k) + 0.03f, f.color, (1f - k) * 0.8f);
        GlStateManager.popMatrix();
        billboardGlow(0, f.vh * 0.5f, 0, 1f + k * 3f, 0xFFFFFFFF, (1f - k) * 0.9f);
        norm();
        if (t < 0.55f) confetti(f, t, 1.2f);
    }

    private static void confetti(Fx f, float t, float life) {
        if (t > life) return;
        float fade = 1f - t / life;
        for (int i = 0; i < 46; i++) {
            Random r = new Random(f.seed * 7 + i * 13L);
            double a = r.nextDouble() * Math.PI * 2.0;
            float sp = 1.2f + r.nextFloat() * 3.2f;
            float up = 2f + r.nextFloat() * 4f;
            float px = (float) Math.cos(a) * sp * t, pz = (float) Math.sin(a) * sp * t;
            float py = f.vh * 0.5f + up * t - 4.9f * t * t;
            if (py < 0.02f) py = 0.02f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(px, py, pz);
            GlStateManager.rotate(t * 400f * (r.nextFloat() - 0.5f), r.nextFloat(), 1f, r.nextFloat());
            RenderUtil.alphaMul = fade;
            float s = 0.04f + r.nextFloat() * 0.05f;
            Vox.boxC(0, 0, 0, s * 2f, s * 0.4f, s * 1.2f, RenderUtil.hsb(r.nextFloat(), 0.8f, 1f));
            GlStateManager.popMatrix();
        }
        RenderUtil.alphaMul = 1f;
    }

    // ------------------------------------------------------------------ fase 2: memes 3D
    private static void meme(Fx f, float t) {
        float in = ease(t / 0.5f);
        float out = t > MEME - 0.45f ? Math.max(0f, (MEME - t) / 0.45f) : 1f;
        float sc = in * out;
        if (sc < 0.01f) return;
        float a = Math.min(1f, t / 0.15f) * out;
        GlStateManager.pushMatrix();
        GlStateManager.rotate(f.yaw, 0f, 1f, 0f);
        GlStateManager.scale(sc, sc, sc);
        if (f.style == 2) GlStateManager.scale(1f / Math.max(sc, 0.01f), 1f / Math.max(sc, 0.01f), 1f / Math.max(sc, 0.01f));
        RenderUtil.alphaMul = 1f;
        int labelCol = 0xFFFFFFFF;
        String label = "";
        float ly = 2.7f;
        switch (f.style) {
            case 0: tung(t); label = "TUNG TUNG TUNG SAHUR!"; labelCol = 0xFFFFD84A; break;
            case 1: tralalero(t); label = "TRALALERO TRALALA!"; labelCol = 0xFF6AD0FF; ly = 2.3f; break;
            case 2: bombardiro(t, f); label = "BOMBARDIRO CROCODILO!"; labelCol = 0xFFFF9A3A; ly = 3.6f; break;
            case 3: skibidi(t); label = "SKIBIDI DOP DOP YES YES!"; labelCol = 0xFF7DFFE0; ly = 2.4f; break;
            case 4: amongus(t); label = t < 1.4f ? "SUS" : "RED WAS THE IMPOSTOR"; labelCol = 0xFFFF5050; ly = 2.3f; break;
            default: troll(t); label = "PROBLEM?"; labelCol = 0xFFFFFFFF; ly = 2.9f; break;
        }
        GlStateManager.popMatrix();
        // texto pulsando (sem rotacao do modelo)
        float pulse = 1f + 0.25f * (float) Math.abs(Math.sin(t * 6f));
        GlStateManager.pushMatrix();
        GlStateManager.translate(0, ly * sc, 0);
        label(label, 0f, 0.045f * pulse * Math.min(1f, sc * 1.2f), RenderUtil.alpha(labelCol, Math.min(1f, a)));
        GlStateManager.popMatrix();
        // brilho de fundo
        add();
        billboardGlow(0, 1.2f * sc, 0, 2.2f * sc, f.color, 0.18f * a);
        norm();
    }

    private static final int EYE = 0xFFFFFFFF, BLK = 0xFF101010;

    private static void tung(float t) {
        float bob = (float) Math.abs(Math.sin(t * 6f)) * 0.12f;
        GlStateManager.translate(0, bob, 0);
        GlStateManager.rotate((float) Math.sin(t * 6f) * 5f, 0f, 0f, 1f);
        Vox.cyl(0, 0.35f, 0, 0.3f, 1.5f, 10, 0xFFA8693A);
        Vox.cyl(0, 0.62f, 0, 0.315f, 0.68f, 10, 0xFF7E4A22);
        Vox.cyl(0, 1.1f, 0, 0.315f, 1.16f, 10, 0xFF7E4A22);
        Vox.cyl(0, 1.5f, 0, 0.3f, 1.54f, 10, 0xFF5E3414);
        // rosto
        Vox.box(-0.2f, 1.02f, 0.27f, -0.03f, 1.28f, 0.31f, EYE);
        Vox.box(0.03f, 1.02f, 0.27f, 0.2f, 1.28f, 0.31f, EYE);
        float lx = (float) Math.sin(t * 5f) * 0.03f;
        Vox.box(-0.14f + lx, 1.08f, 0.31f, -0.08f + lx, 1.2f, 0.33f, BLK);
        Vox.box(0.08f + lx, 1.08f, 0.31f, 0.14f + lx, 1.2f, 0.33f, BLK);
        Vox.box(-0.22f, 1.3f, 0.27f, -0.02f, 1.35f, 0.31f, BLK);
        Vox.box(0.02f, 1.3f, 0.27f, 0.22f, 1.35f, 0.31f, BLK);
        float mo = 0.05f + 0.08f * (float) Math.abs(Math.sin(t * 12f));
        Vox.box(-0.12f, 0.8f, 0.27f, 0.12f, 0.8f + mo + 0.05f, 0.31f, BLK);
        Vox.box(-0.09f, 0.83f + mo, 0.31f, 0.09f, 0.85f + mo, 0.32f, EYE);
        // pernas
        float lg = (float) Math.sin(t * 10f) * 25f;
        for (int s = -1; s <= 1; s += 2) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(s * 0.14f, 0.35f, 0f);
            GlStateManager.rotate(lg * s, 1f, 0f, 0f);
            Vox.box(-0.04f, -0.35f, -0.04f, 0.04f, 0f, 0.04f, 0xFF8A5530);
            Vox.box(-0.07f, -0.37f, -0.06f, 0.07f, -0.3f, 0.1f, BLK);
            GlStateManager.popMatrix();
        }
        // braco esquerdo
        GlStateManager.pushMatrix();
        GlStateManager.translate(-0.32f, 1.1f, 0f);
        GlStateManager.rotate(20f + (float) Math.sin(t * 9f) * 25f, 0f, 0f, 1f);
        Vox.box(-0.04f, -0.45f, -0.04f, 0.04f, 0f, 0.04f, 0xFF8A5530);
        GlStateManager.popMatrix();
        // braco direito com bastao (swing)
        GlStateManager.pushMatrix();
        GlStateManager.translate(0.32f, 1.1f, 0f);
        GlStateManager.rotate(-30f + 100f * (float) Math.sin(t * 8f), 1f, 0f, 0f);
        GlStateManager.rotate(-15f, 0f, 0f, 1f);
        Vox.box(-0.04f, 0f, -0.04f, 0.04f, 0.5f, 0.04f, 0xFF8A5530);
        Vox.box(-0.035f, 0.4f, -0.035f, 0.035f, 0.95f, 0.035f, 0xFFD9B27A);
        Vox.box(-0.085f, 0.95f, -0.085f, 0.085f, 1.55f, 0.085f, 0xFFD9B27A);
        Vox.box(-0.09f, 1.5f, -0.09f, 0.09f, 1.58f, 0.09f, 0xFFB78A52);
        GlStateManager.popMatrix();
    }

    private static void tralalero(float t) {
        float run = t * 14f;
        float bob = (float) Math.abs(Math.sin(run * 0.5f)) * 0.1f;
        GlStateManager.translate(0, bob, 0);
        int blue = 0xFF3D8FE0, dark = 0xFF2A6DB8, belly = 0xFFE6F3FF;
        Vox.box(-0.3f, 0.6f, -0.7f, 0.3f, 1.2f, 0.65f, blue);
        Vox.box(-0.28f, 0.6f, -0.66f, 0.28f, 0.7f, 0.62f, belly);
        Vox.box(-0.26f, 0.68f, 0.65f, 0.26f, 1.12f, 1.05f, blue);
        Vox.box(-0.22f, 0.66f, 1.0f, 0.22f, 0.98f, 1.28f, blue);
        Vox.box(-0.2f, 0.66f, 1.0f, 0.2f, 0.74f, 1.26f, belly);
        Vox.box(-0.2f, 0.86f, 1.26f, 0.2f, 0.9f, 1.29f, BLK);
        for (int s = -1; s <= 1; s += 2) {
            Vox.box(s * 0.26f - 0.03f, 0.95f, 0.78f, s * 0.26f + 0.03f, 1.1f, 0.96f, EYE);
            Vox.box(s * 0.26f - 0.04f, 0.99f, 0.9f, s * 0.26f + 0.04f, 1.06f, 0.97f, BLK);
        }
        // barbatana e cauda
        Vox.box(-0.03f, 1.2f, -0.2f, 0.03f, 1.55f, 0.2f, dark);
        Vox.box(-0.03f, 1.55f, -0.05f, 0.03f, 1.75f, 0.14f, dark);
        float wag = (float) Math.sin(run) * 12f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(0, 0.9f, -0.7f);
        GlStateManager.rotate(wag, 0f, 1f, 0f);
        Vox.box(-0.2f, -0.2f, -0.4f, 0.2f, 0.2f, 0f, blue);
        Vox.box(-0.03f, 0.2f, -0.55f, 0.03f, 0.6f, -0.1f, dark);
        Vox.box(-0.03f, -0.45f, -0.5f, 0.03f, -0.2f, -0.1f, dark);
        GlStateManager.popMatrix();
        // 3 pernas com tenis
        float[] zs = {0.45f, 0.0f, -0.45f};
        for (int i = 0; i < 3; i++) {
            float ang = (float) Math.sin(run + i * 2.1f) * 38f;
            for (int s = -1; s <= 1; s += 2) {
                if (i == 1 && s == 1) continue;
                GlStateManager.pushMatrix();
                GlStateManager.translate(s * 0.16f, 0.6f, zs[i]);
                GlStateManager.rotate(ang * (s > 0 ? 1 : -1), 1f, 0f, 0f);
                Vox.box(-0.05f, -0.4f, -0.05f, 0.05f, 0f, 0.05f, blue);
                Vox.box(-0.09f, -0.6f, -0.1f, 0.09f, -0.38f, 0.2f, 0xFFF4F4F4);
                Vox.box(-0.095f, -0.52f, -0.04f, 0.095f, -0.46f, 0.12f, 0xFFE03030);
                GlStateManager.popMatrix();
            }
        }
    }

    private static void bombardiro(float t, Fx f) {
        // t e relativo ao tempo do meme; esta escala unitaria (ver meme()).
        float sc = ease(t / 0.5f) * (t > MEME - 0.45f ? Math.max(0f, (MEME - t) / 0.45f) : 1f);
        GlStateManager.scale(sc, sc, sc);
        float w = t * 2.2f;
        float R = 1.5f;
        float h = 2.4f + (float) Math.sin(t * 3f) * 0.12f;
        // bombas
        for (int k = 0; k < 5; k++) {
            float tr = 0.3f + k * 0.5f;
            float dt = t - tr;
            if (dt < 0f) continue;
            float wr = tr * 2.2f;
            float bx = (float) Math.cos(wr) * R, bz = (float) Math.sin(wr) * R;
            float fall = (float) Math.sqrt(2f * h / 9.8f);
            if (dt < fall) {
                float by = h - 4.9f * dt * dt;
                GlStateManager.pushMatrix();
                GlStateManager.translate(bx + (float) -Math.sin(wr) * 1.4f * dt, by, bz + (float) Math.cos(wr) * 1.4f * dt);
                GlStateManager.rotate(dt * 200f, 0f, 0f, 1f);
                Vox.boxC(0, 0, 0, 0.18f, 0.32f, 0.18f, 0xFF222226);
                Vox.boxC(0, 0.2f, 0, 0.1f, 0.1f, 0.1f, 0xFFE03020);
                GlStateManager.popMatrix();
            } else if (dt - fall < 0.5f) {
                float e = (dt - fall) / 0.5f;
                float ix = bx + (float) -Math.sin(wr) * 1.4f * fall, iz = bz + (float) Math.cos(wr) * 1.4f * fall;
                add();
                GlStateManager.pushMatrix();
                GlStateManager.translate(ix, 0.05f, iz);
                ringY(0.2f + e * 1.6f, 0.15f, 0xFFFF8A20, 1f - e);
                GlStateManager.popMatrix();
                billboardGlow(ix, 0.4f + e * 0.6f, iz, 0.5f + e * 1.2f, 0xFFFFB040, (1f - e) * 0.9f);
                billboardGlow(ix, 0.3f, iz, 0.4f, 0xFFFFFFFF, (1f - e) * 0.9f);
                norm();
            }
        }
        // crocodilo voador
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) Math.cos(w) * R, h, (float) Math.sin(w) * R);
        GlStateManager.rotate(-(float) Math.toDegrees(w) + 180f, 0f, 1f, 0f);
        GlStateManager.rotate((float) Math.sin(t * 3f) * 8f, 0f, 0f, 1f);
        int g = 0xFF4E8F2E, gd = 0xFF356B1C, gray = 0xFF8A8F99;
        Vox.box(-0.28f, -0.2f, -0.55f, 0.28f, 0.2f, 0.55f, g);
        Vox.box(-0.2f, -0.2f, -0.55f, 0.2f, -0.12f, 0.55f, 0xFFC8D88A);
        Vox.box(-0.2f, -0.12f, 0.55f, 0.2f, 0.08f, 1.25f, g);
        Vox.box(-0.19f, -0.14f, 0.55f, 0.19f, -0.08f, 1.22f, 0xFFE8EEC8);
        for (int i = 0; i < 4; i++) {
            Vox.box(-0.2f, -0.2f, 0.62f + i * 0.15f, -0.17f, -0.12f, 0.68f + i * 0.15f, EYE);
            Vox.box(0.17f, -0.2f, 0.62f + i * 0.15f, 0.2f, -0.12f, 0.68f + i * 0.15f, EYE);
        }
        Vox.box(-0.22f, 0.2f, 0.4f, -0.1f, 0.3f, 0.55f, 0xFFFFE04A);
        Vox.box(0.1f, 0.2f, 0.4f, 0.22f, 0.3f, 0.55f, 0xFFFFE04A);
        Vox.box(-0.2f, 0.0f, -1.1f, 0.2f, 0.18f, -0.55f, gd);
        Vox.box(-0.04f, 0.18f, -1.1f, 0.04f, 0.5f, -0.8f, gd);
        float fl = (float) Math.sin(t * 14f) * 18f;
        for (int s = -1; s <= 1; s += 2) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(s * 0.28f, 0.1f, 0.05f);
            GlStateManager.rotate(s * fl, 0f, 0f, 1f);
            Vox.box(s > 0 ? 0f : -1.3f, -0.03f, -0.3f, s > 0 ? 1.3f : 0f, 0.03f, 0.3f, gray);
            Vox.box(s > 0 ? 0.9f : -1.3f, -0.03f, -0.5f, s > 0 ? 1.3f : -0.9f, 0.03f, -0.3f, 0xFF5A5F69);
            GlStateManager.popMatrix();
        }
        Vox.boxC(0, -0.34f, 0.0f, 0.16f, 0.28f, 0.16f, 0xFF222226);
        GlStateManager.popMatrix();
    }

    private static void skibidi(float t) {
        float yaw = (float) Math.sin(t * 2.5f) * 25f;
        GlStateManager.rotate(yaw, 0f, 1f, 0f);
        Vox.box(-0.32f, 0f, -0.38f, 0.32f, 0.45f, 0.38f, 0xFFF4F4F4);
        Vox.box(-0.36f, 0.45f, -0.42f, 0.36f, 0.52f, 0.42f, 0xFFE8E8EC);
        Vox.box(-0.28f, 0.5f, -0.6f, 0.28f, 1.1f, -0.38f, 0xFFF4F4F4);
        Vox.box(0.2f, 0.9f, -0.66f, 0.3f, 0.98f, -0.6f, 0xFFB8C0C8);
        Vox.box(-0.3f, 0.1f, -0.28f, 0.3f, 0.4f, 0.4f, 0xFF3A8FD8);
        // cabeca saindo do vaso
        float bob = (float) Math.abs(Math.sin(t * 10f)) * 0.1f;
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) Math.sin(t * 5f) * 0.12f, 0.5f + bob, 0.05f);
        GlStateManager.rotate((float) Math.sin(t * 5f) * 22f, 0f, 0f, 1f);
        Vox.box(-0.27f, 0f, -0.26f, 0.27f, 0.54f, 0.26f, 0xFFE8C39A);
        Vox.box(-0.27f, 0.5f, -0.26f, 0.27f, 0.58f, 0.26f, 0xFF3A2A1A);
        Vox.box(-0.19f, 0.28f, 0.26f, -0.07f, 0.4f, 0.29f, EYE);
        Vox.box(0.07f, 0.28f, 0.26f, 0.19f, 0.4f, 0.29f, EYE);
        Vox.box(-0.15f, 0.31f, 0.29f, -0.1f, 0.37f, 0.3f, BLK);
        Vox.box(0.1f, 0.31f, 0.29f, 0.15f, 0.37f, 0.3f, BLK);
        Vox.box(-0.22f, 0.42f, 0.26f, -0.05f, 0.46f, 0.29f, BLK);
        Vox.box(0.05f, 0.42f, 0.26f, 0.22f, 0.46f, 0.29f, BLK);
        float mo = 0.04f + 0.1f * (float) Math.abs(Math.sin(t * 10f));
        Vox.box(-0.13f, 0.08f, 0.26f, 0.13f, 0.08f + mo, 0.29f, 0xFF4A0A0A);
        GlStateManager.popMatrix();
    }

    private static void amongus(float t) {
        float x = 0f, y = 0f, rot = 0f;
        if (t < 1.4f) {
            rot = (float) Math.sin(t * 9f) * 8f;
            y = (float) Math.abs(Math.sin(t * 9f)) * 0.08f;
        } else {
            float e = t - 1.4f;
            x = e * 1.6f;
            y = e * 1.2f + 0.2f;
            rot = e * 380f;
        }
        GlStateManager.translate(x, y, 0f);
        GlStateManager.translate(0, 0.7f, 0);
        GlStateManager.rotate(rot, 0f, 0f, 1f);
        GlStateManager.translate(0, -0.7f, 0);
        int red = 0xFFD42A2A, dk = 0xFF9E1B1B;
        Vox.box(-0.3f, 0.3f, -0.2f, 0.3f, 1.1f, 0.2f, red);
        Vox.box(-0.25f, 1.1f, -0.17f, 0.25f, 1.2f, 0.17f, red);
        Vox.box(-0.3f, 0f, -0.18f, -0.04f, 0.32f, 0.18f, red);
        Vox.box(0.04f, 0f, -0.18f, 0.3f, 0.32f, 0.18f, red);
        Vox.box(-0.22f, 0.4f, -0.32f, 0.22f, 0.9f, -0.2f, dk);
        Vox.box(-0.05f, 0.74f, 0.2f, 0.34f, 1.02f, 0.25f, 0xFF9AD8F0);
        Vox.box(0.12f, 0.9f, 0.25f, 0.28f, 0.98f, 0.27f, 0xFFE8F8FF);
    }

    private static void troll(float t) {
        float z = 1f + 0.12f * (float) Math.sin(t * 4f);
        GlStateManager.translate(0, 1.2f, 0);
        GlStateManager.rotate(t * 90f, 0f, 1f, 0f);
        GlStateManager.scale(z, z, z);
        Vox.boxC(0, 0, 0, 1.2f, 1.05f, 0.5f, 0xFFF4F4F4);
        Vox.boxC(0, -0.1f, 0, 1.1f, 0.2f, 0.52f, 0xFFE6E6E6);
        for (int ss = -1; ss <= 1; ss += 2) {
            Vox.boxC(ss * 0.25f, 0.15f, 0.26f, 0.3f, 0.2f, 0.03f, EYE);
            Vox.boxC(ss * 0.25f, 0.13f, 0.28f, 0.1f, 0.1f, 0.03f, BLK);
            GlStateManager.pushMatrix();
            GlStateManager.translate(ss * 0.28f, 0.34f, 0.27f);
            GlStateManager.rotate(-ss * 18f, 0f, 0f, 1f);
            Vox.boxC(0, 0, 0, 0.36f, 0.06f, 0.03f, BLK);
            GlStateManager.popMatrix();
        }
        for (int i = -4; i <= 4; i++) {
            float yy = -0.2f - 0.14f * (1f - (i * i) / 16f) * -1f;
            Vox.boxC(i * 0.11f, -0.2f + (i * i) * 0.012f - 0.1f, 0.27f, 0.12f, 0.05f, 0.03f, BLK);
        }
        Vox.boxC(0, -0.27f, 0.27f, 0.7f, 0.08f, 0.03f, EYE);
        Vox.boxC(-0.4f, -0.12f, 0.27f, 0.05f, 0.1f, 0.03f, BLK);
        Vox.boxC(0.4f, -0.12f, 0.27f, 0.05f, 0.1f, 0.03f, BLK);
    }
}
