package com.larpclient.cosmetics;

import com.larpclient.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Animacoes de morte desenhadas por codigo (sem texturas). */
public final class DeathEffects {
    private DeathEffects() {}

    private static final class Fx {
        double x, y, z;
        int style, color;
        float scale, yaw;
        long t0;
        long seed;
    }

    private static final List<Fx> LIST = new ArrayList<Fx>();
    private static final Random RND = new Random();
    private static final float DUR = 2.0f;

    public static void spawn(double x, double y, double z, int style, int color, float scale) {
        Fx f = new Fx();
        f.x = x;
        f.y = y;
        f.z = z;
        f.style = style == 5 ? RND.nextInt(5) : style;
        f.color = color;
        f.scale = scale;
        f.yaw = RND.nextFloat() * 360f;
        f.t0 = System.currentTimeMillis();
        f.seed = RND.nextLong();
        LIST.add(f);
    }

    public static void render(float pt) {
        if (LIST.isEmpty()) return;
        long now = System.currentTimeMillis();
        double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
        for (int i = LIST.size() - 1; i >= 0; i--) {
            Fx f = LIST.get(i);
            float age = (now - f.t0) / 1000f;
            if (age > DUR) {
                LIST.remove(i);
                continue;
            }
            GlStateManager.pushMatrix();
            GlStateManager.translate(f.x - cx, f.y - cy, f.z - cz);
            GlStateManager.scale(f.scale, f.scale, f.scale);
            switch (f.style) {
                case 0: beast(f, age); break;
                case 1: lightning(f, age); break;
                case 2: souls(f, age); break;
                case 3: shock(f, age); break;
                default: sahur(f, age); break;
            }
            GlStateManager.popMatrix();
        }
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    // ---------------------------------------------------------------- helpers
    private static void ringFlat(float r, float w, float y, int col, float a) {
        RenderUtil.begin();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.blendFunc(770, 1);
        GL11.glBegin(GL11.GL_QUAD_STRIP);
        for (int i = 0; i <= 48; i++) {
            double ang = Math.PI * 2.0 * i / 48.0;
            float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
            RenderUtil.color(RenderUtil.alpha(col, a));
            GL11.glVertex3f(cs * r, y, sn * r);
            RenderUtil.color(RenderUtil.alpha(col, 0f));
            GL11.glVertex3f(cs * (r + w), y, sn * (r + w));
        }
        GL11.glEnd();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        RenderUtil.end();
    }

    private static void glowOrb(float x, float y, float z, float r, int col, float a) {
        RenderUtil.begin();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.blendFunc(770, 1);
        for (int p = 0; p < 3; p++) {
            GL11.glBegin(GL11.GL_TRIANGLE_FAN);
            RenderUtil.color(RenderUtil.alpha(RenderUtil.mix(col, 0xFFFFFFFF, 0.6f), a));
            GL11.glVertex3f(x, y, z);
            RenderUtil.color(RenderUtil.alpha(col, 0f));
            for (int i = 0; i <= 16; i++) {
                double ang = Math.PI * 2.0 * i / 16.0;
                float c = (float) Math.cos(ang) * r, s = (float) Math.sin(ang) * r;
                if (p == 0) GL11.glVertex3f(x + c, y + s, z);
                else if (p == 1) GL11.glVertex3f(x + c, y, z + s);
                else GL11.glVertex3f(x, y + c, z + s);
            }
            GL11.glEnd();
        }
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        RenderUtil.end();
    }

    /** Caixa solida centrada em (cx,cy,cz). */
    private static void box(float cx, float cy, float cz, float sx, float sy, float sz, int col) {
        float x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2;
        GL11.glBegin(GL11.GL_QUADS);
        RenderUtil.color(RenderUtil.shade(col, 1.0f));
        GL11.glVertex3f(x0, y1, z0); GL11.glVertex3f(x1, y1, z0); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x0, y1, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.5f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x0, y0, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.8f));
        GL11.glVertex3f(x0, y0, z1); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x0, y1, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.65f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y1, z0); GL11.glVertex3f(x0, y1, z0);
        RenderUtil.color(RenderUtil.shade(col, 0.9f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x0, y0, z1); GL11.glVertex3f(x0, y1, z1); GL11.glVertex3f(x0, y1, z0);
        RenderUtil.color(RenderUtil.shade(col, 0.7f));
        GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x1, y1, z0);
        GL11.glEnd();
    }

    private static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    // ---------------------------------------------------------------- 0: FERA
    private static void beast(Fx f, float age) {
        float runT = ease(age / 0.7f);
        float dist = 9f * (1f - runT);
        float fade = age < 1.5f ? 1f : Math.max(0f, 1f - (age - 1.5f) / 0.5f);
        float a = fade;
        GlStateManager.pushMatrix();
        GlStateManager.rotate(f.yaw, 0f, 1f, 0f);
        GlStateManager.translate(0f, 0f, dist);
        float leap = age > 0.55f && age < 0.9f ? (float) Math.sin((age - 0.55f) / 0.35f * Math.PI) * 1.0f : 0f;
        float run = age < 0.7f ? (float) Math.sin(age * 28f) : 0f;
        RenderUtil.begin();
        GlStateManager.disableCull();
        RenderUtil.alphaMul = a;
        int body = 0xFF120818, trim = f.color;
        GlStateManager.translate(0f, leap, 0f);
        GlStateManager.rotate(180f, 0f, 1f, 0f);
        box(0f, 1.0f, 0f, 0.9f, 1.1f, 0.5f, body);
        box(0f, 1.85f, 0.05f, 0.7f, 0.7f, 0.7f, body);
        box(-0.18f, 1.9f, 0.42f, 0.14f, 0.1f, 0.05f, 0xFFFF2020);
        box(0.18f, 1.9f, 0.42f, 0.14f, 0.1f, 0.05f, 0xFFFF2020);
        box(-0.28f, 2.35f, 0f, 0.1f, 0.35f, 0.1f, trim);
        box(0.28f, 2.35f, 0f, 0.1f, 0.35f, 0.1f, trim);
        GlStateManager.pushMatrix();
        GlStateManager.translate(-0.6f, 1.4f, 0f);
        GlStateManager.rotate(-60f + run * 40f - (age > 0.55f ? 40f : 0f), 1f, 0f, 0f);
        box(0f, -0.5f, 0f, 0.25f, 1.0f, 0.25f, body);
        box(0f, -1.05f, 0f, 0.3f, 0.12f, 0.3f, 0xFFE8E8E8);
        GlStateManager.popMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.translate(0.6f, 1.4f, 0f);
        GlStateManager.rotate(-60f - run * 40f - (age > 0.55f ? 40f : 0f), 1f, 0f, 0f);
        box(0f, -0.5f, 0f, 0.25f, 1.0f, 0.25f, body);
        box(0f, -1.05f, 0f, 0.3f, 0.12f, 0.3f, 0xFFE8E8E8);
        GlStateManager.popMatrix();
        for (int s = -1; s <= 1; s += 2) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(s * 0.22f, 0.5f, 0f);
            GlStateManager.rotate(s * run * 35f, 1f, 0f, 0f);
            box(0f, -0.5f, 0f, 0.3f, 1.0f, 0.3f, body);
            GlStateManager.popMatrix();
        }
        // asas de morcego
        for (int s = -1; s <= 1; s += 2) {
            float flap = (float) Math.sin(age * 14f) * 18f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(s * 0.45f, 1.5f, -0.28f);
            GlStateManager.rotate(s * (35f + flap), 0f, 0f, 1f);
            GL11.glBegin(GL11.GL_TRIANGLE_FAN);
            RenderUtil.color(RenderUtil.alpha(trim, 0.85f));
            GL11.glVertex3f(0f, 0f, 0f);
            GL11.glVertex3f(s * 1.9f, 0.9f, 0f);
            GL11.glVertex3f(s * 1.6f, 0.0f, 0f);
            GL11.glVertex3f(s * 1.2f, -0.4f, 0f);
            GL11.glVertex3f(s * 0.5f, -0.8f, 0f);
            GL11.glEnd();
            GlStateManager.popMatrix();
        }
        GlStateManager.popMatrix();
        RenderUtil.alphaMul = 1f;
        RenderUtil.end();

        // garras: tres cortes + brilho no impacto
        if (age > 0.6f && age < 1.4f) {
            float p = (age - 0.6f) / 0.8f;
            float sa = 1f - p;
            RenderUtil.begin();
            GlStateManager.disableCull();
            GlStateManager.depthMask(false);
            GlStateManager.blendFunc(770, 1);
            GlStateManager.pushMatrix();
            GlStateManager.rotate(f.yaw, 0f, 1f, 0f);
            for (int k = 0; k < 3; k++) {
                float o = (k - 1) * 0.35f;
                float prog = Math.min(1f, p * 3f - k * 0.2f);
                if (prog <= 0f) continue;
                GL11.glLineWidth(5f);
                GL11.glBegin(GL11.GL_LINE_STRIP);
                for (int i = 0; i <= 12; i++) {
                    float u = i / 12f * prog;
                    RenderUtil.color(RenderUtil.alpha(RenderUtil.mix(f.color, 0xFFFFFFFF, 0.6f), sa * (1f - u * 0.4f)));
                    GL11.glVertex3f(o + u * 0.3f, 2.2f - u * 1.9f, 0.5f - u * 0.3f);
                }
                GL11.glEnd();
            }
            GlStateManager.popMatrix();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.depthMask(true);
            GlStateManager.enableCull();
            RenderUtil.end();
            glowOrb(0f, 1.0f, 0f, 1.6f * (0.4f + p), f.color, sa * 0.9f);
            ringFlat(0.3f + p * 3.5f, 0.6f, 0.05f, f.color, sa * 0.8f);
        }
    }

    // ------------------------------------------------------------ 1: RAIO
    private static void lightning(Fx f, float age) {
        if (age > 1.2f) return;
        Random r = new Random(f.seed + (long) (age * 14f));
        float a = Math.max(0f, 1f - age / 1.2f);
        RenderUtil.begin();
        GlStateManager.depthMask(false);
        GlStateManager.blendFunc(770, 1);
        for (int pass = 0; pass < 2; pass++) {
            r = new Random(f.seed + (long) (age * 14f));
            GL11.glLineWidth(pass == 0 ? 9f : 3f);
            for (int b = 0; b < 3; b++) {
                float x = 0f, z = 0f;
                GL11.glBegin(GL11.GL_LINE_STRIP);
                for (int i = 0; i <= 14; i++) {
                    float y = 28f - i * 2f;
                    RenderUtil.color(pass == 0 ? RenderUtil.alpha(f.color, a * 0.35f) : RenderUtil.alpha(0xFFFFFFFF, a));
                    GL11.glVertex3f(x, y, z);
                    x += (r.nextFloat() - 0.5f) * (b == 0 ? 1.4f : 2.2f);
                    z += (r.nextFloat() - 0.5f) * (b == 0 ? 1.4f : 2.2f);
                    x *= 0.8f;
                    z *= 0.8f;
                    if (i == 13) {
                        x = 0f;
                        z = 0f;
                    }
                }
                GL11.glEnd();
            }
        }
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        RenderUtil.end();
        glowOrb(0f, 0.6f, 0f, 2.2f * (0.5f + age), f.color, a);
        ringFlat(age * 5f, 0.8f, 0.05f, f.color, a);
    }

    // ------------------------------------------------------------ 2: ALMAS
    private static void souls(Fx f, float age) {
        Random r = new Random(f.seed);
        for (int i = 0; i < 14; i++) {
            float ph = r.nextFloat() * 6.28f, sp = 0.6f + r.nextFloat() * 0.8f, rad = 0.3f + r.nextFloat() * 0.7f;
            float t = age * sp;
            if (t > 1.8f) continue;
            float y = 0.3f + t * 2.4f;
            float ang = ph + t * 4f;
            float a = 1f - t / 1.8f;
            glowOrb((float) Math.cos(ang) * rad * (1f + t * 0.4f), y, (float) Math.sin(ang) * rad * (1f + t * 0.4f), 0.28f, f.color, a);
        }
        ringFlat(0.2f + age * 1.4f, 0.5f, 0.05f, f.color, Math.max(0f, 0.8f - age * 0.4f));
    }

    // ------------------------------------------------------- 3: ONDA DE CHOQUE
    private static void shock(Fx f, float age) {
        for (int k = 0; k < 3; k++) {
            float t = age - k * 0.15f;
            if (t <= 0f || t > 1.4f) continue;
            ringFlat(t * 6f, 0.9f, 0.05f + k * 0.02f, k == 0 ? f.color : RenderUtil.mix(f.color, 0xFFFFFFFF, 0.5f), 1f - t / 1.4f);
        }
        RenderUtil.begin();
        GlStateManager.depthMask(false);
        GlStateManager.blendFunc(770, 1);
        GL11.glLineWidth(3f);
        Random r = new Random(f.seed);
        GL11.glBegin(GL11.GL_LINES);
        for (int i = 0; i < 28; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double e = r.nextDouble() * 1.2;
            float d0 = age * 4f, d1 = d0 + 0.6f;
            float al = Math.max(0f, 1f - age / 1.2f);
            RenderUtil.color(RenderUtil.alpha(0xFFFFFFFF, al));
            GL11.glVertex3d(Math.cos(a) * d0, 0.2 + e * age * 2, Math.sin(a) * d0);
            RenderUtil.color(RenderUtil.alpha(f.color, 0f));
            GL11.glVertex3d(Math.cos(a) * d1, 0.2 + e * age * 2 + 0.3, Math.sin(a) * d1);
        }
        GL11.glEnd();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        RenderUtil.end();
        glowOrb(0f, 0.8f, 0f, 2.4f * Math.max(0f, 1f - age), f.color, 1f - age / 1.2f);
    }

    // --------------------------------------------------------- 4: TUNG SAHUR (meme)
    private static void sahur(Fx f, float age) {
        float runT = ease(age / 0.6f);
        float dist = 7f * (1f - runT);
        float fade = age < 1.6f ? 1f : Math.max(0f, 1f - (age - 1.6f) / 0.4f);
        RenderUtil.begin();
        RenderUtil.alphaMul = fade;
        GlStateManager.disableCull();
        GlStateManager.pushMatrix();
        GlStateManager.rotate(f.yaw, 0f, 1f, 0f);
        GlStateManager.translate(0f, 0f, dist);
        GlStateManager.rotate(180f, 0f, 1f, 0f);
        float step = age < 0.6f ? (float) Math.sin(age * 30f) : 0f;
        int wood = 0xFF8A5A2B, dark = 0xFF4A2A10;
        box(0f, 1.0f, 0f, 0.7f, 1.4f, 0.7f, wood);          // tronco
        box(0f, 1.0f, 0.36f, 0.5f, 1.0f, 0.02f, dark);
        box(-0.15f, 1.4f, 0.37f, 0.12f, 0.12f, 0.03f, 0xFFFFFFFF);   // olhos
        box(0.15f, 1.4f, 0.37f, 0.12f, 0.12f, 0.03f, 0xFFFFFFFF);
        box(0f, 1.15f, 0.37f, 0.3f, 0.06f, 0.03f, 0xFF200808);       // boca
        for (int s = -1; s <= 1; s += 2) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(s * 0.2f, 0.3f, 0f);
            GlStateManager.rotate(s * step * 40f, 1f, 0f, 0f);
            box(0f, -0.25f, 0f, 0.2f, 0.6f, 0.2f, dark);
            GlStateManager.popMatrix();
        }
        // braco com bastao: balanca a partir de 0.6s
        float swing = age > 0.6f ? (float) Math.sin(Math.min(1f, (age - 0.6f) / 0.25f) * Math.PI) : 0f;
        float rep = age > 0.85f ? (float) Math.sin((age - 0.85f) * 22f) * 0.5f + 0.5f : 0f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(0.5f, 1.5f, 0f);
        GlStateManager.rotate(-30f - swing * 110f - rep * 70f, 1f, 0f, 0f);
        box(0f, -0.4f, 0f, 0.2f, 0.8f, 0.2f, dark);
        box(0f, -1.2f, 0f, 0.22f, 1.0f, 0.22f, 0xFFD2A060);
        GlStateManager.popMatrix();
        GlStateManager.popMatrix();
        RenderUtil.alphaMul = 1f;
        RenderUtil.end();
        if (age > 0.6f && age < 1.7f) {
            float p = (age - 0.6f) / 1.1f;
            float pop = 0.07f + 0.04f * (float) Math.sin(age * 30f);
            RenderUtil.worldText(((int) (age * 10f)) % 2 == 0 ? "TUNG!" : "TUNG TUNG!", 0.0, 2.6 + p * 0.6, 0.0, pop, RenderUtil.alpha(0xFFFFE070, 1f - p));
            glowOrb(0f, 0.9f, 0f, 1.2f * (1f - p), 0xFFFFA030, 0.8f * (1f - p));
            ringFlat(0.3f + p * 3f, 0.5f, 0.05f, 0xFFFFA030, 0.8f * (1f - p));
        }
    }
}
