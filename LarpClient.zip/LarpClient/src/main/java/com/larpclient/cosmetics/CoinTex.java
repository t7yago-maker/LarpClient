package com.larpclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.image.BufferedImage;

/** Moedas (Bitcoin, Monero, Litecoin, Ethereum, Dolar, Euro) desenhadas por codigo (sem fontes). */
public final class CoinTex {
    private CoinTex() {}

    public static final int COUNT = 6;
    private static final ResourceLocation[] locs = new ResourceLocation[COUNT];
    private static final int[] BG = {0xFFF7931A, 0xFFFF6600, 0xFF345D9D, 0xFF627EEA, 0xFF2E9A4A, 0xFF1E6FD9};

    public static ResourceLocation get(int i) {
        i = ((i % COUNT) + COUNT) % COUNT;
        if (locs[i] == null) locs[i] = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("larpcoin" + i, new DynamicTexture(build(i)));
        return locs[i];
    }

    private static void line(BufferedImage im, float x0, float y0, float x1, float y1, float w) {
        float minx = Math.min(x0, x1) - w, maxx = Math.max(x0, x1) + w, miny = Math.min(y0, y1) - w, maxy = Math.max(y0, y1) + w;
        float dx = x1 - x0, dy = y1 - y0, l2 = dx * dx + dy * dy;
        for (int y = Math.max(0, (int) miny); y <= Math.min(63, (int) maxy); y++) {
            for (int x = Math.max(0, (int) minx); x <= Math.min(63, (int) maxx); x++) {
                float t = l2 == 0 ? 0 : Math.max(0f, Math.min(1f, ((x - x0) * dx + (y - y0) * dy) / l2));
                float px = x0 + t * dx - x, py = y0 + t * dy - y;
                if (px * px + py * py <= w * w / 4f) im.setRGB(x, y, 0xFFFFFFFF);
            }
        }
    }

    private static BufferedImage build(int i) {
        BufferedImage im = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        int bg = BG[i];
        int dark = ((bg >> 17) & 0x7F) << 16 | ((bg >> 9) & 0x7F) << 8 | ((bg >> 1) & 0x7F) | 0xFF000000;
        for (int y = 0; y < 64; y++) {
            for (int x = 0; x < 64; x++) {
                float d = (float) Math.sqrt((x - 31.5f) * (x - 31.5f) + (y - 31.5f) * (y - 31.5f));
                if (d <= 31f) im.setRGB(x, y, d > 27f ? dark : bg);
            }
        }
        float w = 5.5f;
        switch (i) {
            case 0: // Bitcoin B
                line(im, 24, 14, 24, 50, w); line(im, 24, 14, 38, 14, w); line(im, 38, 14, 44, 20, w); line(im, 44, 20, 38, 31, w);
                line(im, 24, 31, 38, 31, w); line(im, 38, 31, 46, 38, w); line(im, 46, 38, 38, 50, w); line(im, 24, 50, 38, 50, w);
                line(im, 30, 8, 30, 14, 4f); line(im, 36, 8, 36, 14, 4f); line(im, 30, 50, 30, 56, 4f); line(im, 36, 50, 36, 56, 4f);
                break;
            case 1: // Monero M
                line(im, 16, 50, 16, 16, w); line(im, 16, 16, 32, 36, w); line(im, 32, 36, 48, 16, w); line(im, 48, 16, 48, 50, w);
                break;
            case 2: // Litecoin L
                line(im, 24, 14, 24, 50, w); line(im, 24, 50, 46, 50, w); line(im, 14, 38, 34, 28, w);
                break;
            case 3: // Ethereum diamante
                line(im, 32, 10, 46, 32, w); line(im, 46, 32, 32, 54, w); line(im, 32, 54, 18, 32, w); line(im, 18, 32, 32, 10, w);
                line(im, 18, 32, 46, 32, w);
                break;
            case 4: // Dolar
                line(im, 42, 21, 29, 18, w); line(im, 29, 18, 21, 26, w); line(im, 21, 26, 31, 32, w); line(im, 31, 32, 42, 38, w);
                line(im, 42, 38, 36, 46, w); line(im, 36, 46, 20, 44, w); line(im, 32, 9, 32, 55, 4f);
                break;
            default: // Euro
                for (int a = 40; a < 320; a += 12) {
                    double r0 = Math.toRadians(a), r1 = Math.toRadians(a + 12);
                    line(im, 36 + 17 * (float) Math.cos(r0), 32 + 17 * (float) Math.sin(r0), 36 + 17 * (float) Math.cos(r1), 32 + 17 * (float) Math.sin(r1), w);
                }
                line(im, 14, 27, 38, 27, 4.5f); line(im, 14, 37, 38, 37, 4.5f);
                break;
        }
        return im;
    }
}
