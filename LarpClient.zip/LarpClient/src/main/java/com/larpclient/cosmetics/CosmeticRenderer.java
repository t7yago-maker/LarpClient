package com.larpclient.cosmetics;

import com.larpclient.core.ModuleManager;
import com.larpclient.modules.CosmeticModules;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderPlayerEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Asas, chifres, capa e aura. Tudo desenhado so no seu cliente. */
public final class CosmeticRenderer {
    private CosmeticRenderer() {}

    /** Contexto de pose usado tanto no jogo quanto na previa. */
    public static final class Ctx {
        public float time, headYaw, headPitch, capeA, capeB;
        public boolean sneak, air, hasLeg;
        public float legX, legY, legZ, legAng;
    }

    private static ModelPlayer capeModel;

    // =========================================================================
    //  Jogo: evento de render do jogador
    // =========================================================================
    private static boolean hidHead, hidLeg, pushed;

    /** Antes de desenhar o jogador: headless, korblox e corpo magro (so em voce). */
    public static void onRenderPre(RenderPlayerEvent.Pre e) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer p = e.entityPlayer;
        if (p != mc.thePlayer) return;
        CosmeticModules.Avatar av = ModuleManager.get(CosmeticModules.Avatar.class);
        if (av == null || !av.enabled) return;
        ModelPlayer m = e.renderer.getMainModel();
        if (av.headless.b()) {
            m.bipedHead.showModel = false;
            m.bipedHeadwear.showModel = false;
            hidHead = true;
        }
        if (av.korblox.b()) {
            m.bipedRightLeg.showModel = false;
            m.bipedRightLegwear.showModel = false;
            hidLeg = true;
        }
        if (av.skinny.b()) {
            float pt = e.partialRenderTick;
            float yawOff = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
            float thin = av.thin.f();
            float thinZ = 0.5f + thin * 0.5f;
            GlStateManager.pushMatrix();
            GlStateManager.translate((float) e.x, (float) e.y, (float) e.z);
            GlStateManager.rotate(180f - yawOff, 0f, 1f, 0f);
            GlStateManager.scale(thin, 1f, thinZ);
            GlStateManager.rotate(-(180f - yawOff), 0f, 1f, 0f);
            GlStateManager.translate((float) -e.x, (float) -e.y, (float) -e.z);
            pushed = true;
        }
    }

    public static void onRenderPlayer(RenderPlayerEvent.Post e) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer p = e.entityPlayer;
        ModelPlayer pm = e.renderer.getMainModel();
        if (hidHead) {
            pm.bipedHead.showModel = true;
            pm.bipedHeadwear.showModel = true;
            hidHead = false;
        }
        boolean legWas = hidLeg;
        if (hidLeg) {
            pm.bipedRightLeg.showModel = true;
            pm.bipedRightLegwear.showModel = true;
            hidLeg = false;
        }
        if (pushed) {
            GlStateManager.popMatrix();
            pushed = false;
        }
        if (p != mc.thePlayer || p.isInvisible()) return;
        float pt = e.partialRenderTick;

        double x = p.lastTickPosX + (p.posX - p.lastTickPosX) * pt - RenderUtil.camX(pt);
        double y = p.lastTickPosY + (p.posY - p.lastTickPosY) * pt - RenderUtil.camY(pt);
        double z = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * pt - RenderUtil.camZ(pt);
        float yawOff = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
        float headY = p.prevRotationYawHead + (p.rotationYawHead - p.prevRotationYawHead) * pt;
        float pitch = p.prevRotationPitch + (p.rotationPitch - p.prevRotationPitch) * pt;

        Ctx c = new Ctx();
        c.time = p.ticksExisted + pt;
        c.headYaw = headY - yawOff;
        c.headPitch = pitch;
        c.sneak = p.isSneaking();
        c.air = !p.onGround;
        if (legWas) {
            c.hasLeg = true;
            c.legX = pm.bipedRightLeg.rotationPointX;
            c.legY = pm.bipedRightLeg.rotationPointY;
            c.legZ = pm.bipedRightLeg.rotationPointZ;
            c.legAng = pm.bipedRightLeg.rotateAngleX;
        }

        // fisica da capa (igual a capa original do jogo)
        double d0 = (p.prevChasingPosX + (p.chasingPosX - p.prevChasingPosX) * pt) - (p.prevPosX + (p.posX - p.prevPosX) * pt);
        double d1 = (p.prevChasingPosY + (p.chasingPosY - p.prevChasingPosY) * pt) - (p.prevPosY + (p.posY - p.prevPosY) * pt);
        double d2 = (p.prevChasingPosZ + (p.chasingPosZ - p.prevChasingPosZ) * pt) - (p.prevPosZ + (p.posZ - p.prevPosZ) * pt);
        double d3 = Math.sin(yawOff * Math.PI / 180.0);
        double d4 = -Math.cos(yawOff * Math.PI / 180.0);
        float f1 = (float) d1 * 10f;
        f1 = Math.max(-6f, Math.min(32f, f1));
        float f2 = (float) (d0 * d3 + d2 * d4) * 100f;
        float f3 = (float) (d0 * d4 - d2 * d3) * 100f;
        if (f2 < 0f) f2 = 0f;
        float f4 = p.prevCameraYaw + (p.cameraYaw - p.prevCameraYaw) * pt;
        f1 += (float) Math.sin((p.prevDistanceWalkedModified + (p.distanceWalkedModified - p.prevDistanceWalkedModified) * pt) * 6f) * 32f * f4;
        if (c.sneak) f1 += 25f;
        c.capeA = 6f + f2 / 2f + f1;
        c.capeB = f3 / 2f;

        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, (float) z);
        if (c.sneak) GlStateManager.translate(0f, -0.125f, 0f);
        renderAura(c.time, false);
        GlStateManager.rotate(180f - yawOff, 0f, 1f, 0f);
        GlStateManager.scale(-1f, -1f, 1f);
        GlStateManager.scale(0.9375f, 0.9375f, 0.9375f);
        GlStateManager.translate(0f, -1.5078125f, 0f);
        renderModel(c);
        GlStateManager.popMatrix();
        GlStateManager.enableLighting();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    // =========================================================================
    //  Espaco do modelo (y para baixo, origem no pescoco, unidades = blocos)
    // =========================================================================
    public static void renderModel(Ctx c) {
        cape(c);
        wings(c);
        horns(c);
        korblox(c);
    }

    private static void cape(Ctx c) {
        CosmeticModules.Cape cm = ModuleManager.get(CosmeticModules.Cape.class);
        if (cm == null || !cm.enabled) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (capeModel == null) capeModel = new ModelPlayer(0f, false);
        mc.getTextureManager().bindTexture(cm.current(c.time));
        GlStateManager.pushMatrix();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.translate(0f, 0f, 0.125f);
        if (c.sneak) GlStateManager.translate(0f, 0.142f, -0.0178f);
        GlStateManager.rotate(c.capeA, 1f, 0f, 0f);
        GlStateManager.rotate(c.capeB, 0f, 0f, 1f);
        GlStateManager.rotate(-c.capeB, 0f, 1f, 0f);
        GlStateManager.rotate(180f, 0f, 1f, 0f);
        capeModel.renderCape(0.0625f);
        GlStateManager.popMatrix();
    }

    // =========================================================================
    //  ASAS
    // =========================================================================
    private static void wings(Ctx c) {
        CosmeticModules.Wings w = ModuleManager.get(CosmeticModules.Wings.class);
        if (w == null || !w.enabled) return;
        int si = w.style.index;
        WingModel m = WingModel.get(si);
        float size = w.size.f() * WingModel.SCALE[si];
        int col = w.resolveColor();
        float t = c.time / 20f;
        float flap = (float) Math.sin(t * Math.PI * w.speed.f() * (c.air ? 3f : 1f));
        float amp = c.air ? 30f : 12f;
        GlStateManager.pushMatrix();
        if (c.sneak) {
            GlStateManager.translate(0f, 0.75f, 0f);
            GlStateManager.rotate(28.6f, 1f, 0f, 0f);
            GlStateManager.translate(0f, -0.75f, 0f);
        }
        for (int side = 0; side < 2; side++) {
            float sx = side == 0 ? 1f : -1f;
            GlStateManager.pushMatrix();
            GlStateManager.translate(sx * 0.09f, 0.12f, 0.14f);
            GlStateManager.scale(sx * size, -size, size);
            GlStateManager.rotate(-(24f + flap * amp), 0f, 1f, 0f);
            m.draw(col, w.glow.b(), WingModel.FIRE[si]);
            GlStateManager.popMatrix();
        }
        GlStateManager.popMatrix();
    }

    private static final class WingModel {
        private static final WingModel[] CACHE = new WingModel[16];
        static final float[] SCALE = {1f, 1f, 1f, 1f, 0.6f, 1.45f, 1.3f, 1.2f, 0.6f, 1.4f, 1f, 1f, 1.1f, 1f, 1.1f, 1f};
        static final boolean[] FIRE = {false, false, true, false, false, false, false, true, false, false, false, false, false, false, false, false};
        final List<float[]> fans = new ArrayList<float[]>();
        final List<float[]> bones = new ArrayList<float[]>();

        static WingModel get(int style) {
            if (CACHE[style] == null) CACHE[style] = build(style);
            return CACHE[style];
        }

        private static WingModel build(int style) {
            WingModel m = new WingModel();
            switch (style) {
                case 0: case 2: case 4: case 5: case 12: m.bat(4, 1.0f); break;
                case 1: m.feathers(3, 7, 0.20f, 78f, -12f, 2.0f); break;
                case 3: m.feathers(1, 5, 0.09f, 72f, -6f, 2.2f); break;
                case 6: m.bat(5, 1.25f); break;
                case 7: m.feathers(3, 9, 0.17f, 85f, -25f, 2.3f); break;
                case 8: m.feathers(2, 5, 0.20f, 75f, -5f, 1.8f); break;
                case 9: m.feathers(4, 9, 0.22f, 82f, -20f, 2.2f); break;
                case 10: m.feathers(1, 6, 0.06f, 80f, -10f, 2.0f); break;
                case 11: m.butterfly(); break;
                case 13: m.feathers(2, 6, 0.16f, 70f, -8f, 2.0f); break;
                case 14: m.feathers(3, 8, 0.17f, 80f, -18f, 2.1f); break;
                default: m.feathers(2, 6, 0.07f, 74f, -8f, 2.3f); break;
            }
            return m;
        }

        private void butterfly() {
            float[][][] lobes = {
                    {{0f, 0f}, {0.4f, 0.9f}, {1.3f, 1.6f}, {2.0f, 1.1f}, {1.8f, 0.3f}, {0.9f, 0f}},
                    {{0f, 0f}, {0.9f, 0f}, {1.6f, -0.3f}, {1.5f, -1.0f}, {0.8f, -1.1f}, {0.3f, -0.5f}}};
            for (float[][] lobe : lobes) {
                float[] flat = new float[lobe.length * 3];
                for (int i = 0; i < lobe.length; i++) {
                    flat[i * 3] = lobe[i][0];
                    flat[i * 3 + 1] = lobe[i][1];
                    flat[i * 3 + 2] = i == 0 ? 0f : (i == 1 || i == lobe.length - 1 ? 0.35f : 1f);
                }
                fans.add(flat);
                for (int i = 1; i < lobe.length; i++) bones.add(new float[]{0f, 0f, lobe[i][0], lobe[i][1]});
            }
        }

        private static float[] scallop(float[] a, float[] b, float wx, float wy) {
            float mx = (a[0] + b[0]) / 2f, my = (a[1] + b[1]) / 2f;
            return new float[]{mx + (wx - mx) * 0.35f, my + (wy - my) * 0.35f, 0.45f};
        }

        private void bat(int fingers, float tall) {
            float wx = 1.0f, wy = 0.9f * tall;
            float[][] tips = new float[fingers][2];
            for (int i = 0; i < fingers; i++) {
                float u = i / (float) (fingers - 1);
                tips[i][0] = 2.1f - 1.3f * u * u - 0.1f * u;
                tips[i][1] = (1.25f - 1.9f * u) * tall;
            }
            float[] b = {0.05f, -0.55f * tall};
            List<float[]> pts = new ArrayList<float[]>();
            pts.add(new float[]{wx, wy, 0f});
            pts.add(new float[]{tips[0][0], tips[0][1], 1f});
            for (int i = 1; i < fingers; i++) {
                pts.add(scallop(tips[i - 1], tips[i], wx, wy));
                pts.add(new float[]{tips[i][0], tips[i][1], 1f});
            }
            pts.add(scallop(tips[fingers - 1], b, wx, wy));
            pts.add(new float[]{b[0], b[1], 0.25f});
            pts.add(new float[]{0f, 0f, 0f});
            float[] flat = new float[pts.size() * 3];
            for (int i = 0; i < pts.size(); i++) {
                flat[i * 3] = pts.get(i)[0];
                flat[i * 3 + 1] = pts.get(i)[1];
                flat[i * 3 + 2] = pts.get(i)[2];
            }
            fans.add(flat);
            bones.add(new float[]{0f, 0f, wx, wy});
            for (float[] t : tips) bones.add(new float[]{wx, wy, t[0], t[1]});
        }

        private void feathers(int rows, int n, float width, float a0, float a1, float l0) {
            for (int r = 0; r < rows; r++) {
                float rs = 1f - 0.2f * r;
                float ox = 0.08f, oy = 0.2f - 0.14f * r;
                for (int k = 0; k < n; k++) {
                    float u = n == 1 ? 0f : k / (float) (n - 1);
                    float ang = (float) Math.toRadians(a0 + (a1 - a0) * u);
                    float len = l0 * rs * (0.65f + 0.35f * (float) Math.cos((u - 0.25f) * 2.2f));
                    float dx = (float) Math.cos(ang), dy = (float) Math.sin(ang);
                    float px = -dy, py = dx;
                    float mx = ox + dx * len * 0.35f, my = oy + dy * len * 0.35f;
                    float wd = width * rs;
                    fans.add(new float[]{
                            ox, oy, 0f,
                            mx + px * wd, my + py * wd, 0.35f,
                            ox + dx * len, oy + dy * len, 1f,
                            mx - px * wd, my - py * wd, 0.35f});
                    bones.add(new float[]{ox, oy, ox + dx * len, oy + dy * len});
                }
            }
        }

        private static int fire(float h) {
            if (h < 0.5f) return RenderUtil.mix(0xFF8A0A00, 0xFFFF5A00, h * 2f);
            return RenderUtil.mix(0xFFFF5A00, 0xFFFFE070, (h - 0.5f) * 2f);
        }

        private void strips() {
            for (float[] fan : fans) {
                GL11.glBegin(GL11.GL_LINE_STRIP);
                for (int i = 3; i < fan.length; i += 3) GL11.glVertex3f(fan[i], fan[i + 1], 0f);
                GL11.glEnd();
            }
            GL11.glBegin(GL11.GL_LINES);
            for (float[] b : bones) {
                GL11.glVertex3f(b[0], b[1], 0f);
                GL11.glVertex3f(b[2], b[3], 0f);
            }
            GL11.glEnd();
        }

        void draw(int col, boolean glow, boolean fire) {
            RenderUtil.begin();
            GlStateManager.disableCull();
            GlStateManager.depthMask(false);
            int dark = RenderUtil.shade(col, 0.45f);
            int edge = RenderUtil.mix(col, 0xFFFFFFFF, 0.45f);
            float[] zs = {0.006f, -0.006f};
            for (float z : zs) {
                for (float[] fan : fans) {
                    GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                    for (int i = 0; i < fan.length; i += 3) {
                        int c = fire ? fire(fan[i + 2]) : RenderUtil.mix(dark, col, fan[i + 2]);
                        RenderUtil.color(RenderUtil.alpha(c, 0.72f));
                        GL11.glVertex3f(fan[i], fan[i + 1], z);
                    }
                    GL11.glEnd();
                }
            }
            GL11.glLineWidth(2.5f);
            RenderUtil.color(fire ? 0xFFFFD27A : edge);
            strips();
            if (glow) {
                GlStateManager.blendFunc(770, 1);
                GL11.glLineWidth(7f);
                RenderUtil.color(RenderUtil.alpha(fire ? 0xFFFF8A00 : col, 0.28f));
                strips();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            }
            GlStateManager.depthMask(true);
            GlStateManager.enableCull();
            RenderUtil.end();
        }
    }

    // =========================================================================
    //  CHIFRES (cones curvos gerados por codigo + espinhos + fogo artificial)
    // =========================================================================
    private static final class HS {
        final float h, out, back, r0, ridges;
        final int n, base, tip;
        final boolean glow, halo;
        boolean curl;
        int spikes;
        float spikeLen;
        int flameA, flameB;

        HS(float h, float out, float back, float r0, int n, float ridges, int base, int tip, boolean glow, boolean halo) {
            this.h = h;
            this.out = out;
            this.back = back;
            this.r0 = r0;
            this.n = n;
            this.ridges = ridges;
            this.base = base;
            this.tip = tip;
            this.glow = glow;
            this.halo = halo;
        }

        HS thorn(int tipCol, int flA, int flB) {
            curl = true;
            spikes = 8;
            spikeLen = 0.11f;
            flameA = flA;
            flameB = flB;
            return this;
        }
    }

    private static HS thornHorn(int base, int tip, int fa, int fb) {
        return new HS(0.50f, 0.20f, 0.0f, 0.075f, 8, 0f, base, tip, true, false).thorn(tip, fa, fb);
    }

    private static final HS[] HORNS = {
            new HS(0.38f, 0.10f, 0.05f, 0.06f, 10, 0f, 0xFFB01000, 0xFFFFD040, true, false),  // Fire
            new HS(0.34f, 0.12f, 0.10f, 0.055f, 8, 0f, 0xFF0A0A0A, 0xFF4A0A0A, false, false), // Dark
            new HS(0.30f, 0.02f, 0.00f, 0.045f, 8, 0f, 0xFFFFFFFF, 0xFFFFD700, true, true),   // Angel
            new HS(0.40f, 0.18f, 0.08f, 0.07f, 10, 4f, 0xFF7A0000, 0xFF1A0000, false, false), // Demon
            new HS(0.42f, 0.06f, 0.02f, 0.07f, 4, 0f, 0xFF3FC8FF, 0xFFEFFFFF, true, false),   // Crystal
            new HS(0.30f, 0.14f, 0.30f, 0.06f, 10, 6f, 0xFFD9C8A0, 0xFF6B4A2B, false, false), // Dragon
            thornHorn(0xFF0A0D14, 0xFF2F9BFF, 0xFF1E7BFF, 0xFFB8FFFF),   // Thorn Blue
            thornHorn(0xFF140A0A, 0xFFFF3040, 0xFFFF2A10, 0xFFFFE0A0),   // Thorn Red
            thornHorn(0xFF0E0A14, 0xFFB050FF, 0xFF8A30FF, 0xFFF0D0FF),   // Thorn Purple
            thornHorn(0xFF2A2A30, 0xFFFFFFFF, 0xFFBFD8FF, 0xFFFFFFFF),   // Thorn White
            thornHorn(0xFF1A1206, 0xFFFFC840, 0xFFFF9A10, 0xFFFFF0A0),   // Thorn Gold
            new HS(0.46f, 0.08f, 0.0f, 0.06f, 5, 0f, 0xFF8FE0FF, 0xFFFFFFFF, true, false),    // Ice
    };

    private static void horns(Ctx c) {
        CosmeticModules.Horns h = ModuleManager.get(CosmeticModules.Horns.class);
        if (h == null || !h.enabled) return;
        CosmeticModules.Avatar av = ModuleManager.get(CosmeticModules.Avatar.class);
        if (av != null && av.enabled && av.headless.b()) return;
        HS s;
        if (h.style.index < HORNS.length) {
            s = HORNS[h.style.index];
        } else {
            int col = h.color.c();
            s = new HS(h.height.f(), h.spread.f(), 0.05f, 0.06f, 8, 0f, RenderUtil.shade(col, 0.5f), col, true, false);
        }
        float size = h.size.f();
        GlStateManager.pushMatrix();
        if (c.sneak) GlStateManager.translate(0f, 0.0625f, 0f);
        GlStateManager.rotate(c.headYaw, 0f, 1f, 0f);
        GlStateManager.rotate(c.headPitch, 1f, 0f, 0f);
        GlStateManager.scale(1f, -1f, 1f);
        RenderUtil.begin();
        GlStateManager.disableCull();
        for (int side = -1; side <= 1; side += 2) hornMesh(s, side, size, 1f, 1f, true);
        if (s.glow && h.glow.b()) {
            GlStateManager.depthMask(false);
            GlStateManager.blendFunc(770, 1);
            for (int side = -1; side <= 1; side += 2) hornMesh(s, side, size, 1.7f, 0.18f, false);
            if (s.halo) halo(c.time);
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.depthMask(true);
        }
        if (s.flameA != 0 && h.flame.b()) {
            GlStateManager.depthMask(false);
            GlStateManager.blendFunc(770, 1);
            GlStateManager.pushMatrix();
            GlStateManager.translate(0f, 0.50f, 0.02f);
            float fs = h.flameSize.f() * size;
            artFlame(c.time, s.flameA, s.flameB, 0.62f * fs, 0.20f * fs);
            GlStateManager.popMatrix();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.depthMask(true);
        }
        GlStateManager.enableCull();
        RenderUtil.end();
        GlStateManager.popMatrix();
    }

    /**
     * Chama artificial (sem particulas do Minecraft): gota luminosa feita de 3 planos cruzados em 3 camadas,
     * com balanco e tremulacao. Desenha de y=0 ate y=height (y para cima). Estado GL: aditivo, sem culling.
     */
    static void artFlame(float time, int colA, int colB, float height, float width) {
        float flick = 1f + 0.07f * (float) Math.sin(time * 0.8f) + 0.04f * (float) Math.sin(time * 1.9f + 1f);
        int mid = RenderUtil.mix(colA, colB, 0.5f);
        for (int plane = 0; plane < 3; plane++) {
            GlStateManager.pushMatrix();
            GlStateManager.rotate(plane * 60f, 0f, 1f, 0f);
            for (int layer = 0; layer < 3; layer++) {
                float hh = height * flick * (layer == 2 ? 0.62f : (layer == 1 ? 0.85f : 1f));
                float ww = width * (layer == 2 ? 0.38f : (layer == 1 ? 0.65f : 1f));
                int col = layer == 0 ? colA : (layer == 1 ? mid : colB);
                float al = layer == 0 ? 0.32f : (layer == 1 ? 0.45f : 0.75f);
                GL11.glBegin(GL11.GL_QUAD_STRIP);
                for (int i = 0; i <= 14; i++) {
                    float t = i / 14f;
                    float prof = (float) Math.pow(Math.sin(Math.PI * Math.pow(t, 0.55)), 0.9) * (1f - 0.35f * t);
                    float sway = (float) Math.sin(time * 0.17f + t * 3.2f + plane) * 0.05f * t * height * 2f;
                    float y = t * hh;
                    float edgeA = al * (1f - 0.25f * t);
                    RenderUtil.color(RenderUtil.alpha(col, edgeA * 0.15f));
                    GL11.glVertex3f(sway - ww * prof, y, 0f);
                    RenderUtil.color(RenderUtil.alpha(col, edgeA));
                    GL11.glVertex3f(sway, y, 0f);
                }
                GL11.glEnd();
                GL11.glBegin(GL11.GL_QUAD_STRIP);
                for (int i = 0; i <= 14; i++) {
                    float t = i / 14f;
                    float prof = (float) Math.pow(Math.sin(Math.PI * Math.pow(t, 0.55)), 0.9) * (1f - 0.35f * t);
                    float sway = (float) Math.sin(time * 0.17f + t * 3.2f + plane) * 0.05f * t * height * 2f;
                    float y = t * hh;
                    float edgeA = al * (1f - 0.25f * t);
                    RenderUtil.color(RenderUtil.alpha(col, edgeA));
                    GL11.glVertex3f(sway, y, 0f);
                    RenderUtil.color(RenderUtil.alpha(col, edgeA * 0.15f));
                    GL11.glVertex3f(sway + ww * prof, y, 0f);
                }
                GL11.glEnd();
            }
            GlStateManager.popMatrix();
        }
        // base luminosa
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        RenderUtil.color(RenderUtil.alpha(colB, 0.5f));
        GL11.glVertex3f(0f, 0.01f, 0f);
        RenderUtil.color(RenderUtil.alpha(colA, 0f));
        for (int i = 0; i <= 20; i++) {
            double a = Math.PI * 2.0 * i / 20.0;
            GL11.glVertex3d(Math.cos(a) * width * 1.2, 0.01, Math.sin(a) * width * 1.2);
        }
        GL11.glEnd();
    }

    private static void hornMesh(HS s, int side, float size, float radScale, float alpha, boolean spikes) {
        int rings = 16, n = s.n;
        float[][] c = new float[rings][3];
        float[] rad = new float[rings];
        int[] rc = new int[rings];
        float[][] tn = new float[rings][3], n1s = new float[rings][3], n2s = new float[rings][3];
        float norm = (float) Math.sin(1.35);
        for (int j = 0; j < rings; j++) {
            float t = j / (rings - 1f);
            if (s.curl) c[j][0] = side * (0.16f + s.out * size * (float) Math.sin(t * 2.3f));
            else c[j][0] = side * (0.17f + s.out * size * t * t);
            c[j][1] = 0.49f + s.h * size * (float) Math.sin(t * 1.35f) / norm;
            c[j][2] = -0.03f + s.back * size * t * t;
            float r = s.r0 * size * (float) Math.pow(1f - t, 0.85f) + 0.004f;
            if (s.ridges > 0f) r *= 1f + 0.18f * (float) Math.sin(t * s.ridges * 6.2832f) * (1f - t);
            rad[j] = r * radScale;
            rc[j] = RenderUtil.mix(s.base, s.tip, (float) Math.pow(t, 1.2));
        }
        float[][][] p = new float[rings][n + 1][3];
        for (int j = 0; j < rings; j++) {
            float[] a = c[Math.max(j - 1, 0)], b = c[Math.min(j + 1, rings - 1)];
            float tx = b[0] - a[0], ty = b[1] - a[1], tz = b[2] - a[2];
            float tl = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
            tx /= tl;
            ty /= tl;
            tz /= tl;
            float n1x = ty, n1y = -tx, n1z = 0f;
            float l1 = (float) Math.sqrt(n1x * n1x + n1y * n1y);
            if (l1 < 1e-4f) {
                n1x = 1f;
                n1y = 0f;
                l1 = 1f;
            }
            n1x /= l1;
            n1y /= l1;
            float n2x = ty * n1z - tz * n1y, n2y = tz * n1x - tx * n1z, n2z = tx * n1y - ty * n1x;
            tn[j][0] = tx; tn[j][1] = ty; tn[j][2] = tz;
            n1s[j][0] = n1x; n1s[j][1] = n1y; n1s[j][2] = n1z;
            n2s[j][0] = n2x; n2s[j][1] = n2y; n2s[j][2] = n2z;
            for (int i = 0; i <= n; i++) {
                double ph = Math.PI * 2.0 * i / n;
                float cs = (float) Math.cos(ph), sn = (float) Math.sin(ph);
                p[j][i][0] = c[j][0] + rad[j] * (cs * n1x + sn * n2x);
                p[j][i][1] = c[j][1] + rad[j] * (cs * n1y + sn * n2y);
                p[j][i][2] = c[j][2] + rad[j] * (cs * n1z + sn * n2z);
            }
        }
        for (int j = 0; j < rings - 1; j++) {
            GL11.glBegin(GL11.GL_QUAD_STRIP);
            for (int i = 0; i <= n; i++) {
                float k = 0.65f + 0.35f * (float) Math.cos(Math.PI * 2.0 * i / n);
                for (int q = 0; q < 2; q++) {
                    int col = RenderUtil.shade(rc[j + q], k);
                    RenderUtil.color(RenderUtil.alpha(col, alpha));
                    GL11.glVertex3f(p[j + q][i][0], p[j + q][i][1], p[j + q][i][2]);
                }
            }
            GL11.glEnd();
        }
        // espinhos ao longo do chifre
        if (spikes && s.spikes > 0) {
            for (int k = 0; k < s.spikes; k++) {
                int j = 2 + (int) ((rings - 5) * (k / (float) Math.max(1, s.spikes - 1)));
                float t = j / (rings - 1f);
                float len = s.spikeLen * size * (1.15f - 0.75f * t);
                float rr = Math.max(0.012f, rad[j] * 0.55f);
                float[][] dirs = {n1s[j], {-n1s[j][0], -n1s[j][1], -n1s[j][2]}, n2s[j], {-n2s[j][0], -n2s[j][1], -n2s[j][2]}};
                for (float[] d : dirs) {
                    float[] t0 = tn[j];
                    // perpendicular a d e a t
                    float px = d[1] * t0[2] - d[2] * t0[1], py = d[2] * t0[0] - d[0] * t0[2], pz = d[0] * t0[1] - d[1] * t0[0];
                    float pl = (float) Math.sqrt(px * px + py * py + pz * pz);
                    if (pl < 1e-4f) continue;
                    px /= pl; py /= pl; pz /= pl;
                    float bx = c[j][0] + d[0] * rad[j] * 0.8f, by = c[j][1] + d[1] * rad[j] * 0.8f, bz = c[j][2] + d[2] * rad[j] * 0.8f;
                    float ax = bx + d[0] * len + t0[0] * len * 0.5f, ay = by + d[1] * len + t0[1] * len * 0.5f, az = bz + d[2] * len + t0[2] * len * 0.5f;
                    float[][] bp = {
                            {bx + t0[0] * rr, by + t0[1] * rr, bz + t0[2] * rr},
                            {bx + px * rr, by + py * rr, bz + pz * rr},
                            {bx - t0[0] * rr, by - t0[1] * rr, bz - t0[2] * rr},
                            {bx - px * rr, by - py * rr, bz - pz * rr}};
                    GL11.glBegin(GL11.GL_TRIANGLES);
                    for (int f = 0; f < 4; f++) {
                        float[] b0 = bp[f], b1 = bp[(f + 1) % 4];
                        RenderUtil.color(RenderUtil.alpha(RenderUtil.shade(s.base, 1.4f), alpha));
                        GL11.glVertex3f(b0[0], b0[1], b0[2]);
                        GL11.glVertex3f(b1[0], b1[1], b1[2]);
                        RenderUtil.color(RenderUtil.alpha(s.tip, alpha));
                        GL11.glVertex3f(ax, ay, az);
                    }
                    GL11.glEnd();
                }
            }
        }
    }

    private static void halo(float time) {
        GL11.glBegin(GL11.GL_QUAD_STRIP);
        for (int i = 0; i <= 36; i++) {
            double a = Math.PI * 2.0 * i / 36.0 + time * 0.02;
            RenderUtil.color(0xCCFFD700);
            GL11.glVertex3d(Math.cos(a) * 0.24, 0.98, Math.sin(a) * 0.24);
            RenderUtil.color(0x33FFD700);
            GL11.glVertex3d(Math.cos(a) * 0.32, 0.98, Math.sin(a) * 0.32);
        }
        GL11.glEnd();
    }

    // =========================================================================
    //  KORBLOX (perna direita de armadura) - desenhada no espaco do modelo
    // =========================================================================
    private static void qbox(float x0, float y0, float z0, float x1, float y1, float z1, int col) {
        GL11.glBegin(GL11.GL_QUADS);
        RenderUtil.color(RenderUtil.shade(col, 1.0f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x0, y0, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.55f));
        GL11.glVertex3f(x0, y1, z0); GL11.glVertex3f(x1, y1, z0); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x0, y1, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.8f));
        GL11.glVertex3f(x0, y0, z1); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x0, y1, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.7f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y1, z0); GL11.glVertex3f(x0, y1, z0);
        RenderUtil.color(RenderUtil.shade(col, 0.9f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x0, y0, z1); GL11.glVertex3f(x0, y1, z1); GL11.glVertex3f(x0, y1, z0);
        RenderUtil.color(RenderUtil.shade(col, 0.75f));
        GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x1, y1, z0);
        GL11.glEnd();
    }

    private static void korblox(Ctx c) {
        CosmeticModules.Avatar av = ModuleManager.get(CosmeticModules.Avatar.class);
        if (av == null || !av.enabled || !av.korblox.b() || !c.hasLeg) return;
        float u = 0.0625f;
        RenderUtil.begin();
        GlStateManager.disableCull();
        GlStateManager.pushMatrix();
        GlStateManager.translate(c.legX * u, c.legY * u, c.legZ * u);
        GlStateManager.rotate(c.legAng * 57.29578f, 1f, 0f, 0f);
        float w = 2.3f * u, d = 2.3f * u;
        // coxa (carvao), joelho (osso), canela (cinza + faixas), bota (osso)
        qbox(-w, 0f, -d, w, 5.2f * u, d, 0xFF22242B);
        qbox(-w - 0.25f * u, 4.7f * u, -d - 0.25f * u, w + 0.25f * u, 6.4f * u, d + 0.25f * u, 0xFFE6E1D2);
        qbox(-w, 6.4f * u, -d, w, 10.6f * u, d, 0xFF2E3038);
        qbox(-w - 0.15f * u, 7.4f * u, -d - 0.15f * u, w + 0.15f * u, 7.9f * u, d + 0.15f * u, 0xFFB52A2A);
        qbox(-w - 0.15f * u, 9.0f * u, -d - 0.15f * u, w + 0.15f * u, 9.5f * u, d + 0.15f * u, 0xFFB52A2A);
        qbox(-w - 0.2f * u, 10.4f * u, -d - 0.2f * u, w + 0.2f * u, 12.2f * u, d + 0.6f * u, 0xFFE6E1D2);
        GlStateManager.popMatrix();
        GlStateManager.enableCull();
        RenderUtil.end();
    }

    // =========================================================================
    //  AURA (espaco da entidade: y para cima, origem nos pes)
    // =========================================================================
    public static void renderAura(float time, boolean preview) {
        CosmeticModules.Aura a = ModuleManager.get(CosmeticModules.Aura.class);
        if (a == null || !a.enabled) return;
        float t = time / 20f * a.speed.f();
        float size = a.size.f();
        int col = a.color.c();
        int bright = RenderUtil.mix(col, 0xFFFFFFFF, 0.5f);

        RenderUtil.begin();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.blendFunc(770, 1);
        switch (a.style.index) {
            case 0: auraRing(t, size, col, bright); break;
            case 1: auraHexagram(t, size, col, bright); break;
            case 2: auraHelix(t, size, col, bright); break;
            case 3: auraStars(t, size, col, bright); break;
            case 4: auraOrbs(t, size, col, bright, a.count.i(), false); break;
            case 5: auraOrbs(t, size, col, bright, a.count.i(), true); break;
            case 6: auraGalaxy(t, size, col, bright); break;
            case 7: auraFlameRing(time, size, col, bright); break;
            case 8: auraLightning(t, size, col, bright); break;
            case 9: auraSparkles(t, size, col, bright); break;
            case 10: auraRunes(t, size, col, bright); break;
            case 11: auraVortex(t, size, col, bright); break;
            default: auraSnow(t, size, col, bright); break;
        }
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        RenderUtil.end();
    }

    private static void orb(float x, float y, float z, float r, int col, float a) {
        for (int pl = 0; pl < 3; pl++) {
            GL11.glBegin(GL11.GL_TRIANGLE_FAN);
            RenderUtil.color(RenderUtil.alpha(RenderUtil.mix(col, 0xFFFFFFFF, 0.65f), a));
            GL11.glVertex3f(x, y, z);
            RenderUtil.color(RenderUtil.alpha(col, 0f));
            for (int i = 0; i <= 14; i++) {
                double ang = Math.PI * 2.0 * i / 14.0;
                float cc = (float) Math.cos(ang) * r, ss = (float) Math.sin(ang) * r;
                if (pl == 0) GL11.glVertex3f(x + cc, y + ss, z);
                else if (pl == 1) GL11.glVertex3f(x + cc, y, z + ss);
                else GL11.glVertex3f(x, y + cc, z + ss);
            }
            GL11.glEnd();
        }
    }

    private static void auraOrbs(float t, float size, int col, int bright, int count, boolean trail) {
        ring(size * 0.9f, size * 1.0f, 0.03f, col, 0f, 360f, 0f, 0.18f);
        for (int k = 0; k < count; k++) {
            float ph = k / (float) count;
            float spd = 1.2f + 0.25f * (k % 3);
            int tl = trail ? 9 : 1;
            for (int q = 0; q < tl; q++) {
                double ang = t * spd * (k % 2 == 0 ? 1.0 : -1.0) + ph * Math.PI * 2.0 - q * 0.09 * (k % 2 == 0 ? 1.0 : -1.0);
                float rad = size * (0.85f + 0.15f * (float) Math.sin(t * 1.5f + k));
                float y = 0.25f + 1.5f * (0.5f + 0.5f * (float) Math.sin(t * 0.9f + k * 1.7f)) ;
                float px = (float) Math.cos(ang) * rad, pz = (float) Math.sin(ang) * rad;
                float fade = 1f - q / (float) tl;
                orb(px, y, pz, (q == 0 ? 0.17f : 0.12f * fade) * (0.9f + 0.1f * size), q == 0 ? bright : col, 0.95f * fade);
            }
        }
    }

    private static void auraGalaxy(float t, float size, int col, int bright) {
        ring(size * 0.2f, size * 1.5f, 0.9f, col, 0f, 360f, 0.10f, 0f);
        GL11.glPointSize(3f);
        GL11.glBegin(GL11.GL_POINTS);
        for (int arm = 0; arm < 3; arm++) {
            for (int i = 0; i < 70; i++) {
                float u = i / 69f;
                double ang = t * 0.8 + arm * Math.PI * 2.0 / 3.0 + u * 5.0;
                float r = size * (0.2f + 1.3f * u);
                float y = 0.9f + (float) Math.sin(ang * 2.0 + t) * 0.07f;
                RenderUtil.color(RenderUtil.alpha(i % 5 == 0 ? 0xFFFFFFFF : (i % 2 == 0 ? bright : col), 1f - u * 0.6f));
                GL11.glVertex3d(Math.cos(ang) * r, y, Math.sin(ang) * r);
            }
        }
        GL11.glEnd();
    }

    private static void auraFlameRing(float time, float size, int col, int bright) {
        int n = 10;
        for (int i = 0; i < n; i++) {
            double ang = Math.PI * 2.0 * i / n + time * 0.01;
            GlStateManager.pushMatrix();
            GlStateManager.translate((float) Math.cos(ang) * size, 0.02f, (float) Math.sin(ang) * size);
            artFlame(time + i * 7f, col, bright, 0.65f + 0.15f * (float) Math.sin(time * 0.2f + i), 0.13f);
            GlStateManager.popMatrix();
        }
        ring(size * 0.85f, size * 1.1f, 0.03f, col, 0f, 360f, 0.35f, 0f);
    }

    private static void auraLightning(float t, float size, int col, int bright) {
        int frame = (int) (t * 8f);
        for (int b = 0; b < 6; b++) {
            Random r = new Random(frame * 31L + b * 977L);
            if (r.nextInt(3) == 0) continue;
            double ang = Math.PI * 2.0 * b / 6.0 + r.nextDouble() * 0.5;
            float x = (float) Math.cos(ang) * size, z = (float) Math.sin(ang) * size;
            for (int pass = 0; pass < 2; pass++) {
                Random q = new Random(frame * 31L + b * 977L + 5);
                GL11.glLineWidth(pass == 0 ? 6f : 2f);
                GL11.glBegin(GL11.GL_LINE_STRIP);
                float px = x, pz = z;
                for (int i = 0; i <= 8; i++) {
                    RenderUtil.color(pass == 0 ? RenderUtil.alpha(col, 0.35f) : bright);
                    GL11.glVertex3f(px, 2.3f - i * 0.29f, pz);
                    px += (q.nextFloat() - 0.5f) * 0.3f;
                    pz += (q.nextFloat() - 0.5f) * 0.3f;
                }
                GL11.glEnd();
            }
        }
        ring(size * 0.8f, size * 1.1f, 0.03f, col, 0f, 360f, 0.3f, 0f);
    }

    private static void auraSparkles(float t, float size, int col, int bright) {
        for (int i = 0; i < 28; i++) {
            float u = (t * 0.35f + i * 0.137f) % 1f;
            double ang = i * 2.399 + t * 0.6;
            float r = size * (0.45f + 0.55f * (float) Math.abs(Math.sin(i * 1.3)));
            float x = (float) Math.cos(ang) * r, z = (float) Math.sin(ang) * r, y = u * 2.3f;
            float a = (float) Math.sin(u * Math.PI);
            float s = 0.07f + 0.04f * (i % 3);
            GL11.glLineWidth(2f);
            RenderUtil.color(RenderUtil.alpha(i % 2 == 0 ? bright : col, a));
            GL11.glBegin(GL11.GL_LINES);
            GL11.glVertex3f(x - s, y, z); GL11.glVertex3f(x + s, y, z);
            GL11.glVertex3f(x, y - s, z); GL11.glVertex3f(x, y + s, z);
            GL11.glVertex3f(x, y, z - s); GL11.glVertex3f(x, y, z + s);
            GL11.glEnd();
        }
        ring(size * 0.7f, size * 1.0f, 0.03f, col, 0f, 360f, 0f, 0.25f);
    }

    private static void auraRunes(float t, float size, int col, int bright) {
        for (int k = 0; k < 3; k++) {
            float u = (t * 0.25f + k / 3f) % 1f;
            float y = 0.05f + u * 2.1f;
            float a = (float) Math.sin(u * Math.PI);
            float r = size * (0.95f - 0.15f * u);
            loop(r, y, RenderUtil.alpha(col, a * 0.9f), 2f);
            loop(r * 0.82f, y, RenderUtil.alpha(bright, a * 0.6f), 1.5f);
            GL11.glLineWidth(2f);
            GL11.glBegin(GL11.GL_LINES);
            for (int i = 0; i < 16; i++) {
                double ang = Math.PI * 2.0 * i / 16.0 + t * (k % 2 == 0 ? 0.5 : -0.5);
                float l = (i % 3 == 0) ? 0.18f : (i % 3 == 1 ? 0.1f : 0.14f);
                RenderUtil.color(RenderUtil.alpha(bright, a));
                GL11.glVertex3d(Math.cos(ang) * r * 0.82, y, Math.sin(ang) * r * 0.82);
                GL11.glVertex3d(Math.cos(ang) * (r * 0.82 + l * size), y, Math.sin(ang) * (r * 0.82 + l * size));
            }
            GL11.glEnd();
        }
        starFlat(size * 0.8f, 0.04f, t * 30f, bright, 2.5f);
    }

    private static void auraVortex(float t, float size, int col, int bright) {
        for (int k = 0; k < 9; k++) {
            float u = (t * 0.35f + k / 9f) % 1f;
            float y = u * 2.3f;
            float r = size * (0.35f + 0.8f * u);
            float a = 1f - u;
            double ph = t * 3.0 + k;
            GL11.glLineWidth(3f);
            GL11.glBegin(GL11.GL_LINE_STRIP);
            for (int i = 0; i <= 26; i++) {
                double ang = ph + Math.PI * 1.4 * i / 26.0;
                RenderUtil.color(RenderUtil.alpha(i > 20 ? bright : col, a * (1f - Math.abs(i - 13) / 14f)));
                GL11.glVertex3d(Math.cos(ang) * r, y, Math.sin(ang) * r);
            }
            GL11.glEnd();
        }
        ring(size * 0.3f, size * 0.9f, 0.03f, col, 0f, 360f, 0.35f, 0f);
    }

    private static void auraSnow(float t, float size, int col, int bright) {
        GL11.glPointSize(3.5f);
        GL11.glBegin(GL11.GL_POINTS);
        for (int i = 0; i < 46; i++) {
            float u = (t * 0.28f + i * 0.2371f) % 1f;
            double ang = i * 2.399 + Math.sin(t + i) * 0.4;
            float r = size * 1.4f * (float) Math.sqrt((i * 0.618f) % 1f) + 0.2f;
            RenderUtil.color(RenderUtil.alpha(i % 3 == 0 ? 0xFFFFFFFF : bright, (float) Math.sin(u * Math.PI)));
            GL11.glVertex3d(Math.cos(ang) * r, 2.6f - u * 2.6f, Math.sin(ang) * r);
        }
        GL11.glEnd();
        ring(size * 0.8f, size * 1.2f, 0.03f, col, 0f, 360f, 0.2f, 0f);
    }

    private static void ring(float rIn, float rOut, float y, int col, float a0, float a1, float aIn, float aOut) {
        int seg = 40;
        GL11.glBegin(GL11.GL_QUAD_STRIP);
        for (int i = 0; i <= seg; i++) {
            double ang = Math.toRadians(a0 + (a1 - a0) * i / seg);
            float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
            RenderUtil.color(RenderUtil.alpha(col, aIn));
            GL11.glVertex3f(cs * rIn, y, sn * rIn);
            RenderUtil.color(RenderUtil.alpha(col, aOut));
            GL11.glVertex3f(cs * rOut, y, sn * rOut);
        }
        GL11.glEnd();
    }

    private static void loop(float r, float y, int col, float width) {
        GL11.glLineWidth(width);
        RenderUtil.color(col);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (int i = 0; i < 48; i++) {
            double ang = Math.PI * 2.0 * i / 48.0;
            GL11.glVertex3d(Math.cos(ang) * r, y, Math.sin(ang) * r);
        }
        GL11.glEnd();
    }

    private static void auraRing(float t, float size, int col, int bright) {
        float r = size;
        ring(r - 0.30f * size, r, 0.03f, col, 0f, 360f, 0f, 0.55f);
        float a0 = t * 220f;
        ring(r - 0.22f * size, r + 0.03f, 0.035f, bright, a0, a0 + 100f, 0f, 1f);
        loop(r, 0.04f, RenderUtil.alpha(bright, 0.9f), 2.5f);
        for (int k = 0; k < 2; k++) {
            float p = (t * 0.5f + k * 0.5f) % 1f;
            loop(r * (0.95f - 0.3f * p), 0.05f + p * 1.9f, RenderUtil.alpha(col, (1f - p) * 0.7f), 2f);
        }
    }

    private static void starFlat(float r, float y, float rot, int col, float lw) {
        GL11.glLineWidth(lw);
        RenderUtil.color(col);
        for (int tri = 0; tri < 2; tri++) {
            GL11.glBegin(GL11.GL_LINE_LOOP);
            for (int i = 0; i < 3; i++) {
                double ang = Math.toRadians(rot + tri * 60 + i * 120);
                GL11.glVertex3d(Math.cos(ang) * r, y, Math.sin(ang) * r);
            }
            GL11.glEnd();
        }
    }

    private static void auraHexagram(float t, float size, int col, int bright) {
        float r = size;
        ring(r * 0.92f, r * 1.12f, 0.03f, col, 0f, 360f, 0.5f, 0.0f);
        loop(r * 1.12f, 0.035f, RenderUtil.alpha(bright, 0.8f), 2f);
        loop(r * 0.92f, 0.035f, RenderUtil.alpha(bright, 0.8f), 2f);
        starFlat(r * 0.92f, 0.04f, t * 40f, bright, 3f);
        starFlat(r * 0.92f, 0.045f, t * 40f, RenderUtil.alpha(col, 0.5f), 7f);
        GL11.glLineWidth(2f);
        RenderUtil.color(RenderUtil.alpha(bright, 0.7f));
        GL11.glBegin(GL11.GL_LINES);
        for (int i = 0; i < 24; i++) {
            double ang = Math.PI * 2.0 * i / 24.0 - t * 0.3;
            GL11.glVertex3d(Math.cos(ang) * r * 1.12, 0.035, Math.sin(ang) * r * 1.12);
            GL11.glVertex3d(Math.cos(ang) * r * 1.2, 0.035, Math.sin(ang) * r * 1.2);
        }
        GL11.glEnd();
    }

    private static void auraHelix(float t, float size, int col, int bright) {
        for (int s = 0; s < 2; s++) {
            GL11.glLineWidth(3f);
            GL11.glBegin(GL11.GL_LINE_STRIP);
            for (int i = 0; i < 64; i++) {
                float u = i / 63f;
                double ang = Math.toRadians(t * 120f) + u * Math.PI * 4.0 + s * Math.PI;
                float rr = size * (0.7f + 0.1f * (float) Math.sin(u * Math.PI));
                float fade = (float) Math.sin(u * Math.PI);
                RenderUtil.color(RenderUtil.alpha(i % 8 < 2 ? bright : col, fade));
                GL11.glVertex3d(Math.cos(ang) * rr, u * 1.9f, Math.sin(ang) * rr);
            }
            GL11.glEnd();
        }
        ring(size * 0.55f, size * 0.8f, 0.03f, col, 0f, 360f, 0f, 0.35f);
    }

    private static void auraStars(float t, float size, int col, int bright) {
        ring(size * 0.7f, size * 1.0f, 0.03f, col, 0f, 360f, 0f, 0.3f);
        for (int k = 0; k < 3; k++) {
            double ang = Math.toDegrees(t * 1.4) + k * 120.0;
            double rad = Math.toRadians(ang);
            float px = (float) Math.cos(rad) * 1.15f * size;
            float pz = (float) Math.sin(rad) * 1.15f * size;
            float py = 0.95f + 0.15f * (float) Math.sin(t * 2f + k);
            GlStateManager.pushMatrix();
            GlStateManager.translate(px, py, pz);
            GlStateManager.rotate((float) (90.0 - ang), 0f, 1f, 0f);
            GlStateManager.rotate(t * 90f, 0f, 0f, 1f);
            for (int pass = 0; pass < 2; pass++) {
                GL11.glLineWidth(pass == 0 ? 6f : 2.5f);
                RenderUtil.color(pass == 0 ? RenderUtil.alpha(col, 0.35f) : bright);
                for (int tri = 0; tri < 2; tri++) {
                    GL11.glBegin(GL11.GL_LINE_LOOP);
                    for (int i = 0; i < 3; i++) {
                        double aa = Math.toRadians(90 + tri * 60 + i * 120);
                        GL11.glVertex3d(Math.cos(aa) * 0.2, Math.sin(aa) * 0.2, 0.0);
                    }
                    GL11.glEnd();
                }
            }
            GlStateManager.popMatrix();
        }
    }
}
