package com.larpclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.image.BufferedImage;
import java.util.Random;

/** Efeito do corpo: brilho branco pulsante + manchas pretas que se movem (estilo vaca/AE). */
public final class SpotFx {
    private SpotFx() {}

    private static ResourceLocation tex;

    private static void ensure() {
        if (tex != null) return;
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Random r = new Random(11L);
        for (int n = 0; n < 17; n++) {
            float cx = r.nextFloat() * 64f, cy = r.nextFloat() * 64f;
            float rad = 3.5f + r.nextFloat() * 6f;
            float ph = r.nextFloat() * 6.28f;
            int col = (n % 4 == 0) ? 0xF0341E10 : 0xF00E0E0E;
            for (int y = 0; y < 64; y++) {
                for (int x = 0; x < 64; x++) {
                    float dx = Math.abs(x - cx), dy = Math.abs(y - cy);
                    if (dx > 32f) dx = 64f - dx;
                    if (dy > 32f) dy = 64f - dy;
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    float ang = (float) Math.atan2(y - cy, x - cx);
                    float rr = rad * (1f + 0.35f * (float) Math.sin(ang * 3f + ph) + 0.15f * (float) Math.sin(ang * 5f - ph));
                    if (d < rr) img.setRGB(x, y, col);
                }
            }
        }
        tex = Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation("larpspots", new DynamicTexture(img));
    }

    /**
     * Desenha o efeito por cima do corpo ja renderizado. O chamador deixa a matriz no espaco do modelo
     * (mesmo espaco usado pelo ModelRenderer).
     */
    public static void draw(ModelPlayer m, boolean noHead, boolean kor, boolean s15, float time, float speed) {
        ensure();
        Minecraft mc = Minecraft.getMinecraft();
        float f = 0.0625f;
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(false);
        GlStateManager.enableAlpha();
        GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
        GL11.glPolygonOffset(-2f, -2f);

        // 1) manchas pretas se movendo (textura rolando)
        com.larpclient.util.RenderUtil.white();
        mc.getTextureManager().bindTexture(tex);
        GL11.glMatrixMode(GL11.GL_TEXTURE);
        GL11.glPushMatrix();
        GL11.glTranslatef(time * 0.0045f * speed, time * 0.0075f * speed, 0f);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        PlayerModelRenderer.body(m, f, noHead, kor, s15);
        GL11.glMatrixMode(GL11.GL_TEXTURE);
        GL11.glPopMatrix();
        GL11.glMatrixMode(GL11.GL_MODELVIEW);

        // 2) brilho branco pulsante (aditivo) + halo
        GlStateManager.disableTexture2D();
        GlStateManager.blendFunc(770, 1);
        float pulse = 0.5f + 0.5f * (float) Math.sin(time * 0.09f * speed);
        GlStateManager.color(1f, 1f, 1f, 0.12f + 0.10f * pulse);
        PlayerModelRenderer.body(m, f, noHead, kor, s15);
        GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);
        GlStateManager.pushMatrix();
        GlStateManager.translate(0f, 0.75f, 0f);
        GlStateManager.scale(1.07f, 1.04f, 1.07f);
        GlStateManager.translate(0f, -0.75f, 0f);
        GlStateManager.color(0.85f, 0.92f, 1f, 0.06f + 0.05f * pulse);
        PlayerModelRenderer.body(m, f, noHead, kor, s15);
        GlStateManager.popMatrix();

        GlStateManager.enableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        com.larpclient.util.RenderUtil.white();
    }
}
