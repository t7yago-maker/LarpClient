package com.larpclient.cosmetics;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

import java.util.UUID;

/** Pega a skin da conta logada (usada no menu, onde nao existe jogador). */
public final class SkinLoader {
    private static ResourceLocation skin;
    private static ResourceLocation fallback;
    private static boolean slim;
    private static boolean started;

    private SkinLoader() {}

    private static void start() {
        started = true;
        final Minecraft mc = Minecraft.getMinecraft();
        final GameProfile prof = mc.getSession().getProfile();
        UUID id = EntityPlayer.getUUID(prof);
        fallback = DefaultPlayerSkin.getDefaultSkin(id);
        slim = "slim".equals(DefaultPlayerSkin.getSkinType(id));
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final GameProfile filled = mc.getSessionService().fillProfileProperties(prof, true);
                    mc.addScheduledTask(new Runnable() {
                        @Override
                        public void run() {
                            mc.getSkinManager().loadProfileTextures(filled, new net.minecraft.client.resources.SkinManager.SkinAvailableCallback() {
                                @Override
                                public void skinAvailable(MinecraftProfileTexture.Type type, ResourceLocation loc, MinecraftProfileTexture tex) {
                                    if (type == MinecraftProfileTexture.Type.SKIN) {
                                        skin = loc;
                                        slim = "slim".equals(tex.getMetadata("model"));
                                    }
                                }
                            }, false);
                        }
                    });
                } catch (Throwable ignored) {
                }
            }
        }, "LarpClient-Skin");
        t.setDaemon(true);
        t.start();
    }

    public static ResourceLocation getSkin() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) return mc.thePlayer.getLocationSkin();
        if (!started) start();
        return skin != null ? skin : fallback;
    }

    public static boolean isSlim() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null) return "slim".equals(mc.thePlayer.getSkinType());
        if (!started) start();
        return slim;
    }
}
