package com.larpclient.cosmetics;

import com.larpclient.modules.CosmeticModules;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Particulas ao redor da camera, espalhadas pelo mapa todo (vagalumes, brasas, neve, raios...). */
public final class WorldFx {
    private WorldFx() {}

    private static final class P {
        double x, y, z, vx, vy, vz;
        float life, max, size, rot, spin, ph;
        int type, col;
        long seed;
    }

    private static final List<P> L = new ArrayList<P>();
    private static final Random R = new Random();
    private static long last;
    private static float strikeCd;

    private static final int[] BASE = {
            0xFFD8FF5A, 0xFFFF7A1A, 0xFFFFFFFF, 0xFFFFA0C8, 0xFFBFD8FF,
            0xFF7AE0FF, 0xFFB8C8FF, 0xFF35B8FF, 0xFF9FE8FF, 0xFF9A9AA8, 0xFFFFF0A0, 0xFFFF80C0};

    private static int groundY(Minecraft mc, double x, double z) {
        try {
            return mc.theWorld.getHeight(new BlockPos((int) Math.floor(x), 0, (int) Math.floor(z))).getY();
        } catch (Throwable t) {
            return (int) mc.thePlayer.posY;
        }
    }

    private static void spawn(Minecraft mc, int type, double cx, double cy, double cz, float rad, int col) {
        double a = R.nextDouble() * Math.PI * 2.0, d = Math.sqrt(R.nextDouble()) * rad;
        P p = new P();
        p.type = type;
        p.x = cx + Math.cos(a) * d;
        p.z = cz + Math.sin(a) * d;
        p.col = col;
        p.rot = R.nextFloat() * 360f;
        p.spin = (R.nextFloat() - 0.5f) * 180f;
        p.ph = R.nextFloat() * 6.28f;
        p.seed = R.nextLong();
        double g = groundY(mc, p.x, p.z);
        p.max = 6f + R.nextFloat() * 6f;
        switch (type) {
            case 0: p.y = g + 0.5 + R.nextDouble() * 3.0; p.size = 0.07f; break;
            case 1: p.y = g + R.nextDouble() * 1.5; p.vy = 0.8 + R.nextDouble() * 1.2; p.size = 0.05f; p.max = 3f + R.nextFloat() * 3f; break;
            case 2: p.y = cy + 6 + R.nextDouble() * 10; p.vy = -(0.9 + R.nextDouble() * 0.8); p.size = 0.04f; break;
            case 3: p.y = cy + 6 + R.nextDouble() * 10; p.vy = -(0.7 + R.nextDouble() * 0.5); p.size = 0.09f; break;
            case 4: p.y = cy + 14 + R.nextDouble() * 6; p.vy = -(7 + R.nextDouble() * 5); p.vx = 3; p.size = 0.14f; p.max = 3f; break;
            case 5: p.y = g + 1.0 + R.nextDouble() * 5.0; p.size = 0.2f + R.nextFloat() * 0.15f; p.max = 9f + R.nextFloat() * 6f; break;
            case 7: p.y = g + 0.05; p.vy = 0.6 + R.nextDouble() * 0.7; p.size = 0.32f + R.nextFloat() * 0.2f; p.max = 2f + R.nextFloat() * 1.5f; break;
            case 8: p.y = cy + 8 + R.nextDouble() * 10; p.vy = -(14 + R.nextDouble() * 6); p.size = 0.012f; p.max = 1.4f; break;
            case 9: p.y = g + 0.2 + R.nextDouble() * 2; p.vy = 0.3 + R.nextDouble() * 0.3; p.size = 0.35f; p.max = 4f + R.nextFloat() * 3f; break;
            case 10: p.y = g + 1.0 + R.nextDouble() * 9.0; p.size = 0.16f + R.nextFloat() * 0.14f; p.max = 12f + R.nextFloat() * 10f; p.vx = (R.nextDouble() - 0.5) * 2; p.vz = (R.nextDouble() - 0.5) * 2; p.vy = (R.nextDouble() - 0.5); break;
            case 11: p.y = g + 0.5 + R.nextDouble() * 5.0; p.size = 0.05f; p.max = 8f + R.nextFloat() * 6f; p.col = RenderUtil.rainbow(R.nextFloat()); p.vx = (R.nextDouble() - 0.5) * 1.5; p.vz = (R.nextDouble() - 0.5) * 1.5; p.vy = (R.nextDouble() - 0.5) * 0.8; break;
            default: p.y = cy + 5; break;
        }
    }

    private static void glow(float r, int col, float a) {
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        RenderUtil.color(RenderUtil.alpha(col, a));
        GL11.glVertex3f(0f, 0f, 0f);
        RenderUtil.color(RenderUtil.alpha(col, 0f));
        for (int i = 0; i <= 12; i++) {
            double ang = Math.PI * 2.0 * i / 12.0;
            GL11.glVertex3f((float) Math.cos(ang) * r, (float) Math.sin(ang) * r, 0f);
        }
        GL11.glEnd();
    }

    private static void bolt(double x, double top, double y0, double z, long seed, float a, int col) {
        Random r = new Random(seed);
        double cx = x, cz = z;
        int segs = 22;
        double step = (top - y0) / segs;
        for (int pass = 0; pass < 2; pass++) {
            GL11.glLineWidth(pass == 0 ? 5f : 1.6f);
            RenderUtil.color(RenderUtil.alpha(pass == 0 ? col : 0xFFFFFFFF, pass == 0 ? a * 0.45f : a));
            Random rr = new Random(seed);
            cx = x;
            cz = z;
            GL11.glBegin(GL11.GL_LINE_STRIP);
            GL11.glVertex3d(cx, top, cz);
            for (int i = 1; i <= segs; i++) {
                cx += (rr.nextDouble() - 0.5) * 3.2;
                cz += (rr.nextDouble() - 0.5) * 3.2;
                GL11.glVertex3d(cx, top - step * i, cz);
            }
            GL11.glEnd();
        }
    }

    public static void render(float pt, CosmeticModules.WorldEffects m) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) return;
        Entity v = mc.getRenderViewEntity();
        if (v == null) return;
        long nowN = System.nanoTime();
        float dt = last == 0L ? 0.016f : Math.min(0.1f, (nowN - last) / 1.0e9f);
        last = nowN;
        float sp = m.speed.f();
        float rad = m.radius.f();
        double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);

        int enabled = 0;
        for (int i = 0; i < m.on.length; i++) if (m.on[i].b()) enabled++;
        if (enabled == 0) {
            L.clear();
            return;
        }
        int per = Math.max(2, (int) (m.density.num / enabled));
        int[] cnt = new int[m.on.length];
        for (P p : L) cnt[p.type]++;

        // spawn
        for (int ty = 0; ty < m.on.length; ty++) {
            if (!m.on[ty].b() || ty == 6) continue;
            int want = ty == 4 ? Math.max(1, per / 10) : (ty == 7 ? Math.max(2, per / 3) : (ty == 8 ? per * 2 : per));
            int made = 0;
            while (cnt[ty] < want && made < 6) {
                int col = m.tint.b() ? m.color.c() : BASE[ty];
                if (!m.tint.b() && ty == 5) col = RenderUtil.rainbow(R.nextFloat());
                spawn(mc, ty, v.posX, v.posY, v.posZ, rad, col);
                cnt[ty]++;
                made++;
            }
        }
        if (m.on[6].b()) {
            strikeCd -= dt * sp;
            if (strikeCd <= 0f) {
                strikeCd = 0.8f + R.nextFloat() * 2.8f;
                P p = new P();
                p.type = 6;
                double a = R.nextDouble() * Math.PI * 2.0, d = 8 + R.nextDouble() * rad;
                p.x = v.posX + Math.cos(a) * d;
                p.z = v.posZ + Math.sin(a) * d;
                p.y = groundY(mc, p.x, p.z);
                p.max = 0.35f;
                p.seed = R.nextLong();
                p.col = m.tint.b() ? m.color.c() : BASE[6];
                L.add(p);
                if (d < 40) mc.theWorld.playSound(p.x, p.y, p.z, "ambient.weather.thunder", 0.25f, 1.4f + R.nextFloat() * 0.4f, false);
            }
        }

        // atualizar + desenhar
        RenderUtil.begin();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        float vy = mc.getRenderManager().playerViewY, vx = mc.getRenderManager().playerViewX;
        for (int i = L.size() - 1; i >= 0; i--) {
            P p = L.get(i);
            p.life += dt;
            if (!m.on[p.type].b() || p.life > p.max) {
                L.remove(i);
                continue;
            }
            double dx = p.x - v.posX, dz = p.z - v.posZ;
            if (dx * dx + dz * dz > (rad * 1.4) * (rad * 1.4)) {
                L.remove(i);
                continue;
            }
            float k = p.life / p.max;
            float fade = Math.min(1f, Math.min(p.life * 3f, (p.max - p.life) * 2f));
            double s = dt * sp;
            switch (p.type) {
                case 0:
                    p.x += Math.cos(p.ph + p.life * 0.9) * 0.6 * s;
                    p.z += Math.sin(p.ph * 1.3 + p.life * 0.7) * 0.6 * s;
                    p.y += Math.sin(p.ph + p.life * 1.4) * 0.35 * s;
                    fade *= 0.55f + 0.45f * (float) Math.sin(p.life * 3.1 + p.ph);
                    break;
                case 1:
                    p.x += Math.sin(p.life * 2 + p.ph) * 0.4 * s;
                    p.z += Math.cos(p.life * 2.3 + p.ph) * 0.4 * s;
                    p.y += p.vy * s;
                    fade *= 1f - k * 0.6f;
                    break;
                case 2:
                case 3:
                    p.x += Math.sin(p.life * 1.2 + p.ph) * 0.5 * s;
                    p.z += Math.cos(p.life * 0.9 + p.ph) * 0.5 * s;
                    p.y += p.vy * s * 0.6;
                    p.rot += p.spin * dt;
                    break;
                case 4:
                    p.x += p.vx * s;
                    p.y += p.vy * s;
                    break;
                case 5:
                    p.x += Math.sin(p.life * 0.5 + p.ph) * 0.5 * s;
                    p.z += Math.cos(p.life * 0.4 + p.ph) * 0.5 * s;
                    p.y += Math.sin(p.life * 0.8 + p.ph) * 0.4 * s;
                    fade *= 0.7f + 0.3f * (float) Math.sin(p.life * 2 + p.ph);
                    break;
                case 7:
                    p.x += Math.sin(p.life * 3 + p.ph) * 0.3 * s;
                    p.y += p.vy * s;
                    fade *= 1f - k;
                    break;
                case 8:
                    p.y += p.vy * s;
                    break;
                case 9:
                    p.x += Math.sin(p.life + p.ph) * 0.3 * s;
                    p.y += p.vy * s;
                    fade *= 0.4f * (1f - k);
                    break;
                case 10:
                case 11:
                    // voo desengoncado: a velocidade muda aleatoriamente o tempo todo
                    p.vx += (R.nextDouble() - 0.5) * 9.0 * dt;
                    p.vz += (R.nextDouble() - 0.5) * 9.0 * dt;
                    p.vy += (R.nextDouble() - 0.5) * 6.0 * dt;
                    p.vx = Math.max(-2.2, Math.min(2.2, p.vx));
                    p.vz = Math.max(-2.2, Math.min(2.2, p.vz));
                    p.vy = Math.max(-1.1, Math.min(1.1, p.vy));
                    p.x += p.vx * s;
                    p.z += p.vz * s;
                    p.y += p.vy * s;
                    p.rot += p.spin * dt * 2f;
                    fade *= 0.6f + 0.4f * (float) Math.sin(p.life * 5 + p.ph);
                    break;
                default: break;
            }
            if (p.type == 6) {
                GlStateManager.blendFunc(770, 1);
                GlStateManager.pushMatrix();
                GlStateManager.translate(-cx, -cy, -cz);
                float a = (p.life < 0.12f ? 1f : 1f - (p.life - 0.12f) / (p.max - 0.12f)) * (0.6f + 0.4f * (float) Math.sin(p.life * 60f));
                bolt(p.x, p.y + 70, p.y, p.z, p.seed, Math.max(0f, a), p.col);
                GlStateManager.popMatrix();
                continue;
            }
            GlStateManager.pushMatrix();
            GlStateManager.translate(p.x - cx, p.y - cy, p.z - cz);
            if (p.type == 8) {
                GlStateManager.blendFunc(770, 1);
                RenderUtil.color(RenderUtil.alpha(p.col, 0.55f * fade));
                GL11.glLineWidth(1.4f);
                GL11.glBegin(GL11.GL_LINES);
                GL11.glVertex3f(0f, 0f, 0f);
                GL11.glVertex3f(0f, 0.9f, 0f);
                GL11.glEnd();
                GlStateManager.popMatrix();
                continue;
            }
            GlStateManager.rotate(-vy, 0f, 1f, 0f);
            GlStateManager.rotate(vx, 1f, 0f, 0f);
            if (p.type == 3 || p.type == 2) {
                GlStateManager.blendFunc(770, 771);
                GlStateManager.rotate(p.rot, 0f, 0f, 1f);
                float w = p.size;
                RenderUtil.color(RenderUtil.alpha(p.col, 0.9f * fade));
                GL11.glBegin(GL11.GL_TRIANGLES);
                if (p.type == 3) {
                    GL11.glVertex3f(0f, -w, 0f);
                    GL11.glVertex3f(w * 0.7f, 0f, 0f);
                    GL11.glVertex3f(0f, w * 1.2f, 0f);
                    GL11.glVertex3f(0f, -w, 0f);
                    GL11.glVertex3f(-w * 0.7f, 0f, 0f);
                    GL11.glVertex3f(0f, w * 1.2f, 0f);
                } else {
                    for (int q = 0; q < 6; q++) {
                        double a0 = Math.PI * 2.0 * q / 6.0, a1 = Math.PI * 2.0 * (q + 1) / 6.0;
                        GL11.glVertex3f(0f, 0f, 0f);
                        GL11.glVertex3f((float) Math.cos(a0) * w, (float) Math.sin(a0) * w, 0f);
                        GL11.glVertex3f((float) Math.cos(a1) * w, (float) Math.sin(a1) * w, 0f);
                    }
                }
                GL11.glEnd();
            } else if (p.type == 10) {
                GlStateManager.blendFunc(770, 1);
                GlStateManager.rotate(p.rot, 0f, 0f, 1f);
                float w = p.size;
                glow(w * 3.2f, p.col, 0.45f * fade);
                GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                RenderUtil.color(RenderUtil.alpha(0xFFFFFFFF, 0.95f * fade));
                GL11.glVertex3f(0f, 0f, 0f);
                RenderUtil.color(RenderUtil.alpha(p.col, 0.9f * fade));
                for (int q = 0; q <= 8; q++) {
                    double an = Math.PI * 2.0 * q / 8.0;
                    float rr = (q % 2 == 0) ? w : w * 0.28f;
                    GL11.glVertex3f((float) Math.cos(an) * rr, (float) Math.sin(an) * rr, 0f);
                }
                GL11.glEnd();
            } else {
                GlStateManager.blendFunc(770, p.type == 9 ? 771 : 1);
                float r = p.size * (p.type == 7 ? (1f - k * 0.6f) : 1f);
                glow(r * 4f, p.col, 0.5f * fade);
                if (p.type != 9) glow(r * 1.4f, 0xFFFFFFFF, 0.9f * fade);
            }
            GlStateManager.popMatrix();
        }
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        RenderUtil.end();
    }
}
