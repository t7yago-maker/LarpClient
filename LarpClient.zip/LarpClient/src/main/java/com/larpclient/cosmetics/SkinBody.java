package com.larpclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ImageBufferDownload;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.image.BufferedImage;

/**
 * Baixa da internet a skin do nome de usuario ativo (usada no menu inicial, onde nao existe jogador).
 * Tenta Mojang (api + sessionserver); se falhar tenta minotar.net; se tudo falhar o menu usa o Steve/Alex padrao.
 */
public final class SkinBody {
    private SkinBody() {}

    private static volatile ResourceLocation loc;
    private static volatile boolean slim;
    private static boolean started;

    /** null enquanto nao baixou. */
    public static ResourceLocation skin() {
        if (!started) start();
        return loc;
    }

    public static boolean slim() {
        return slim;
    }

    private static void start() {
        started = true;
        final Minecraft mc = Minecraft.getMinecraft();
        final String name = mc.getSession().getUsername();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                BufferedImage img = null;
                boolean sl = false;
                try {
                    com.google.gson.JsonParser jp = new com.google.gson.JsonParser();
                    String id = null;
                    try {
                        id = jp.parse(get("https://api.minecraftservices.com/minecraft/profile/lookup/name/" + name)).getAsJsonObject().get("id").getAsString();
                    } catch (Throwable ignored) {
                    }
                    if (id == null) {
                        id = jp.parse(get("https://api.mojang.com/users/profiles/minecraft/" + name)).getAsJsonObject().get("id").getAsString();
                    }
                    com.google.gson.JsonObject prof = jp.parse(get("https://sessionserver.mojang.com/session/minecraft/profile/" + id)).getAsJsonObject();
                    String val = prof.getAsJsonArray("properties").get(0).getAsJsonObject().get("value").getAsString();
                    com.google.gson.JsonObject skin = jp.parse(new String(java.util.Base64.getDecoder().decode(val), "UTF-8"))
                            .getAsJsonObject().getAsJsonObject("textures").getAsJsonObject("SKIN");
                    img = javax.imageio.ImageIO.read(new java.net.URL(skin.get("url").getAsString()));
                    sl = skin.has("metadata") && "slim".equals(skin.getAsJsonObject("metadata").get("model").getAsString());
                } catch (Throwable ignored) {
                    img = null;
                }
                if (img == null) {
                    try {
                        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("https://minotar.net/skin/" + name).openConnection();
                        c.setConnectTimeout(6000);
                        c.setReadTimeout(8000);
                        c.setRequestProperty("User-Agent", "LarpClient");
                        img = javax.imageio.ImageIO.read(c.getInputStream());
                        if (img != null && img.getHeight() >= 64) sl = ((img.getRGB(54, 20) >>> 24) & 255) == 0;
                    } catch (Throwable ignored) {
                        img = null;
                    }
                }
                if (img == null) return;
                final BufferedImage raw = img;
                final boolean fsl = sl;
                mc.addScheduledTask(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            BufferedImage fin = new ImageBufferDownload().parseUserSkin(raw);
                            ResourceLocation l = mc.getTextureManager().getDynamicTextureLocation("larpmenuskin", new DynamicTexture(fin));
                            slim = fsl;
                            loc = l;
                        } catch (Throwable ignored) {
                        }
                    }
                });
            }
        }, "LarpClient-MenuSkin");
        t.setDaemon(true);
        t.start();
    }

    private static String get(String u) throws java.io.IOException {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "LarpClient");
        java.io.InputStream in = c.getInputStream();
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return new String(o.toByteArray(), "UTF-8");
    }
}
