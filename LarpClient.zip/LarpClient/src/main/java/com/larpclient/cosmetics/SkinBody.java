package com.larpclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.image.BufferedImage;

/**
 * Corpo do jogador desenhado "na mao" (caixas texturizadas com UV da skin). Usado no menu inicial.
 * A skin e baixada da internet pelo nome de usuario ativo; se falhar, usa o Steve padrao.
 */
public final class SkinBody {
    private SkinBody() {}

    private static final ResourceLocation STEVE = new ResourceLocation("textures/entity/steve.png");
    private static ResourceLocation loc = STEVE;
    private static boolean legacy = true, slim, started;
    private static final float D = (float) (180.0 / Math.PI);

    private static void start() {
        started = true;
        final Minecraft mc = Minecraft.getMinecraft();
        final String name = mc.getSession().getUsername();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                BufferedImage img = null;
                boolean sl = false;
                try {
                    com.google.gson.JsonParser jp = new com.google.gson.JsonParser();
                    String id = jp.parse(get("https://api.mojang.com/users/profiles/minecraft/" + name)).getAsJsonObject().get("id").getAsString();
                    com.google.gson.JsonObject prof = jp.parse(get("https://sessionserver.mojang.com/session/minecraft/profile/" + id)).getAsJsonObject();
                    String val = prof.getAsJsonArray("properties").get(0).getAsJsonObject().get("value").getAsString();
                    com.google.gson.JsonObject skin = jp.parse(new String(java.util.Base64.getDecoder().decode(val), "UTF-8"))
                            .getAsJsonObject().getAsJsonObject("textures").getAsJsonObject("SKIN");
                    img = javax.imageio.ImageIO.read(new java.net.URL(skin.get("url").getAsString()));
                    sl = skin.has("metadata") && "slim".equals(skin.getAsJsonObject("metadata").get("model").getAsString());
                } catch (Throwable ignored) {
                }
                if (img == null) return;
                final BufferedImage fin = img;
                final boolean fsl = sl;
                mc.addScheduledTask(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            legacy = fin.getHeight() * 2 <= fin.getWidth();
                            slim = fsl;
                            loc = mc.getTextureManager().getDynamicTextureLocation("larpmenuskin", new DynamicTexture(fin));
                        } catch (Throwable ignored) {
                        }
                    }
                });
            }
        }, "LarpClient-MenuSkin");
        t.setDaemon(true);
        t.start();
    }

    private static String get(String u) throws java.io.IOException {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(8000);
        c.setRequestProperty("User-Agent", "LarpClient");
        java.io.InputStream in = c.getInputStream();
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return new String(o.toByteArray(), "UTF-8");
    }

    private static void v(float x, float y, float z, float u, float vv) {
        GL11.glTexCoord2f(u / 64f, vv / (legacy ? 32f : 64f));
        GL11.glVertex3f(x, y, z);
    }

    /** Caixa no espaco do modelo do Minecraft (pixels, y para baixo, frente em -z). */
    private static void box(float x, float y, float z, float w, float h, float d, float inf, float u, float vv) {
        float X0 = x - inf, X1 = x + w + inf, Y0 = y - inf, Y1 = y + h + inf, Z0 = z - inf, Z1 = z + d + inf;
        float uL = u + d, uR = u + d + w, vT = vv + d, vB = vv + d + h;
        GL11.glBegin(GL11.GL_QUADS);
        // frente (z0)
        v(X0, Y0, Z0, uL, vT); v(X1, Y0, Z0, uR, vT); v(X1, Y1, Z0, uR, vB); v(X0, Y1, Z0, uL, vB);
        // costas (z1)
        float bL = u + 2 * d + w, bR = u + 2 * d + 2 * w;
        v(X1, Y0, Z1, bL, vT); v(X0, Y0, Z1, bR, vT); v(X0, Y1, Z1, bR, vB); v(X1, Y1, Z1, bL, vB);
        // lado x-
        v(X0, Y0, Z0, u + d, vT); v(X0, Y0, Z1, u, vT); v(X0, Y1, Z1, u, vB); v(X0, Y1, Z0, u + d, vB);
        // lado x+
        v(X1, Y0, Z0, u + d + w, vT); v(X1, Y0, Z1, u + 2 * d + w, vT); v(X1, Y1, Z1, u + 2 * d + w, vB); v(X1, Y1, Z0, u + d + w, vB);
        // topo (y0)
        v(X0, Y0, Z0, uL, vv + d); v(X1, Y0, Z0, uR, vv + d); v(X1, Y0, Z1, uR, vv); v(X0, Y0, Z1, uL, vv);
        // base (y1)
        v(X0, Y1, Z0, uR, vv); v(X1, Y1, Z0, uR + w, vv); v(X1, Y1, Z1, uR + w, vv + d); v(X0, Y1, Z1, uR, vv + d);
        GL11.glEnd();
    }

    private static void joint(float px, float py, float pz, net.minecraft.client.model.ModelRenderer r) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(px, py, pz);
        GlStateManager.rotate(r.rotateAngleZ * D, 0f, 0f, 1f);
        GlStateManager.rotate(r.rotateAngleY * D, 0f, 1f, 0f);
        GlStateManager.rotate(r.rotateAngleX * D, 1f, 0f, 0f);
    }

    /** Desenha o corpo inteiro. Ja deve estar na matriz do modelo (escala 0.9375, y para baixo). */
    public static void draw(ModelPlayer m, boolean noHead, boolean kor) {
        Minecraft mc = Minecraft.getMinecraft();
        if (!started) start();
        mc.getTextureManager().bindTexture(loc);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.1f);
        GlStateManager.disableLighting();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.pushMatrix();
        float k = 0.0625f;
        GlStateManager.scale(k, k, k);
        float aw = slim ? 3f : 4f;
        // cabeca
        if (!noHead) {
            joint(0f, 0f, 0f, m.bipedHead);
            box(-4f, -8f, -4f, 8f, 8f, 8f, 0f, 0f, 0f);
            if (!legacy) box(-4f, -8f, -4f, 8f, 8f, 8f, 0.5f, 32f, 0f);
            else box(-4f, -8f, -4f, 8f, 8f, 8f, 0.5f, 32f, 0f);
            GlStateManager.popMatrix();
        }
        // corpo
        box(-4f, 0f, -2f, 8f, 12f, 4f, 0f, 16f, 16f);
        if (!legacy) box(-4f, 0f, -2f, 8f, 12f, 4f, 0.25f, 16f, 32f);
        // braco direito
        joint(-5f, slim ? 2.5f : 2f, 0f, m.bipedRightArm);
        box(slim ? -2f : -3f, slim ? -2.5f : -2f, -2f, aw, 12f, 4f, 0f, 40f, 16f);
        if (!legacy) box(slim ? -2f : -3f, slim ? -2.5f : -2f, -2f, aw, 12f, 4f, 0.25f, 40f, 32f);
        GlStateManager.popMatrix();
        // braco esquerdo
        joint(5f, slim ? 2.5f : 2f, 0f, m.bipedLeftArm);
        box(-1f, slim ? -2.5f : -2f, -2f, aw, 12f, 4f, 0f, legacy ? 40f : 32f, legacy ? 16f : 48f);
        if (!legacy) box(-1f, slim ? -2.5f : -2f, -2f, aw, 12f, 4f, 0.25f, 48f, 48f);
        GlStateManager.popMatrix();
        // pernas
        if (!kor) {
            joint(-1.9f, 12f, 0.1f, m.bipedRightLeg);
            box(-2f, 0f, -2f, 4f, 12f, 4f, 0f, 0f, 16f);
            if (!legacy) box(-2f, 0f, -2f, 4f, 12f, 4f, 0.25f, 0f, 32f);
            GlStateManager.popMatrix();
        }
        joint(1.9f, 12f, 0.1f, m.bipedLeftLeg);
        box(-2f, 0f, -2f, 4f, 12f, 4f, 0f, legacy ? 0f : 16f, legacy ? 16f : 48f);
        if (!legacy) box(-2f, 0f, -2f, 4f, 12f, 4f, 0.25f, 0f, 48f);
        GlStateManager.popMatrix();
        GlStateManager.popMatrix();
    }
}
