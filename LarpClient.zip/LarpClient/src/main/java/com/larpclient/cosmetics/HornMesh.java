package com.larpclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Modelo 3D real das "Frozen Horns of the Frigid Planes" (.obj em assets/larpclient/models/frozen_horns.obj).
 * Se existir assets/larpclient/textures/frozen_horns.png (Handle1Tex.png renomeado) ele e usado com UV;
 * senao as cores vem de um gradiente por altura (metal escuro -> azul cobalto) com sombreamento.
 */
public final class HornMesh {
    private HornMesh() {}

    private static boolean tried;
    private static float[] pos, nrm, uv, col; // por vertice de triangulo: 3,3,2,3
    private static int count;
    private static ResourceLocation tex;

    public static boolean ready() {
        if (!tried) load();
        return count > 0;
    }

    public static boolean textured() {
        return tex != null;
    }

    public static void bind() {
        if (tex != null) Minecraft.getMinecraft().getTextureManager().bindTexture(tex);
    }

    private static void load() {
        tried = true;
        try {
            Minecraft mc = Minecraft.getMinecraft();
            IResource r = mc.getResourceManager().getResource(new ResourceLocation("larpclient", "models/frozen_horns.obj"));
            BufferedReader br = new BufferedReader(new InputStreamReader(r.getInputStream(), "UTF-8"));
            List<float[]> v = new ArrayList<float[]>(), t = new ArrayList<float[]>(), n = new ArrayList<float[]>();
            List<float[]> corners = new ArrayList<float[]>();
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.trim().split("\\s+");
                if (p.length < 3) continue;
                if (p[0].equals("v")) v.add(new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2]), Float.parseFloat(p[3])});
                else if (p[0].equals("vt")) t.add(new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2])});
                else if (p[0].equals("vn")) n.add(new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2]), Float.parseFloat(p[3])});
                else if (p[0].equals("f")) {
                    int k = p.length - 1;
                    float[][] cs = new float[k][];
                    for (int i = 0; i < k; i++) {
                        String[] q = p[i + 1].split("/");
                        float[] vv = v.get(Integer.parseInt(q[0]) - 1);
                        float[] tt = q.length > 1 && q[1].length() > 0 ? t.get(Integer.parseInt(q[1]) - 1) : new float[]{0f, 0f};
                        float[] nn = q.length > 2 && q[2].length() > 0 ? n.get(Integer.parseInt(q[2]) - 1) : new float[]{0f, 1f, 0f};
                        cs[i] = new float[]{vv[0], vv[1], vv[2], nn[0], nn[1], nn[2], tt[0], tt[1]};
                    }
                    for (int i = 1; i < k - 1; i++) {
                        corners.add(cs[0]);
                        corners.add(cs[i]);
                        corners.add(cs[i + 1]);
                    }
                }
            }
            br.close();
            int c = corners.size();
            float[] P = new float[c * 3], N = new float[c * 3], U = new float[c * 2], C = new float[c * 3];
            float lx = -0.4f, ly = 0.7f, lz = 0.6f;
            float ll = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
            lx /= ll; ly /= ll; lz /= ll;
            for (int i = 0; i < c; i++) {
                float[] k = corners.get(i);
                P[i * 3] = k[0]; P[i * 3 + 1] = k[1]; P[i * 3 + 2] = k[2];
                N[i * 3] = k[3]; N[i * 3 + 1] = k[4]; N[i * 3 + 2] = k[5];
                U[i * 2] = k[6]; U[i * 2 + 1] = 1f - k[7];
                float h = Math.max(0f, Math.min(1f, k[1] / 2.467f));
                int cc;
                if (h < 0.30f) cc = com.larpclient.util.RenderUtil.mix(0xFF1B1D23, 0xFF30343C, h / 0.30f);
                else if (h < 0.52f) cc = com.larpclient.util.RenderUtil.mix(0xFF30343C, 0xFF12296A, (h - 0.30f) / 0.22f);
                else if (h < 0.86f) cc = com.larpclient.util.RenderUtil.mix(0xFF12296A, 0xFF2477FF, (h - 0.52f) / 0.34f);
                else cc = com.larpclient.util.RenderUtil.mix(0xFF2477FF, 0xFF8AC8FF, (h - 0.86f) / 0.14f);
                float d = Math.abs(k[3] * lx + k[4] * ly + k[5] * lz);
                float sh = 0.45f + 0.55f * d;
                C[i * 3] = ((cc >> 16) & 255) / 255f * sh;
                C[i * 3 + 1] = ((cc >> 8) & 255) / 255f * sh;
                C[i * 3 + 2] = (cc & 255) / 255f * sh;
            }
            pos = P; nrm = N; uv = U; col = C; count = c;
            try {
                ResourceLocation tl = new ResourceLocation("larpclient", "textures/frozen_horns.png");
                mc.getResourceManager().getResource(tl).getInputStream().close();
                tex = tl;
            } catch (Throwable ignored) {
                tex = null;
            }
        } catch (Throwable e) {
            count = 0;
        }
    }

    /** Desenha o modelo (coordenadas originais do .obj). Depois chama RenderUtil.white() para ressincronizar a cor. */
    public static void draw(float alpha, boolean useTex) {
        if (!ready()) return;
        boolean tx = useTex && tex != null;
        GL11.glBegin(GL11.GL_TRIANGLES);
        for (int i = 0; i < count; i++) {
            if (tx) {
                GL11.glColor4f(1f, 1f, 1f, alpha);
                GL11.glTexCoord2f(uv[i * 2], uv[i * 2 + 1]);
            } else {
                GL11.glColor4f(col[i * 3], col[i * 3 + 1], col[i * 3 + 2], alpha);
            }
            GL11.glVertex3f(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]);
        }
        GL11.glEnd();
        com.larpclient.util.RenderUtil.white();
    }
}
