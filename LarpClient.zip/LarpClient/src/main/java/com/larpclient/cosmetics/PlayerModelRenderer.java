package com.larpclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;

/** Desenha o boneco do jogador em telas (menu e previa de cosmeticos). */
public final class PlayerModelRenderer {
    private static ModelPlayer wide, slim;

    private PlayerModelRenderer() {}

    /**
     * @param x,feetY posicao dos pes na tela (px)
     * @param s       escala (px por bloco)
     * @param yaw     0 = de frente para a tela; -90 = andando para a direita
     */
    public static void draw(float x, float feetY, float s, float yaw, float headYaw, float headPitch,
                            float limbSwing, float limbAmt, float ticks, boolean cosmetics) {
        Minecraft mc = Minecraft.getMinecraft();
        if (wide == null) {
            wide = new ModelPlayer(0f, false);
            slim = new ModelPlayer(0f, true);
        }
        ModelPlayer m = SkinLoader.isSlim() ? slim : wide;
        pose(m, headYaw, headPitch, limbSwing, limbAmt, ticks);

        GlStateManager.pushMatrix();
        GlStateManager.enableDepth();
        GlStateManager.clear(256);
        GlStateManager.enableColorMaterial();
        GlStateManager.translate(x, feetY, 100f);
        GlStateManager.scale(-s, s, s);
        GlStateManager.rotate(180f, 0f, 0f, 1f);

        if (cosmetics) CosmeticRenderer.renderAura(ticks, true);

        GlStateManager.disableLighting();
        GlStateManager.rotate(180f - yaw, 0f, 1f, 0f);
        GlStateManager.scale(-1f, -1f, 1f);
        GlStateManager.scale(0.9375f, 0.9375f, 0.9375f);
        GlStateManager.translate(0f, -1.5078125f, 0f);
        GlStateManager.enableRescaleNormal();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.enableAlpha();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
        mc.getTextureManager().bindTexture(SkinLoader.getSkin());

        float f = 0.0625f;
        com.larpclient.modules.CosmeticModules.Avatar av = com.larpclient.core.ModuleManager.get(com.larpclient.modules.CosmeticModules.Avatar.class);
        boolean noHead = cosmetics && av != null && av.enabled && av.headless.b();
        boolean kor = cosmetics && av != null && av.enabled && av.korblox.b();
        boolean thin = cosmetics && av != null && av.enabled && av.skinny.b();
        if (thin) GlStateManager.scale(av.thin.f(), 1f, 0.5f + av.thin.f() * 0.5f);
        if (!noHead) m.bipedHead.render(f);
        m.bipedBody.render(f);
        m.bipedRightArm.render(f);
        m.bipedLeftArm.render(f);
        if (!kor) m.bipedRightLeg.render(f);
        m.bipedLeftLeg.render(f);
        if (!noHead) m.bipedHeadwear.render(f);
        m.bipedBodyWear.render(f);
        m.bipedRightArmwear.render(f);
        m.bipedLeftArmwear.render(f);
        if (!kor) m.bipedRightLegwear.render(f);
        m.bipedLeftLegwear.render(f);
        if (thin) GlStateManager.scale(1f / av.thin.f(), 1f, 1f / (0.5f + av.thin.f() * 0.5f));
        RenderHelper.disableStandardItemLighting();

        if (cosmetics) {
            CosmeticRenderer.Ctx c = new CosmeticRenderer.Ctx();
            c.time = ticks;
            c.headYaw = headYaw;
            c.headPitch = headPitch;
            c.capeA = 8f + (float) Math.sin(ticks * 0.08f) * 3f + limbAmt * 18f;
            c.capeB = (float) Math.sin(ticks * 0.05f) * 2f;
            c.hasLeg = kor;
            c.legX = m.bipedRightLeg.rotationPointX;
            c.legY = m.bipedRightLeg.rotationPointY;
            c.legZ = m.bipedRightLeg.rotationPointZ;
            c.legAng = m.bipedRightLeg.rotateAngleX;
            CosmeticRenderer.renderModel(c);
        }

        GlStateManager.disableRescaleNormal();
        GlStateManager.disableDepth();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static void pose(ModelPlayer m, float headYaw, float headPitch, float ls, float la, float t) {
        float d = (float) (Math.PI / 180.0);
        m.bipedHead.rotateAngleY = headYaw * d;
        m.bipedHead.rotateAngleX = headPitch * d;
        m.bipedHead.rotateAngleZ = 0f;
        m.bipedHead.rotationPointY = 0f;
        m.bipedBody.rotateAngleX = 0f;
        m.bipedBody.rotateAngleY = 0f;
        m.bipedBody.rotateAngleZ = 0f;
        float c = ls * 0.6662f;
        m.bipedRightArm.rotateAngleX = (float) Math.cos(c + Math.PI) * 2f * la * 0.5f;
        m.bipedLeftArm.rotateAngleX = (float) Math.cos(c) * 2f * la * 0.5f;
        m.bipedRightArm.rotateAngleY = 0f;
        m.bipedLeftArm.rotateAngleY = 0f;
        m.bipedRightArm.rotateAngleZ = 0f;
        m.bipedLeftArm.rotateAngleZ = 0f;
        m.bipedRightLeg.rotateAngleX = (float) Math.cos(c) * 1.4f * la;
        m.bipedLeftLeg.rotateAngleX = (float) Math.cos(c + Math.PI) * 1.4f * la;
        m.bipedRightLeg.rotateAngleY = 0f;
        m.bipedLeftLeg.rotateAngleY = 0f;
        m.bipedRightLeg.rotateAngleZ = 0f;
        m.bipedLeftLeg.rotateAngleZ = 0f;
        m.bipedRightArm.rotateAngleZ += (float) Math.cos(t * 0.09f) * 0.05f + 0.05f;
        m.bipedLeftArm.rotateAngleZ -= (float) Math.cos(t * 0.09f) * 0.05f + 0.05f;
        m.bipedRightArm.rotateAngleX += (float) Math.sin(t * 0.067f) * 0.05f;
        m.bipedLeftArm.rotateAngleX -= (float) Math.sin(t * 0.067f) * 0.05f;
        m.bipedRightArm.rotationPointX = -5f;
        m.bipedRightArm.rotationPointZ = 0f;
        m.bipedLeftArm.rotationPointX = 5f;
        m.bipedLeftArm.rotationPointZ = 0f;
        m.bipedRightLeg.rotationPointY = 12f;
        m.bipedLeftLeg.rotationPointY = 12f;
        m.bipedRightLeg.rotationPointZ = 0.1f;
        m.bipedLeftLeg.rotationPointZ = 0.1f;
        ModelBase.copyModelAngles(m.bipedHead, m.bipedHeadwear);
        ModelBase.copyModelAngles(m.bipedBody, m.bipedBodyWear);
        ModelBase.copyModelAngles(m.bipedLeftArm, m.bipedLeftArmwear);
        ModelBase.copyModelAngles(m.bipedRightArm, m.bipedRightArmwear);
        ModelBase.copyModelAngles(m.bipedLeftLeg, m.bipedLeftLegwear);
        ModelBase.copyModelAngles(m.bipedRightLeg, m.bipedRightLegwear);
    }
}
