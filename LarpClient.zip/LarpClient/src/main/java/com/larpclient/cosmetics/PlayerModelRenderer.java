package com.larpclient.cosmetics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;

/** Desenha o boneco do jogador em telas (menu e previa de cosmeticos). */
public final class PlayerModelRenderer {
    private static ModelPlayer wide, slim;

    private PlayerModelRenderer() {}

    /**
     * @param x,feetY posicao dos pes na tela (px)
     * @param s       escala (px por bloco)
     * @param yaw     0 = de frente para a tela; -90 = andando para a direita
     */
    public static void draw(float x, float feetY, float s, float yaw, float headYaw, float headPitch,
                            float limbSwing, float limbAmt, float ticks, boolean cosmetics) {
        Minecraft mc = Minecraft.getMinecraft();
        if (wide == null) {
            wide = new ModelPlayer(0f, false);
            slim = new ModelPlayer(0f, true);
        }
        net.minecraft.util.ResourceLocation tex;
        boolean sl;
        net.minecraft.util.ResourceLocation web = mc.thePlayer == null ? SkinBody.skin() : null;
        if (web != null) {
            tex = web;
            sl = SkinBody.slim();
        } else {
            tex = SkinLoader.getSkin();
            sl = SkinLoader.isSlim();
        }
        ModelPlayer m = sl ? slim : wide;
        com.larpclient.util.RenderUtil.white();
        com.larpclient.modules.CosmeticModules.Avatar av0 = com.larpclient.core.ModuleManager.get(com.larpclient.modules.CosmeticModules.Avatar.class);
        boolean avOn = cosmetics && av0 != null && av0.enabled;
        boolean zombie = avOn && av0.anim.index == 1;
        boolean s15 = avOn && av0.s15.b();
        pose(m, headYaw, headPitch, limbSwing, limbAmt, ticks, zombie);

        GlStateManager.pushMatrix();
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.clear(256);
        GlStateManager.enableColorMaterial();
        GlStateManager.translate(x, feetY, 100f);
        GlStateManager.scale(-s, s, s);
        GlStateManager.rotate(180f, 0f, 0f, 1f);

        if (cosmetics) CosmeticRenderer.renderAura(ticks, true);

        GlStateManager.disableLighting();
        GlStateManager.rotate(180f - yaw, 0f, 1f, 0f);
        GlStateManager.scale(-1f, -1f, 1f);
        GlStateManager.scale(0.9375f, 0.9375f, 0.9375f);
        GlStateManager.translate(0f, -1.5078125f, 0f);
        GlStateManager.enableRescaleNormal();
        GlStateManager.disableCull();
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.1f);
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        com.larpclient.util.RenderUtil.white();
        mc.getTextureManager().bindTexture(tex);

        float f = 0.0625f;
        com.larpclient.modules.CosmeticModules.Avatar av = com.larpclient.core.ModuleManager.get(com.larpclient.modules.CosmeticModules.Avatar.class);
        boolean noHead = cosmetics && av != null && av.enabled && av.headless.b();
        boolean kor = cosmetics && av != null && av.enabled && av.korblox.b();
        boolean thin = cosmetics && av != null && av.enabled && av.skinny.b();
        if (thin && !s15) GlStateManager.scale(av.thin.f(), 1f, 0.5f + av.thin.f() * 0.5f);
        if (s15) GlStateManager.translate(0f, -S15_RAISE * f, 0f);
        body(m, f, noHead, kor, s15);
        if (avOn && av.spots.b()) SpotFx.draw(m, noHead, kor, s15, ticks, av.spotSpeed.f());
        if (thin && !s15) GlStateManager.scale(1f / av.thin.f(), 1f, 1f / (0.5f + av.thin.f() * 0.5f));
        RenderHelper.disableStandardItemLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        if (cosmetics) {
            CosmeticRenderer.Ctx c = new CosmeticRenderer.Ctx();
            c.time = ticks;
            c.headYaw = headYaw;
            c.headPitch = headPitch;
            c.capeA = 8f + (float) Math.sin(ticks * 0.08f) * 3f + limbAmt * 18f;
            c.capeB = (float) Math.sin(ticks * 0.05f) * 2f;
            c.hasLeg = kor;
            c.legX = m.bipedRightLeg.rotationPointX;
            c.legY = m.bipedRightLeg.rotationPointY;
            c.legZ = m.bipedRightLeg.rotationPointZ;
            c.legAng = m.bipedRightLeg.rotateAngleX;
            c.menu = true;
            c.trailZ = limbAmt * 1.7f;
            if (s15) {
                c.legSx = 0.72f;
                c.legSy = 1.12f;
                c.headScale = 1.12f;
            }
            CosmeticRenderer.renderModel(c);
        }

        GlStateManager.disableRescaleNormal();
        GlStateManager.disableDepth();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
        com.larpclient.util.RenderUtil.white();
    }

    static final float S15_RAISE = 1.44f;

    static void body(ModelPlayer m, float f, boolean noHead, boolean kor, boolean s15) {
        if (s15) partsS15(m, f, noHead, kor);
        else parts(m, f, noHead, kor);
    }

    /** Desenha a parte escalando no eixo local do membro (depois da rotacao). */
    private static void partLocal(net.minecraft.client.model.ModelRenderer r, float f, float sx, float sy, float sz, float dx) {
        float rx = r.rotateAngleX, ry = r.rotateAngleY, rz = r.rotateAngleZ;
        float px = r.rotationPointX, py = r.rotationPointY, pz = r.rotationPointZ;
        GlStateManager.pushMatrix();
        GlStateManager.translate((px + dx) * f, py * f, pz * f);
        if (rz != 0f) GlStateManager.rotate(rz * 57.29578f, 0f, 0f, 1f);
        if (ry != 0f) GlStateManager.rotate(ry * 57.29578f, 0f, 1f, 0f);
        if (rx != 0f) GlStateManager.rotate(rx * 57.29578f, 1f, 0f, 0f);
        GlStateManager.scale(sx, sy, sz);
        r.rotateAngleX = 0f;
        r.rotateAngleY = 0f;
        r.rotateAngleZ = 0f;
        r.rotationPointX = 0f;
        r.rotationPointY = 0f;
        r.rotationPointZ = 0f;
        r.render(f);
        r.rotateAngleX = rx;
        r.rotateAngleY = ry;
        r.rotateAngleZ = rz;
        r.rotationPointX = px;
        r.rotationPointY = py;
        r.rotationPointZ = pz;
        GlStateManager.popMatrix();
    }

    /** Corpo S15 (Roblox slim): cabeca maior, tronco fino, bracos e pernas finos e longos. */
    private static void partsS15(ModelPlayer m, float f, boolean noHead, boolean kor) {
        float hs = 1.12f;
        if (!noHead) {
            partLocal(m.bipedHead, f, hs, hs, hs, 0f);
            partLocal(m.bipedHeadwear, f, hs, hs, hs, 0f);
        }
        partLocal(m.bipedBody, f, 0.82f, 1f, 0.72f, 0f);
        partLocal(m.bipedBodyWear, f, 0.82f, 1f, 0.72f, 0f);
        partLocal(m.bipedRightArm, f, 0.58f, 1.1f, 0.62f, 1.0f);
        partLocal(m.bipedLeftArm, f, 0.58f, 1.1f, 0.62f, -1.0f);
        partLocal(m.bipedRightArmwear, f, 0.58f, 1.1f, 0.62f, 1.0f);
        partLocal(m.bipedLeftArmwear, f, 0.58f, 1.1f, 0.62f, -1.0f);
        if (!kor) {
            partLocal(m.bipedRightLeg, f, 0.72f, 1.12f, 0.72f, 0f);
            partLocal(m.bipedRightLegwear, f, 0.72f, 1.12f, 0.72f, 0f);
        }
        partLocal(m.bipedLeftLeg, f, 0.72f, 1.12f, 0.72f, 0f);
        partLocal(m.bipedLeftLegwear, f, 0.72f, 1.12f, 0.72f, 0f);
    }

    private static void parts(ModelPlayer m, float f, boolean noHead, boolean kor) {
        if (!noHead) m.bipedHead.render(f);
        m.bipedBody.render(f);
        m.bipedRightArm.render(f);
        m.bipedLeftArm.render(f);
        if (!kor) m.bipedRightLeg.render(f);
        m.bipedLeftLeg.render(f);
        if (!noHead) m.bipedHeadwear.render(f);
        m.bipedBodyWear.render(f);
        m.bipedRightArmwear.render(f);
        m.bipedLeftArmwear.render(f);
        if (!kor) m.bipedRightLegwear.render(f);
        m.bipedLeftLegwear.render(f);
    }

    private static void pose(ModelPlayer m, float headYaw, float headPitch, float ls, float la, float t, boolean zombie) {
        float d = (float) (Math.PI / 180.0);
        m.bipedHead.rotateAngleY = headYaw * d;
        m.bipedHead.rotateAngleX = headPitch * d;
        m.bipedHead.rotateAngleZ = 0f;
        m.bipedHead.rotationPointY = 0f;
        m.bipedBody.rotateAngleX = 0f;
        m.bipedBody.rotateAngleY = 0f;
        m.bipedBody.rotateAngleZ = 0f;
        float c = ls * 0.6662f;
        m.bipedRightArm.rotateAngleX = (float) Math.cos(c + Math.PI) * 2f * la * 0.5f;
        m.bipedLeftArm.rotateAngleX = (float) Math.cos(c) * 2f * la * 0.5f;
        m.bipedRightArm.rotateAngleY = 0f;
        m.bipedLeftArm.rotateAngleY = 0f;
        m.bipedRightArm.rotateAngleZ = 0f;
        m.bipedLeftArm.rotateAngleZ = 0f;
        m.bipedRightLeg.rotateAngleX = (float) Math.cos(c) * 1.4f * la;
        m.bipedLeftLeg.rotateAngleX = (float) Math.cos(c + Math.PI) * 1.4f * la;
        m.bipedRightLeg.rotateAngleY = 0f;
        m.bipedLeftLeg.rotateAngleY = 0f;
        m.bipedRightLeg.rotateAngleZ = 0f;
        m.bipedLeftLeg.rotateAngleZ = 0f;
        m.bipedRightArm.rotateAngleZ += (float) Math.cos(t * 0.09f) * 0.05f + 0.05f;
        m.bipedLeftArm.rotateAngleZ -= (float) Math.cos(t * 0.09f) * 0.05f + 0.05f;
        m.bipedRightArm.rotateAngleX += (float) Math.sin(t * 0.067f) * 0.05f;
        m.bipedLeftArm.rotateAngleX -= (float) Math.sin(t * 0.067f) * 0.05f;
        if (zombie) {
            float sw = (float) Math.sin(t * 0.067f) * 0.05f;
            m.bipedRightArm.rotateAngleX = -1.5708f + sw;
            m.bipedLeftArm.rotateAngleX = -1.5708f - sw;
            m.bipedRightArm.rotateAngleY = 0f;
            m.bipedLeftArm.rotateAngleY = 0f;
            m.bipedRightArm.rotateAngleZ = 0.02f;
            m.bipedLeftArm.rotateAngleZ = -0.02f;
        }
        m.bipedRightArm.rotationPointX = -5f;
        m.bipedRightArm.rotationPointZ = 0f;
        m.bipedLeftArm.rotationPointX = 5f;
        m.bipedLeftArm.rotationPointZ = 0f;
        m.bipedRightLeg.rotationPointY = 12f;
        m.bipedLeftLeg.rotationPointY = 12f;
        m.bipedRightLeg.rotationPointZ = 0.1f;
        m.bipedLeftLeg.rotationPointZ = 0.1f;
        ModelBase.copyModelAngles(m.bipedHead, m.bipedHeadwear);
        ModelBase.copyModelAngles(m.bipedBody, m.bipedBodyWear);
        ModelBase.copyModelAngles(m.bipedLeftArm, m.bipedLeftArmwear);
        ModelBase.copyModelAngles(m.bipedRightArm, m.bipedRightArmwear);
        ModelBase.copyModelAngles(m.bipedLeftLeg, m.bipedLeftLegwear);
        ModelBase.copyModelAngles(m.bipedRightLeg, m.bipedRightLegwear);
    }
}
