package com.larpclient.cosmetics;

/** Poses de bracos (animacoes do avatar). side: +1 braco direito, -1 braco esquerdo. */
public final class ArmAnim {
    private ArmAnim() {}

    public static final String[] NAMES = {"Normal", "Zumbi", "T-Pose", "Asas (bater)", "Superman", "Bracos pra cima", "Robo"};

    /** out = {rotX, rotY, rotZ} (radianos, convencao do ModelRenderer). */
    public static void pose(int anim, float t, int side, float[] out) {
        float x = 0f, y = 0f, z = 0f;
        float sw = (float) Math.sin(t * 0.067f) * 0.04f;
        switch (anim) {
            case 1: // zumbi: bracos retos para frente
                x = -1.5708f + sw * side;
                z = 0.015f * side;
                break;
            case 2: // T-pose
                z = 1.5708f * side;
                break;
            case 3: // asas batendo
                z = (0.95f + 0.65f * (float) Math.sin(t * 0.38f)) * side;
                break;
            case 4: // superman
                x = -2.65f + sw;
                z = 0.05f * side;
                break;
            case 5: // bracos para cima acenando
                z = (2.75f + 0.18f * (float) Math.sin(t * 0.3f + (side > 0 ? 0f : 1.6f))) * side;
                x = -0.1f;
                break;
            case 6: // robo (alterna)
                x = -1.25f + 0.55f * (float) Math.sin(t * 0.25f) * side;
                z = 0.05f * side;
                break;
            default:
                break;
        }
        out[0] = x;
        out[1] = y;
        out[2] = z;
    }

    /** Desenha os bracos (e mangas) do modelo ja posicionado com a pose da animacao. */
    public static void drawArms(net.minecraft.client.model.ModelPlayer m, float f, int anim, float t) {
        net.minecraft.client.model.ModelRenderer[] r = {m.bipedRightArm, m.bipedRightArmwear, m.bipedLeftArm, m.bipedLeftArmwear};
        float[] o = new float[3];
        for (int i = 0; i < 4; i++) {
            net.minecraft.client.model.ModelRenderer a = r[i];
            float rx = a.rotateAngleX, ry = a.rotateAngleY, rz = a.rotateAngleZ;
            pose(anim, t, i < 2 ? 1 : -1, o);
            a.rotateAngleX = o[0];
            a.rotateAngleY = o[1];
            a.rotateAngleZ = o[2];
            a.render(f);
            a.rotateAngleX = rx;
            a.rotateAngleY = ry;
            a.rotateAngleZ = rz;
        }
    }
}
