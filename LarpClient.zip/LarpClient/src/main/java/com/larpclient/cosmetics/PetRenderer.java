package com.larpclient.cosmetics;

import com.larpclient.modules.CosmeticModules;
import com.larpclient.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

/** Bichos de estimacao 3D (voxel) que seguem voce. So aparecem no seu cliente. */
public final class PetRenderer {
    private PetRenderer() {}

    private static double px, py, pz;
    private static float yaw, walk, speedSm, hop;
    private static boolean init;
    private static long last;

    private static void leg(float x, float z, float ang, float len, float w, int col, int foot) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, len, z);
        GlStateManager.rotate(ang, 1f, 0f, 0f);
        Vox.box(-w, -len, -w, w, 0f, w, col);
        Vox.box(-w - 0.005f, -len, -w, w + 0.005f, -len + 0.05f, w + 0.03f, foot);
        GlStateManager.popMatrix();
    }

    public static void render(float pt, CosmeticModules.Pets m) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer p = mc.thePlayer;
        if (p == null || mc.theWorld == null) return;
        if (mc.gameSettings.thirdPersonView == 0 && false) return;
        long nowN = System.nanoTime();
        float dt = last == 0L ? 0.016f : Math.min(0.1f, (nowN - last) / 1.0e9f);
        last = nowN;
        double ox = p.lastTickPosX + (p.posX - p.lastTickPosX) * pt;
        double oy = p.lastTickPosY + (p.posY - p.lastTickPosY) * pt;
        double oz = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * pt;
        float pyaw = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
        double a = Math.toRadians(pyaw);
        double dist = m.distance.num;
        double tx = ox + Math.sin(a) * dist + Math.cos(a) * -dist * 0.8;
        double tz = oz - Math.cos(a) * dist + Math.sin(a) * -dist * 0.8;
        boolean fly = m.style.index == 2 || m.style.index == 5 || m.style.index == 7;
        double ty = oy;
        if (!init || Math.abs(px - ox) > 24 || Math.abs(pz - oz) > 24) {
            px = tx;
            py = ty;
            pz = tz;
            init = true;
        }
        double dx = tx - px, dz = tz - pz;
        double d = Math.sqrt(dx * dx + dz * dz);
        double follow = Math.min(1.0, dt * (d > 3 ? 6.0 : 3.0));
        double nx = px + dx * follow, nz = pz + dz * follow;
        double moved = Math.sqrt((nx - px) * (nx - px) + (nz - pz) * (nz - pz)) / Math.max(dt, 0.001f);
        if (d > 0.35) {
            float want = (float) Math.toDegrees(Math.atan2(nx - px, nz - pz));
            float diff = net.minecraft.util.MathHelper.wrapAngleTo180_float(want - yaw);
            yaw += diff * Math.min(1f, dt * 10f);
        } else {
            float want = (float) Math.toDegrees(Math.atan2(ox - px, oz - pz));
            float diff = net.minecraft.util.MathHelper.wrapAngleTo180_float(want - yaw);
            yaw += diff * Math.min(1f, dt * 4f);
        }
        px = nx;
        pz = nz;
        py += (ty - py) * Math.min(1.0, dt * 8.0);
        speedSm += ((float) Math.min(moved, 6.0) - speedSm) * Math.min(1f, dt * 8f);
        walk += speedSm * dt * 5f;
        float t = (nowN / 1.0e9f);

        double cx = RenderUtil.camX(pt), cy = RenderUtil.camY(pt), cz = RenderUtil.camZ(pt);
        GlStateManager.pushMatrix();
        float s = m.size.f();
        float hover = fly ? 0.9f + (float) Math.sin(t * 2f) * 0.12f : 0f;
        GlStateManager.translate(px - cx, py - cy + hover, pz - cz);
        GlStateManager.rotate(yaw, 0f, 1f, 0f);
        GlStateManager.scale(s, s, s);
        RenderUtil.begin();
        GlStateManager.disableCull();
        GlStateManager.enableDepth();
        int tint = m.useColor.b() ? m.color.c() : 0;
        draw(m.style.index, t, speedSm, tint);
        GlStateManager.enableCull();
        RenderUtil.end();
        GlStateManager.popMatrix();
        if (m.nameTag.b()) {
            RenderUtil.worldText(m.style.m(), px - cx, py - cy + hover + 0.95 * s, pz - cz, 0.018f, 0xFFFFFFFF);
        }
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    private static int col(int def, int tint) {
        return tint == 0 ? def : tint;
    }

    private static void draw(int st, float t, float sp, int tint) {
        float sw = (float) Math.sin(walk) * Math.min(1f, sp) * 40f;
        float idle = (float) Math.sin(t * 2.3f);
        switch (st) {
            case 0: { // Wolf
                int c = col(0xFFB9BDC4, tint), d = 0xFF8C9098;
                GlStateManager.translate(0, (float) Math.abs(Math.sin(walk * 2f)) * 0.02f * Math.min(1f, sp), 0);
                Vox.box(-0.15f, 0.3f, -0.32f, 0.15f, 0.55f, 0.28f, c);
                Vox.box(-0.14f, 0.38f, 0.26f, 0.14f, 0.64f, 0.5f, c);
                Vox.box(-0.08f, 0.38f, 0.5f, 0.08f, 0.5f, 0.66f, d);
                Vox.box(-0.03f, 0.46f, 0.64f, 0.03f, 0.5f, 0.68f, 0xFF101010);
                Vox.box(-0.14f, 0.64f, 0.34f, -0.08f, 0.74f, 0.4f, d);
                Vox.box(0.08f, 0.64f, 0.34f, 0.14f, 0.74f, 0.4f, d);
                Vox.box(-0.1f, 0.5f, 0.44f, -0.07f, 0.56f, 0.47f, 0xFF101010);
                Vox.box(0.07f, 0.5f, 0.44f, 0.1f, 0.56f, 0.47f, 0xFF101010);
                GlStateManager.pushMatrix();
                GlStateManager.translate(0, 0.5f, -0.3f);
                GlStateManager.rotate(-30f + idle * 14f + sw * 0.3f, 1f, 0f, 0f);
                Vox.box(-0.04f, -0.02f, -0.3f, 0.04f, 0.04f, 0f, c);
                GlStateManager.popMatrix();
                leg(-0.09f, 0.2f, sw, 0.3f, 0.05f, c, d);
                leg(0.09f, 0.2f, -sw, 0.3f, 0.05f, c, d);
                leg(-0.09f, -0.25f, -sw, 0.3f, 0.05f, c, d);
                leg(0.09f, -0.25f, sw, 0.3f, 0.05f, c, d);
                break;
            }
            case 1: { // Cat
                int c = col(0xFFE8943A, tint), w = 0xFFFFF0DC;
                Vox.box(-0.1f, 0.2f, -0.22f, 0.1f, 0.38f, 0.18f, c);
                Vox.box(-0.1f, 0.26f, 0.16f, 0.1f, 0.46f, 0.34f, c);
                Vox.box(-0.06f, 0.28f, 0.33f, 0.06f, 0.36f, 0.38f, w);
                Vox.box(-0.1f, 0.46f, 0.2f, -0.05f, 0.54f, 0.25f, c);
                Vox.box(0.05f, 0.46f, 0.2f, 0.1f, 0.54f, 0.25f, c);
                Vox.box(-0.07f, 0.34f, 0.34f, -0.04f, 0.4f, 0.36f, 0xFF40D060);
                Vox.box(0.04f, 0.34f, 0.34f, 0.07f, 0.4f, 0.36f, 0xFF40D060);
                GlStateManager.pushMatrix();
                GlStateManager.translate(0, 0.34f, -0.22f);
                GlStateManager.rotate(-50f + idle * 20f, 1f, 0f, 0f);
                GlStateManager.rotate(idle * 15f, 0f, 1f, 0f);
                Vox.box(-0.025f, -0.02f, -0.34f, 0.025f, 0.03f, 0f, c);
                GlStateManager.popMatrix();
                leg(-0.06f, 0.12f, sw, 0.2f, 0.035f, c, w);
                leg(0.06f, 0.12f, -sw, 0.2f, 0.035f, c, w);
                leg(-0.06f, -0.17f, -sw, 0.2f, 0.035f, c, w);
                leg(0.06f, -0.17f, sw, 0.2f, 0.035f, c, w);
                break;
            }
            case 2: { // Baby dragon (voa)
                int c = col(0xFF8A3FE0, tint), d = 0xFF5B1FA8, b = 0xFFE8D0FF;
                float fl = (float) Math.sin(t * 9f) * 30f;
                Vox.box(-0.14f, -0.12f, -0.25f, 0.14f, 0.16f, 0.2f, c);
                Vox.box(-0.12f, -0.12f, -0.22f, 0.12f, -0.04f, 0.18f, b);
                Vox.box(-0.12f, 0.1f, 0.18f, 0.12f, 0.34f, 0.42f, c);
                Vox.box(-0.07f, 0.12f, 0.42f, 0.07f, 0.24f, 0.54f, d);
                Vox.box(-0.1f, 0.34f, 0.24f, -0.06f, 0.46f, 0.28f, 0xFFFFE04A);
                Vox.box(0.06f, 0.34f, 0.24f, 0.1f, 0.46f, 0.28f, 0xFFFFE04A);
                Vox.box(-0.09f, 0.2f, 0.4f, -0.05f, 0.26f, 0.43f, 0xFFFFE04A);
                Vox.box(0.05f, 0.2f, 0.4f, 0.09f, 0.26f, 0.43f, 0xFFFFE04A);
                Vox.box(-0.12f, 0.2f, -0.35f, 0.12f, 0.1f, -0.25f, d);
                GlStateManager.pushMatrix();
                GlStateManager.translate(0, 0.02f, -0.25f);
                GlStateManager.rotate(idle * 15f, 0f, 1f, 0f);
                Vox.box(-0.06f, -0.05f, -0.3f, 0.06f, 0.05f, 0f, c);
                Vox.box(-0.04f, -0.04f, -0.5f, 0.04f, 0.04f, -0.3f, d);
                Vox.box(-0.03f, 0f, -0.58f, 0.03f, 0.1f, -0.48f, 0xFFFF6030);
                GlStateManager.popMatrix();
                for (int s = -1; s <= 1; s += 2) {
                    GlStateManager.pushMatrix();
                    GlStateManager.translate(s * 0.14f, 0.12f, 0f);
                    GlStateManager.rotate(s * (fl + 10f), 0f, 0f, 1f);
                    Vox.box(s > 0 ? 0f : -0.6f, -0.015f, -0.15f, s > 0 ? 0.6f : 0f, 0.015f, 0.12f, d);
                    Vox.box(s > 0 ? 0.25f : -0.6f, -0.015f, -0.3f, s > 0 ? 0.6f : -0.25f, 0.015f, -0.15f, c);
                    GlStateManager.popMatrix();
                }
                break;
            }
            case 3: { // Fox
                int c = col(0xFFE8702A, tint), w = 0xFFFFFFFF, dk = 0xFF3A2410;
                Vox.box(-0.11f, 0.24f, -0.26f, 0.11f, 0.42f, 0.2f, c);
                Vox.box(-0.1f, 0.3f, 0.18f, 0.1f, 0.5f, 0.36f, c);
                Vox.box(-0.06f, 0.3f, 0.35f, 0.06f, 0.4f, 0.5f, w);
                Vox.box(-0.02f, 0.38f, 0.49f, 0.02f, 0.41f, 0.52f, dk);
                Vox.box(-0.1f, 0.5f, 0.22f, -0.04f, 0.62f, 0.27f, c);
                Vox.box(0.04f, 0.5f, 0.22f, 0.1f, 0.62f, 0.27f, c);
                Vox.box(-0.1f, 0.5f, 0.22f, -0.04f, 0.54f, 0.27f, dk);
                Vox.box(0.04f, 0.5f, 0.22f, 0.1f, 0.54f, 0.27f, dk);
                GlStateManager.pushMatrix();
                GlStateManager.translate(0, 0.34f, -0.26f);
                GlStateManager.rotate(-25f + idle * 12f, 1f, 0f, 0f);
                Vox.box(-0.06f, -0.06f, -0.38f, 0.06f, 0.06f, 0f, c);
                Vox.box(-0.065f, -0.065f, -0.48f, 0.065f, 0.065f, -0.34f, w);
                GlStateManager.popMatrix();
                leg(-0.06f, 0.14f, sw, 0.24f, 0.04f, dk, dk);
                leg(0.06f, 0.14f, -sw, 0.24f, 0.04f, dk, dk);
                leg(-0.06f, -0.2f, -sw, 0.24f, 0.04f, dk, dk);
                leg(0.06f, -0.2f, sw, 0.24f, 0.04f, dk, dk);
                break;
            }
            case 4: { // Slime
                float sq = 1f + (float) Math.sin(t * 5f) * 0.12f;
                GlStateManager.translate(0, (float) Math.abs(Math.sin(t * 2.5f)) * 0.12f, 0);
                GlStateManager.scale(1f / sq, sq, 1f / sq);
                int c = col(0xFF55D84A, tint);
                Vox.box(-0.18f, 0f, -0.18f, 0.18f, 0.36f, 0.18f, RenderUtil.alpha(c, 0.55f));
                Vox.box(-0.1f, 0.06f, -0.1f, 0.1f, 0.24f, 0.1f, RenderUtil.shade(c, 0.55f));
                Vox.box(-0.12f, 0.2f, 0.19f, -0.05f, 0.27f, 0.2f, 0xFF101010);
                Vox.box(0.05f, 0.2f, 0.19f, 0.12f, 0.27f, 0.2f, 0xFF101010);
                Vox.box(-0.03f, 0.1f, 0.19f, 0.03f, 0.13f, 0.2f, 0xFF101010);
                break;
            }
            case 5: { // Ghost
                int c = col(0xFFF0F4FF, tint);
                float w = (float) Math.sin(t * 3f);
                RenderUtil.alphaMul = 0.8f;
                Vox.box(-0.16f, 0.12f, -0.12f, 0.16f, 0.5f, 0.12f, c);
                Vox.box(-0.12f, 0.5f, -0.1f, 0.12f, 0.56f, 0.1f, c);
                for (int i = 0; i < 3; i++) {
                    float h = 0.12f + 0.05f * (float) Math.sin(t * 4f + i * 2f);
                    Vox.box(-0.16f + i * 0.11f, h * 0.0f, -0.1f, -0.06f + i * 0.11f, 0.12f + 0.02f * w * (i - 1), 0.1f, c);
                }
                RenderUtil.alphaMul = 1f;
                Vox.box(-0.09f, 0.3f, 0.12f, -0.04f, 0.4f, 0.13f, 0xFF101018);
                Vox.box(0.04f, 0.3f, 0.12f, 0.09f, 0.4f, 0.13f, 0xFF101018);
                Vox.box(-0.03f, 0.2f, 0.12f, 0.03f, 0.27f, 0.13f, 0xFF101018);
                break;
            }
            case 6: { // Penguin
                int c = col(0xFF22252E, tint);
                float wad = (float) Math.sin(walk * 1.2f) * Math.min(1f, sp) * 12f;
                GlStateManager.rotate(wad, 0f, 0f, 1f);
                Vox.box(-0.14f, 0.1f, -0.1f, 0.14f, 0.5f, 0.1f, c);
                Vox.box(-0.1f, 0.12f, 0.1f, 0.1f, 0.44f, 0.12f, 0xFFF4F4F4);
                Vox.box(-0.12f, 0.5f, -0.1f, 0.12f, 0.68f, 0.1f, c);
                Vox.box(-0.05f, 0.56f, 0.1f, 0.05f, 0.6f, 0.18f, 0xFFFFA020);
                Vox.box(-0.08f, 0.6f, 0.1f, -0.04f, 0.64f, 0.11f, 0xFFFFFFFF);
                Vox.box(0.04f, 0.6f, 0.1f, 0.08f, 0.64f, 0.11f, 0xFFFFFFFF);
                Vox.box(-0.19f, 0.2f, -0.05f, -0.14f, 0.46f, 0.05f, c);
                Vox.box(0.14f, 0.2f, -0.05f, 0.19f, 0.46f, 0.05f, c);
                Vox.box(-0.12f, 0f, -0.05f, -0.02f, 0.1f, 0.14f, 0xFFFFA020);
                Vox.box(0.02f, 0f, -0.05f, 0.12f, 0.1f, 0.14f, 0xFFFFA020);
                break;
            }
            case 7: { // Blaze spirit (chamas orbitando)
                int c = col(0xFFFFB020, tint);
                Vox.boxC(0, 0.3f, 0, 0.16f, 0.16f, 0.16f, c);
                Vox.boxC(0, 0.3f, 0, 0.1f, 0.1f, 0.1f, 0xFFFFF0A0);
                for (int i = 0; i < 4; i++) {
                    double an = t * 2.4 + i * Math.PI / 2.0;
                    Vox.boxC((float) Math.cos(an) * 0.28f, 0.3f + (float) Math.sin(t * 3 + i) * 0.08f, (float) Math.sin(an) * 0.28f, 0.05f, 0.26f, 0.05f, 0xFFE8A020);
                }
                GlStateManager.blendFunc(770, 1);
                GlStateManager.depthMask(false);
                GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                RenderUtil.color(RenderUtil.alpha(c, 0.5f));
                GL11.glVertex3f(0f, 0.3f, 0f);
                RenderUtil.color(RenderUtil.alpha(c, 0f));
                for (int i = 0; i <= 14; i++) {
                    double an = Math.PI * 2.0 * i / 14.0;
                    GL11.glVertex3f((float) Math.cos(an) * 0.55f, 0.3f + (float) Math.sin(an) * 0.55f, 0f);
                }
                GL11.glEnd();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                GlStateManager.depthMask(true);
                break;
            }
            default: { // Bunny
                int c = col(0xFFFAF4EC, tint), pk = 0xFFF2A0B8;
                float hp = (float) Math.abs(Math.sin(walk * 1.5f)) * Math.min(1f, sp) * 0.14f;
                GlStateManager.translate(0, hp, 0);
                Vox.box(-0.1f, 0.12f, -0.18f, 0.1f, 0.3f, 0.12f, c);
                Vox.box(-0.08f, 0.2f, 0.1f, 0.08f, 0.38f, 0.26f, c);
                Vox.box(-0.07f, 0.38f, 0.14f, -0.03f, 0.64f, 0.18f, c);
                Vox.box(0.03f, 0.38f, 0.14f, 0.07f, 0.64f, 0.18f, c);
                Vox.box(-0.065f, 0.4f, 0.18f, -0.035f, 0.6f, 0.19f, pk);
                Vox.box(0.035f, 0.4f, 0.18f, 0.065f, 0.6f, 0.19f, pk);
                Vox.box(-0.01f, 0.26f, 0.26f, 0.01f, 0.29f, 0.28f, pk);
                Vox.box(-0.06f, 0.3f, 0.255f, -0.03f, 0.33f, 0.265f, 0xFF101010);
                Vox.box(0.03f, 0.3f, 0.255f, 0.06f, 0.33f, 0.265f, 0xFF101010);
                Vox.box(-0.05f, 0.18f, -0.24f, 0.05f, 0.28f, -0.18f, 0xFFFFFFFF);
                Vox.box(-0.1f, 0f, -0.1f, -0.04f, 0.12f, 0.12f, c);
                Vox.box(0.04f, 0f, -0.1f, 0.1f, 0.12f, 0.12f, c);
                break;
            }
        }
    }
}
