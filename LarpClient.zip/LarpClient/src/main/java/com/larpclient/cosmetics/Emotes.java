package com.larpclient.cosmetics;

import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

/** Emotes 3D (tecla G): o jogador faz a danca e aparecem objetos 3D (carro, disco, foguete...). So voce ve. */
public final class Emotes {
    private Emotes() {}

    public static final String[] NAMES = {
            "Carro 3D", "Giro Louco", "Disco", "Foguete", "Chuva de Dinheiro", "Mola Pogo", "Trono Flutuante", "Onda de Choque"};
    public static final String[] DESC = {
            "Pula em cima do carro balancando", "Gira com faiscas", "Bola de espelhos e pista", "Sobe voando num foguete",
            "Notas e moedas caindo", "Pula numa mola gigante", "Flutua num trono dourado", "Aneis de energia no chao"};
    public static final int[] COLORS = {
            0xFFD8202A, 0xFFB14DFF, 0xFFFF4FD8, 0xFFFF8A2A, 0xFF2EC65A, 0xFF9AA4B2, 0xFFFFC83A, 0xFF2FD2FF};

    private static int cur = -1;
    private static long t0;

    public static boolean active() {
        return cur >= 0;
    }

    public static int current() {
        return cur;
    }

    public static void start(int i) {
        cur = i;
        t0 = System.nanoTime();
    }

    public static void stop() {
        cur = -1;
    }

    public static float time() {
        return (System.nanoTime() - t0) / 1e9f;
    }

    /** Deslocamento vertical (blocos) do jogador. */
    public static float jump() {
        float t = time();
        switch (cur) {
            case 0: return 0.74f + Math.abs((float) Math.sin(t * 6.0)) * 0.38f;
            case 1: return Math.abs((float) Math.sin(t * 5.0)) * 0.25f;
            case 2: return Math.abs((float) Math.sin(t * 8.0)) * 0.28f;
            case 3: {
                float k = Math.min(1f, t / 3f);
                float e = k * k * (3f - 2f * k);
                return 1.0f + e * 4.5f + (k >= 1f ? (float) Math.sin(t * 3.0) * 0.25f : 0f);
            }
            case 4: return Math.abs((float) Math.sin(t * 6.0)) * 0.2f;
            case 5: return 0.45f + Math.abs((float) Math.sin(t * 6.5)) * 1.1f;
            case 6: return 0.95f + (float) Math.sin(t * 2.0) * 0.12f;
            case 7: return 0.1f + (float) Math.sin(t * 4.0) * 0.15f;
            default: return 0f;
        }
    }

    /** Giro (graus) em torno do eixo vertical. */
    public static float spin() {
        float t = time();
        switch (cur) {
            case 1: return t * 540f;
            case 2: return (float) Math.sin(t * 3.0) * 25f;
            case 6: return t * 60f;
            case 7: return (float) Math.sin(t * 2.0) * 30f;
            default: return 0f;
        }
    }

    // ------------------------------------------------------------------ desenho
    private static void box(float cx, float cy, float cz, float sx, float sy, float sz, int col) {
        float x0 = cx - sx / 2f, x1 = cx + sx / 2f, y0 = cy - sy / 2f, y1 = cy + sy / 2f, z0 = cz - sz / 2f, z1 = cz + sz / 2f;
        GL11.glBegin(GL11.GL_QUADS);
        face(col, 1.0f, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1);
        face(col, 0.55f, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
        face(col, 0.8f, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
        face(col, 0.8f, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0);
        face(col, 0.68f, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
        face(col, 0.68f, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0);
        GL11.glEnd();
    }

    private static void face(int col, float k, float... v) {
        com.larpclient.util.RenderUtil.color(com.larpclient.util.RenderUtil.shade(col, k));
        for (int i = 0; i < 4; i++) GL11.glVertex3f(v[i * 3], v[i * 3 + 1], v[i * 3 + 2]);
    }

    /** Disco/cilindro deitado no eixo X (roda). */
    private static void wheel(float cx, float cy, float cz, float r, float w, float rot) {
        int n = 12;
        for (int side = 0; side < 2; side++) {
            float x = cx + (side == 0 ? -w : w) / 2f;
            GL11.glBegin(GL11.GL_TRIANGLE_FAN);
            com.larpclient.util.RenderUtil.color(0xFF9AA0AA);
            GL11.glVertex3f(x, cy, cz);
            com.larpclient.util.RenderUtil.color(0xFF15161A);
            for (int i = 0; i <= n; i++) {
                double a = Math.PI * 2 * i / n + rot;
                GL11.glVertex3f(x, cy + (float) Math.sin(a) * r, cz + (float) Math.cos(a) * r);
            }
            GL11.glEnd();
        }
        GL11.glBegin(GL11.GL_QUAD_STRIP);
        for (int i = 0; i <= n; i++) {
            double a = Math.PI * 2 * i / n + rot;
            com.larpclient.util.RenderUtil.color(i % 2 == 0 ? 0xFF1B1C21 : 0xFF2A2C33);
            GL11.glVertex3f(cx - w / 2f, cy + (float) Math.sin(a) * r, cz + (float) Math.cos(a) * r);
            GL11.glVertex3f(cx + w / 2f, cy + (float) Math.sin(a) * r, cz + (float) Math.cos(a) * r);
        }
        GL11.glEnd();
    }

    private static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float hh = h * 6f;
        int i = (int) hh;
        float f = hh - i, p = v * (1f - s), q = v * (1f - f * s), t = v * (1f - (1f - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return 0xFF000000 | ((int) (r * 255f) << 16) | ((int) (g * 255f) << 8) | (int) (b * 255f);
    }

    public static void renderProps(double x, double y, double z, float yawOff, float animTime) {
        if (cur < 0) return;
        float t = time();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, (float) z);
        GlStateManager.rotate(180f - yawOff, 0f, 1f, 0f);
        com.larpclient.util.RenderUtil.begin();
        GlStateManager.disableCull();
        GlStateManager.enableDepth();
        float off = jump();
        switch (cur) {
            case 0: { // carro balancando
                GlStateManager.rotate((float) Math.sin(t * 5.0) * 7f, 0f, 0f, 1f);
                GlStateManager.rotate((float) Math.sin(t * 10.0) * 2f, 1f, 0f, 0f);
                float bob = Math.abs((float) Math.sin(t * 10.0)) * 0.05f;
                GlStateManager.translate(0f, bob, 0f);
                box(0f, 0.30f, 0f, 1.05f, 0.30f, 2.1f, 0xFFD8202A);
                box(0f, 0.58f, 0.12f, 0.86f, 0.28f, 1.05f, 0xFFB01820);
                box(0f, 0.60f, 0.12f, 0.88f, 0.16f, 1.07f, 0xFF28385A);
                box(-0.34f, 0.32f, -1.06f, 0.26f, 0.12f, 0.05f, 0xFFFFF2A0);
                box(0.34f, 0.32f, -1.06f, 0.26f, 0.12f, 0.05f, 0xFFFFF2A0);
                box(-0.34f, 0.32f, 1.06f, 0.26f, 0.1f, 0.05f, 0xFFFF2A2A);
                box(0.34f, 0.32f, 1.06f, 0.26f, 0.1f, 0.05f, 0xFFFF2A2A);
                float wr = t * 14f;
                wheel(-0.56f, 0.17f, -0.66f, 0.2f, 0.16f, wr);
                wheel(0.56f, 0.17f, -0.66f, 0.2f, 0.16f, wr);
                wheel(-0.56f, 0.17f, 0.66f, 0.2f, 0.16f, wr);
                wheel(0.56f, 0.17f, 0.66f, 0.2f, 0.16f, wr);
                break;
            }
            case 1: { // faiscas girando
                GlStateManager.blendFunc(770, 1);
                GlStateManager.depthMask(false);
                for (int i = 0; i < 14; i++) {
                    float a = t * 4f + i * 0.45f;
                    float r = 0.7f + 0.25f * (float) Math.sin(t * 3f + i);
                    float yy = 0.2f + (i / 14f) * 1.8f + off;
                    GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                    com.larpclient.util.RenderUtil.color(0xFFE7C8FF);
                    GL11.glVertex3f((float) Math.cos(a) * r, yy, (float) Math.sin(a) * r);
                    com.larpclient.util.RenderUtil.color(0x00B14DFF);
                    for (int k = 0; k <= 8; k++) {
                        double q = Math.PI * 2 * k / 8;
                        GL11.glVertex3f((float) Math.cos(a) * r + (float) Math.cos(q) * 0.09f, yy + (float) Math.sin(q) * 0.09f, (float) Math.sin(a) * r);
                    }
                    GL11.glEnd();
                }
                GlStateManager.depthMask(true);
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                break;
            }
            case 2: { // disco
                for (int ix = -1; ix <= 1; ix++) {
                    for (int iz = -1; iz <= 1; iz++) {
                        float h = t * 0.5f + (ix + iz) * 0.12f + (ix * 3 + iz) * 0.07f;
                        float pulse = 0.55f + 0.45f * (float) Math.sin(t * 8f + ix * 2 + iz * 3);
                        box(ix * 0.95f, 0.03f, iz * 0.95f, 0.9f, 0.05f, 0.9f, hsv(h, 0.9f, 0.5f + 0.5f * pulse));
                    }
                }
                GlStateManager.pushMatrix();
                GlStateManager.translate(0f, 3.1f, 0f);
                GlStateManager.rotate(t * 60f, 0f, 1f, 0f);
                int lat = 6, lon = 10;
                GL11.glBegin(GL11.GL_QUADS);
                for (int a = 0; a < lat; a++) {
                    double p0 = Math.PI * a / lat, p1 = Math.PI * (a + 1) / lat;
                    for (int b = 0; b < lon; b++) {
                        double t0_ = Math.PI * 2 * b / lon, t1 = Math.PI * 2 * (b + 1) / lon;
                        float flash = 0.45f + 0.55f * (float) Math.sin(t * 6f + a * 1.7f + b * 2.3f);
                        com.larpclient.util.RenderUtil.color(hsv(0.58f + 0.1f * flash, 0.2f, 0.55f + 0.45f * Math.max(0f, flash)));
                        float r = 0.4f;
                        GL11.glVertex3f(r * (float) (Math.sin(p0) * Math.cos(t0_)), r * (float) Math.cos(p0), r * (float) (Math.sin(p0) * Math.sin(t0_)));
                        GL11.glVertex3f(r * (float) (Math.sin(p0) * Math.cos(t1)), r * (float) Math.cos(p0), r * (float) (Math.sin(p0) * Math.sin(t1)));
                        GL11.glVertex3f(r * (float) (Math.sin(p1) * Math.cos(t1)), r * (float) Math.cos(p1), r * (float) (Math.sin(p1) * Math.sin(t1)));
                        GL11.glVertex3f(r * (float) (Math.sin(p1) * Math.cos(t0_)), r * (float) Math.cos(p1), r * (float) (Math.sin(p1) * Math.sin(t0_)));
                    }
                }
                GL11.glEnd();
                GlStateManager.popMatrix();
                break;
            }
            case 3: { // foguete
                float y0 = off - 2.0f;
                GlStateManager.translate(0f, y0, 0f);
                int n = 10;
                GL11.glBegin(GL11.GL_QUAD_STRIP);
                for (int i = 0; i <= n; i++) {
                    double a = Math.PI * 2 * i / n;
                    com.larpclient.util.RenderUtil.color(i % 2 == 0 ? 0xFFF2F2F6 : 0xFFC9CBD4);
                    GL11.glVertex3f((float) Math.cos(a) * 0.32f, 0f, (float) Math.sin(a) * 0.32f);
                    GL11.glVertex3f((float) Math.cos(a) * 0.32f, 1.4f, (float) Math.sin(a) * 0.32f);
                }
                GL11.glEnd();
                GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                com.larpclient.util.RenderUtil.color(0xFFE02A2A);
                GL11.glVertex3f(0f, 1.95f, 0f);
                for (int i = 0; i <= n; i++) {
                    double a = Math.PI * 2 * i / n;
                    com.larpclient.util.RenderUtil.color(i % 2 == 0 ? 0xFFB81F1F : 0xFFE02A2A);
                    GL11.glVertex3f((float) Math.cos(a) * 0.32f, 1.4f, (float) Math.sin(a) * 0.32f);
                }
                GL11.glEnd();
                for (int f = 0; f < 3; f++) {
                    GlStateManager.pushMatrix();
                    GlStateManager.rotate(f * 120f, 0f, 1f, 0f);
                    GL11.glBegin(GL11.GL_TRIANGLES);
                    com.larpclient.util.RenderUtil.color(0xFF2A62D8);
                    GL11.glVertex3f(0.3f, 0.5f, 0f);
                    GL11.glVertex3f(0.3f, 0f, 0f);
                    GL11.glVertex3f(0.7f, -0.15f, 0f);
                    GL11.glEnd();
                    GlStateManager.popMatrix();
                }
                GlStateManager.blendFunc(770, 1);
                GlStateManager.depthMask(false);
                float fl = 1.0f + 0.35f * (float) Math.sin(t * 40f);
                GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                com.larpclient.util.RenderUtil.color(0xFFFFF0A0);
                GL11.glVertex3f(0f, -1.1f * fl, 0f);
                for (int i = 0; i <= n; i++) {
                    double a = Math.PI * 2 * i / n;
                    com.larpclient.util.RenderUtil.color(0x00FF7A1A);
                    GL11.glVertex3f((float) Math.cos(a) * 0.3f, 0f, (float) Math.sin(a) * 0.3f);
                }
                GL11.glEnd();
                GlStateManager.depthMask(true);
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                break;
            }
            case 4: { // chuva de dinheiro
                for (int i = 0; i < 26; i++) {
                    float ph = i * 0.731f;
                    float fall = ((t * 1.1f + i * 0.37f) % 3.2f);
                    float yy = 3.2f - fall;
                    float a = ph * 5f + t * 0.8f;
                    float r = 0.5f + (i % 5) * 0.28f;
                    GlStateManager.pushMatrix();
                    GlStateManager.translate((float) Math.cos(a) * r, yy, (float) Math.sin(a) * r);
                    GlStateManager.rotate(t * 120f + i * 40f, 0f, 1f, 0f);
                    GlStateManager.rotate(25f * (float) Math.sin(t * 4f + i), 1f, 0f, 0f);
                    if (i % 4 == 0) { // moeda dourada
                        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                        com.larpclient.util.RenderUtil.color(0xFFFFE27A);
                        GL11.glVertex3f(0f, 0f, 0f);
                        com.larpclient.util.RenderUtil.color(0xFFE0A21A);
                        for (int k = 0; k <= 10; k++) {
                            double q = Math.PI * 2 * k / 10;
                            GL11.glVertex3f((float) Math.cos(q) * 0.13f, (float) Math.sin(q) * 0.13f, 0f);
                        }
                        GL11.glEnd();
                    } else { // nota verde
                        GL11.glBegin(GL11.GL_QUADS);
                        com.larpclient.util.RenderUtil.color(0xFF2E9A4A);
                        GL11.glVertex3f(-0.19f, -0.09f, 0f);
                        GL11.glVertex3f(0.19f, -0.09f, 0f);
                        GL11.glVertex3f(0.19f, 0.09f, 0f);
                        GL11.glVertex3f(-0.19f, 0.09f, 0f);
                        com.larpclient.util.RenderUtil.color(0xFF7BD98F);
                        GL11.glVertex3f(-0.06f, -0.06f, 0.001f);
                        GL11.glVertex3f(0.06f, -0.06f, 0.001f);
                        GL11.glVertex3f(0.06f, 0.06f, 0.001f);
                        GL11.glVertex3f(-0.06f, 0.06f, 0.001f);
                        GL11.glEnd();
                    }
                    GlStateManager.popMatrix();
                }
                break;
            }
            case 5: { // mola
                GL11.glLineWidth(4f);
                GL11.glBegin(GL11.GL_LINE_STRIP);
                int turns = 7, seg = 18;
                for (int i = 0; i <= turns * seg; i++) {
                    float k = i / (float) (turns * seg);
                    double a = Math.PI * 2 * i / seg;
                    com.larpclient.util.RenderUtil.color(RenderUtilMix(0xFF6E7684, 0xFFD5DAE4, (i % seg) / (float) seg));
                    GL11.glVertex3f((float) Math.cos(a) * 0.22f, 0.05f + k * (off - 0.1f), (float) Math.sin(a) * 0.22f);
                }
                GL11.glEnd();
                GL11.glLineWidth(1f);
                box(0f, 0.03f, 0f, 0.6f, 0.06f, 0.6f, 0xFF3A3F4A);
                box(0f, off - 0.05f, 0f, 0.5f, 0.06f, 0.5f, 0xFFE0A21A);
                break;
            }
            case 6: { // trono
                float by = off - 0.52f;
                box(0f, by, 0f, 0.95f, 0.12f, 0.95f, 0xFFE0A21A);
                box(0f, by + 0.42f, 0.4f, 0.95f, 0.8f, 0.12f, 0xFFFFC83A);
                box(-0.45f, by + 0.2f, 0f, 0.1f, 0.3f, 0.8f, 0xFFC98A12);
                box(0.45f, by + 0.2f, 0f, 0.1f, 0.3f, 0.8f, 0xFFC98A12);
                box(0f, by + 0.03f, 0f, 0.8f, 0.12f, 0.8f, 0xFFB01820);
                GlStateManager.blendFunc(770, 1);
                GlStateManager.depthMask(false);
                for (int i = 0; i < 8; i++) {
                    float a = t * 2f + i * 0.785f;
                    float yy = by - 0.1f + 0.3f * (float) Math.sin(t * 3f + i);
                    GL11.glBegin(GL11.GL_TRIANGLE_FAN);
                    com.larpclient.util.RenderUtil.color(0xFFFFF0B0);
                    GL11.glVertex3f((float) Math.cos(a) * 0.7f, yy, (float) Math.sin(a) * 0.7f);
                    com.larpclient.util.RenderUtil.color(0x00FFC83A);
                    for (int k = 0; k <= 8; k++) {
                        double q = Math.PI * 2 * k / 8;
                        GL11.glVertex3f((float) Math.cos(a) * 0.7f + (float) Math.cos(q) * 0.08f, yy + (float) Math.sin(q) * 0.08f, (float) Math.sin(a) * 0.7f);
                    }
                    GL11.glEnd();
                }
                GlStateManager.depthMask(true);
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                break;
            }
            default: { // onda de choque
                GlStateManager.blendFunc(770, 1);
                GlStateManager.depthMask(false);
                for (int i = 0; i < 4; i++) {
                    float r = (t * 1.8f + i * 0.8f) % 3.2f;
                    float al = 1f - r / 3.2f;
                    GL11.glLineWidth(3f);
                    GL11.glBegin(GL11.GL_LINE_LOOP);
                    com.larpclient.util.RenderUtil.color(com.larpclient.util.RenderUtil.alpha(0xFF2FD2FF, al));
                    for (int k = 0; k < 40; k++) {
                        double q = Math.PI * 2 * k / 40;
                        GL11.glVertex3f((float) Math.cos(q) * r, 0.04f, (float) Math.sin(q) * r);
                    }
                    GL11.glEnd();
                }
                GL11.glLineWidth(1f);
                GlStateManager.depthMask(true);
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                break;
            }
        }
        GlStateManager.enableCull();
        com.larpclient.util.RenderUtil.end();
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }

    private static int RenderUtilMix(int a, int b, float t) {
        return com.larpclient.util.RenderUtil.mix(a, b, t);
    }
}
