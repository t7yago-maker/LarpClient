package com.larpclient.cosmetics;

import com.larpclient.util.RenderUtil;
import org.lwjgl.opengl.GL11;

/** Caixas coloridas com sombreamento por face: base dos modelos 3D (memes, pets). Use dentro de RenderUtil.begin(). */
public final class Vox {
    private Vox() {}

    public static void box(float x0, float y0, float z0, float x1, float y1, float z1, int col) {
        GL11.glBegin(GL11.GL_QUADS);
        RenderUtil.color(RenderUtil.shade(col, 1.0f));
        GL11.glVertex3f(x0, y1, z0); GL11.glVertex3f(x1, y1, z0); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x0, y1, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.5f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x0, y0, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.85f));
        GL11.glVertex3f(x0, y0, z1); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x0, y1, z1);
        RenderUtil.color(RenderUtil.shade(col, 0.65f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y1, z0); GL11.glVertex3f(x0, y1, z0);
        RenderUtil.color(RenderUtil.shade(col, 0.78f));
        GL11.glVertex3f(x0, y0, z0); GL11.glVertex3f(x0, y0, z1); GL11.glVertex3f(x0, y1, z1); GL11.glVertex3f(x0, y1, z0);
        RenderUtil.color(RenderUtil.shade(col, 0.92f));
        GL11.glVertex3f(x1, y0, z0); GL11.glVertex3f(x1, y0, z1); GL11.glVertex3f(x1, y1, z1); GL11.glVertex3f(x1, y1, z0);
        GL11.glEnd();
    }

    /** Caixa centrada. */
    public static void boxC(float cx, float cy, float cz, float sx, float sy, float sz, int col) {
        box(cx - sx / 2f, cy - sy / 2f, cz - sz / 2f, cx + sx / 2f, cy + sy / 2f, cz + sz / 2f, col);
    }

    /** Prisma vertical (cilindro com poucas faces). */
    public static void cyl(float cx, float y0, float cz, float r, float y1, int segs, int col) {
        GL11.glBegin(GL11.GL_QUADS);
        for (int i = 0; i < segs; i++) {
            double a0 = Math.PI * 2.0 * i / segs, a1 = Math.PI * 2.0 * (i + 1) / segs;
            float k = 0.6f + 0.4f * (float) Math.cos((a0 + a1) / 2.0 - 0.8);
            RenderUtil.color(RenderUtil.shade(col, k));
            GL11.glVertex3f(cx + (float) Math.cos(a0) * r, y0, cz + (float) Math.sin(a0) * r);
            GL11.glVertex3f(cx + (float) Math.cos(a1) * r, y0, cz + (float) Math.sin(a1) * r);
            GL11.glVertex3f(cx + (float) Math.cos(a1) * r, y1, cz + (float) Math.sin(a1) * r);
            GL11.glVertex3f(cx + (float) Math.cos(a0) * r, y1, cz + (float) Math.sin(a0) * r);
        }
        GL11.glEnd();
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        RenderUtil.color(RenderUtil.shade(col, 1.05f));
        GL11.glVertex3f(cx, y1, cz);
        for (int i = 0; i <= segs; i++) {
            double a = Math.PI * 2.0 * i / segs;
            GL11.glVertex3f(cx + (float) Math.cos(a) * r, y1, cz + (float) Math.sin(a) * r);
        }
        GL11.glEnd();
    }
}
